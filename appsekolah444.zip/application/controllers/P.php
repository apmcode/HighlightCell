<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class P extends CI_Controller {

	function __construct() {
        parent::__construct();
		date_default_timezone_set("Asia/Jakarta");

        $cek = $this->session->userdata('arr_login');
        $cek_role = explode('*&*&*', $cek);
        if ($cek_role[1] !== 'Admin') {
            redirect('login');
            return false;
        }
    }

    public function index(){
        redirect('p/dashboard');
    }

    public function tahunpelajaran(){
    	$this->load->view('template/header');
    	$this->data['tampil'] = $this->db->query("SELECT * FROM tahun_ajaran")->result_array();
    	$this->load->view('tahun_ajar/tahunajar', $this->data);
    }
    public function edittahunpelajaran(){
    	$this->load->view('template/header');
    	$sql = $this->db->query("SELECT * FROM tahun_ajaran WHERE id_tahun = '$_GET[edit_thnplj]'");
    	$cek = $sql->num_rows();
    	if ($cek=='0') {
    		redirect('p/tahunpelajaran');
    		return false;
    	}
    	$this->data['tampil'] = $sql->row();
    	$this->load->view('tahun_ajar/edittahunajar', $this->data);
    }
    public function addtahunpelajaran(){
    	if ($_GET['page'] !== 'tahunpelajaran'){
    		redirect('p/tahunpelajaran');
    		return false;
    	}
    	$this->load->view('template/header');
    	$this->load->view('tahun_ajar/edittahunajar');
    }

	public function beasiswa(){
    	$this->load->view('template/header');
    	$this->data['tampil'] = $this->db->query("SELECT * FROM beasiswa WHERE NOT id_beasiswa='0'")->result_array();
    	$this->load->view('beasiswa/beasiswa', $this->data);
	}
    public function editbeasiswa(){
    	$this->load->view('template/header');
    	$sql = $this->db->query("SELECT * FROM beasiswa WHERE id_beasiswa = '$_GET[edit_beasiswa]'");
    	$cek = $sql->num_rows();
    	if ($cek=='0') {
    		redirect('p/beasiswa');
    		return false;
    	}
    	$this->data['tampil'] = $sql->row();
    	$this->load->view('beasiswa/editbeasiswa', $this->data);
    }
    public function addbeasiswa(){
    	if ($_GET['page'] !== 'beasiswa'){
    		redirect('p/beasiswa');
    		return false;
    	}
    	$this->load->view('template/header');
    	$this->load->view('beasiswa/editbeasiswa');
    }

	public function kelas(){
    	$this->load->view('template/header');
    	$this->data['tampil'] = $this->db->query("SELECT * FROM kelas")->result_array();
    	$this->load->view('kelas/kelas', $this->data);
	}
    public function editkelas(){
    	$this->load->view('template/header');
    	$sql = $this->db->query("SELECT * FROM kelas WHERE id_kelas = '$_GET[edit_kelas]'");
    	$cek = $sql->num_rows();
    	if ($cek=='0') {
    		redirect('p/kelas');
    		return false;
    	}
    	$this->data['tampil'] = $sql->row();
    	$this->load->view('kelas/editkelas', $this->data);
    }
    public function addkelas(){
    	if ($_GET['page'] !== 'kelas'){
    		redirect('p/kelas');
    		return false;
    	}
    	$this->load->view('template/header');
    	$this->load->view('kelas/editkelas');
    }

	public function siswa(){
    	$this->load->view('template/header');
    	$sql = "SELECT student.id_student, student.no_induk, student.nisn, student.nama_murid, student.tempat_lahir, student.tgl_lahir, agama.ket_agama, kelas.ket_kelas, student.id_agama, student.id_kelas
			FROM student
			INNER JOIN kelas ON kelas.id_kelas=student.id_kelas
			INNER JOIN agama ON agama.id_agama=student.id_agama
            WHERE student.status_murid='0'";
    	$this->data['tampil'] = $this->db->query($sql)->result_array();
    	$this->load->view('siswa/siswa', $this->data);
	}
    public function editsiswa(){
    	$this->load->view('template/header');
    	$sql = "SELECT *
			FROM student
			INNER JOIN kelas ON kelas.id_kelas=student.id_kelas
			INNER JOIN agama ON agama.id_agama=student.id_agama WHERE student.id_student='$_GET[edit_siswa]'";
    	$sql = $this->db->query($sql);
    	$cek = $sql->num_rows();
    	if ($cek=='0') {
    		redirect('p/siswa');
    		return false;
    	}
    	$this->data['tampil'] = $sql->row();
    	$this->load->view('siswa/editsiswa', $this->data);
    }
    public function addsiswa(){
    	if ($_GET['page'] !== 'siswa'){
    		redirect('p/siswa');
    		return false;
    	}
    	$this->load->view('template/header');
    	$this->load->view('siswa/editsiswa');
    }
    public function uploadsiswa(){
    	if ($_GET['page'] !== 'siswa'){
    		redirect('p/siswa');
    		return false;
    	}
    	$this->load->view('template/header');
    	$this->load->view('siswa/uploadsiswa');
    }

    public function kenaikankelas(){
        $this->load->view('template/header');
        $this->load->view('kenaikan_kelas/naik_kelas');
    }

    public function kelulusan(){
        $this->load->view('template/header');
        $this->load->view('kenaikan_kelas/kelulusan');
    }
    public function listlulus(){
        $this->load->view('template/header');
        $sql = "SELECT student.id_student, student.no_induk, student.nisn, student.nama_murid, student.tempat_lahir, student.tgl_lahir, agama.ket_agama, kelas.ket_kelas, student.id_agama, student.id_kelas, student.status_murid
            FROM student
            INNER JOIN kelas ON kelas.id_kelas=student.id_kelas
            INNER JOIN agama ON agama.id_agama=student.id_agama
            WHERE NOT student.status_murid='0'";
        $this->data['tampil'] = $this->db->query($sql)->result_array();
        $this->load->view('kenaikan_kelas/list_lulus', $this->data);
    }
//KEUANGAN
	public function pos_keu(){
    	$this->load->view('template/header');
    	$this->data['tampil'] = $this->db->query("SELECT * FROM pos_keuangan")->result_array();
    	$this->load->view('pos_keu/pos_keu', $this->data);
	}
    public function editpos_keu(){
    	$this->load->view('template/header');
    	$sql = $this->db->query("SELECT * FROM pos_keuangan WHERE id_pos = '$_GET[editpos_keu]'");
    	$cek = $sql->num_rows();
    	if ($cek=='0') {
    		redirect('p/pos_keu');
    		return false;
    	}
    	$this->data['tampil'] = $sql->row();
    	$this->load->view('pos_keu/editpos_keu', $this->data);
    }
    public function addpos_keu(){
    	if ($_GET['page'] !== 'pos_keu'){
    		redirect('p/pos_keu');
    		return false;
    	}
    	$this->load->view('template/header');
    	$this->load->view('pos_keu/editpos_keu');
    }

	public function jenis_pembayaran(){
    	$this->load->view('template/header');
    	$this->data['tampil'] = $this->db->query("SELECT * FROM jenis_pembayaran 
				INNER JOIN pos_keuangan ON pos_keuangan.id_pos=jenis_pembayaran.id_pos
				INNER JOIN tipe_bayar ON tipe_bayar.id_tipe=jenis_pembayaran.id_tipe
				INNER JOIN tahun_ajaran ON tahun_ajaran.id_tahun=jenis_pembayaran.id_tahun")->result_array();
    	$this->load->view('jenis_pembayaran/jenis_pembayaran', $this->data);
	}
    public function editjenis_pembayaran(){
    	$this->load->view('template/header');
    	$sql = $this->db->query("SELECT * FROM jenis_pembayaran 
					INNER JOIN pos_keuangan ON pos_keuangan.id_pos=jenis_pembayaran.id_pos
					INNER JOIN tipe_bayar ON tipe_bayar.id_tipe=jenis_pembayaran.id_tipe
					INNER JOIN tahun_ajaran ON tahun_ajaran.id_tahun=jenis_pembayaran.id_tahun 
					WHERE jenis_pembayaran.id_jp = '$_GET[edit_jp]'");
    	$cek = $sql->num_rows();
    	if ($cek=='0') {
    		redirect('p/jenis_pembayaran');
    		return false;
    	}
    	$this->data['tampil'] = $sql->row();
    	$this->load->view('jenis_pembayaran/editjenis_pembayaran', $this->data);
    }
    public function addjenis_pembayaran(){
    	if ($_GET['addjenis_pembayaran'] !== 'true'){
    		redirect('p/jenis_pembayaran');
    		return false;
    	}
    	$this->load->view('template/header');
    	$this->load->view('jenis_pembayaran/editjenis_pembayaran');
    }

    //REGIS PEMBAYARAN
    public function setting_jp(){
    	if ($_GET['jenis_pembayaran'] !== 'true'){
    		$this->session->set_userdata('alert', 'Maaf Url invalid');
    		redirect('p/jenis_pembayaran');
    		return false;
    	}
    	$this->data['tampil'] = $this->db->query("SELECT * FROM jenis_pembayaran 
					INNER JOIN pos_keuangan ON pos_keuangan.id_pos=jenis_pembayaran.id_pos
					INNER JOIN tipe_bayar ON tipe_bayar.id_tipe=jenis_pembayaran.id_tipe
					INNER JOIN tahun_ajaran ON tahun_ajaran.id_tahun=jenis_pembayaran.id_tahun 
                    WHERE jenis_pembayaran.id_jp = '$_GET[setting_jp]'")->row();
    	$this->session->set_userdata('id_jp', $_GET['setting_jp']);

    	$this->load->view('template/header');
    	$this->load->view('jenis_pembayaran/regis_pembayaran', $this->data);
    }

    //PERBARUI TRANSAKSI
    public function perbaruitransaksibln(){
    	$this->load->view('template/header');
    	$query = "SELECT 
				regis_transaksi.id_regis, pos_keuangan.nama_pos, tahun_ajaran.ket_tahun_ajaran, tipe_bayar.ket_tipe, kelas.ket_kelas,
				student.nama_murid, student.no_induk, bulan.nama_bulan, regis_transaksi.biaya
				FROM regis_transaksi
				INNER JOIN student ON student.id_student=regis_transaksi.id_student
				INNER JOIN kelas ON kelas.id_kelas=student.id_kelas
				INNER JOIN beasiswa ON beasiswa.id_beasiswa=regis_transaksi.id_beasiswa
				INNER JOIN jenis_pembayaran ON jenis_pembayaran.id_jp=regis_transaksi.id_jp
				INNER JOIN tipe_bayar ON tipe_bayar.id_tipe=jenis_pembayaran.id_tipe
				INNER JOIN pos_keuangan ON pos_keuangan.id_pos=jenis_pembayaran.id_pos
				INNER JOIN tahun_ajaran ON tahun_ajaran.id_tahun=jenis_pembayaran.id_tahun
				INNER JOIN bulan ON bulan.id_bulan=regis_transaksi.id_bulan
				WHERE regis_transaksi.id_student='$_GET[stu]' AND regis_transaksi.id_jp='$_GET[jp]'";
    	$sql = $this->db->query($query);
    	// edit_tr
    	$cek = $this->db->query("SELECT id_student FROM regis_transaksi WHERE id_student='$_GET[stu]' AND id_jp='$_GET[jp]'")->num_rows();
    	if ($cek=='0') {
    		$this->session->set_userdata('alert', 'Maaf Url invalid');
    		redirect('p/jenis_pembayaran');
    		return false;
    	}
    	$this->data['tampil'] = $sql->result_array();
    	$this->load->view('jenis_pembayaran/perbarui_transaksi', $this->data);
    }

    public function kwitansi_pembayaran(){
        $this->load->view('template/header');
        $this->data['tampil'] = $this->db->query("SELECT student.nama_murid, kelas.ket_kelas, regis_transaksi.date_bayar, regis_transaksi.no_transaksi, student.id_student, regis_transaksi.id_regis
            FROM regis_transaksi 
            INNER JOIN student ON student.id_student=regis_transaksi.id_student
            INNER JOIN kelas ON kelas.id_kelas=student.id_kelas
            WHERE regis_transaksi.status_bayar='1'")->result_array();
        $this->load->view('transaksi_pembayaran/kwitansi_pembayaran', $this->data);
    }

    //HAPUS TRANSAKSI
    public function hapustr(){
        $this->load->view('template/header');
        $this->load->view('jenis_pembayaran/perbarui_transaksi', $this->data);
    }

    public function addtransaksibln(){
    	$this->load->view('template/header');

    	$sql = "SELECT * FROM jenis_pembayaran 
				INNER JOIN pos_keuangan ON pos_keuangan.id_pos=jenis_pembayaran.id_pos
				INNER JOIN tipe_bayar ON tipe_bayar.id_tipe=jenis_pembayaran.id_tipe
				INNER JOIN tahun_ajaran ON tahun_ajaran.id_tahun=jenis_pembayaran.id_tahun
				WHERE jenis_pembayaran.id_jp='$_GET[jp]'";

		$cekjenispem = $this->db->query($sql)->num_rows();
    	if ($cekjenispem=='0') {
    		$this->session->set_userdata('alert', 'Maaf Url invalid');
	    		redirect('p/jenis_pembayaran');
    		return false;
    	}

		$this->data['tampil'] = $this->db->query($sql)->row();
    	$this->load->view('jenis_pembayaran/add_transaksi', $this->data);
    }

    public function transaksi_pembayaran(){
        $this->load->view('template/header');
        $this->load->view('transaksi_pembayaran/pembayaran');
    }

    public function set_sekolah(){
        $this->load->view('template/header');
        $this->data['tampil'] = $this->db->query("SELECT * FROM sekolah")->row();
        $this->load->view('sekolah/set_sekolah', $this->data);
    }

    public function jur_masuk(){
        $this->load->view('template/header');
        $this->data['tampil'] = $this->db->query("SELECT * FROM jurnal_umul WHERE stat_peng_msk='1'")->result_array();
        $this->load->view('jurnal/jurnalmasuk', $this->data);
    }
    public function addjurmasuk(){
        $this->load->view('template/header');
        $this->load->view('jurnal/editjurnalmasuk');
    }
    public function editjurmasuk(){
        $this->load->view('template/header');
        $this->data['tampil'] = $this->db->query("SELECT * FROM jurnal_umul WHERE id_jurnal='$_GET[jurnal_masuk]'")->row();
        $this->load->view('jurnal/editjurnalmasuk', $this->data);
    }

    public function jur_pengeluaran(){
        $this->load->view('template/header');
        $this->data['tampil'] = $this->db->query("SELECT * FROM jurnal_umul WHERE stat_peng_msk='2'")->result_array();
        $this->load->view('jurnal/jurnalpengeluaran', $this->data);
    }
    public function addjurkeluar(){
        $this->load->view('template/header');
        $this->load->view('jurnal/editjurnalpengeluaran');
    }
    public function editjurkeluar(){
        $this->load->view('template/header');
        $this->data['tampil'] = $this->db->query("SELECT * FROM jurnal_umul WHERE id_jurnal='$_GET[jurnal_keluar]'")->row();
        $this->load->view('jurnal/editjurnalpengeluaran', $this->data);
    }
    
    public function lap_keu(){
        $this->load->view('template/header');
        $this->load->view('laporan/lap_keu');
    }

    public function rekap_pembayaran(){
        $this->load->view('template/header');
        $this->load->view('laporan/rekap_keu');
    }

    public function pengguna(){
        $this->load->view('template/header');
        $this->data['tampil'] = $this->db->query("SELECT * FROM user_login")->result_array();
        $this->load->view('pengguna/pengguna', $this->data);
    }

    public function adduser(){
        $this->load->view('template/header');
        $this->load->view('pengguna/editpengguna');
    }

    public function edituser(){
        $this->load->view('template/header');
        $this->data['tampil'] = $this->db->query("SELECT * FROM user_login WHERE id_user='$_GET[edituser]'")->row();
        $this->load->view('pengguna/editpengguna', $this->data);
    }

    public function dashboard(){
        $this->load->view('template/header');
        $this->data['tampil'] = $this->db->query("SELECT * FROM user_login")->row();
        $this->load->view('dashboard/dashboard', $this->data);
    }
}
?>


