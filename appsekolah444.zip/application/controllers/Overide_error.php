<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Overide_error extends CI_Controller {

	public function index()
	{
		$this->load->view('error_404');
	}
}
