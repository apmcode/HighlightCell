<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
 
class Ajax extends CI_Controller {
 
	function __construct() {
		date_default_timezone_set('asia/jakarta');
        parent::__construct();
        $cek = $this->session->userdata('arr_login');
		if (empty($cek)) {
			redirect('login');
            return false;
		}
    }

    public function index(){
		redirect('p/dashboard');
	}
     
    public function simpanthnpel(){
    	$tahun_ajar = $_POST['tahun_ajar'];
    	$status = $_POST['status'];
    	$kode = $_POST['kode'];
    	if (empty($kode)) {
    		$cek_insert = $this->db->query("SELECT id_tahun FROM tahun_ajaran WHERE ket_tahun_ajaran='$tahun_ajar'")->num_rows();
		    if ($cek_insert > 0) {
	 			$msg = "Data gagal tersimpan, Adanya Duplikat data !!!";
				$this->session->set_userdata('error', $msg);
				return false; 		
	    	}
    		$sql = "INSERT INTO tahun_ajaran (id_tahun, ket_tahun_ajaran, status_thn_pel) VALUES (NULL,'$tahun_ajar','$status')";
    	}else{
    		$cek_update = $this->db->query("SELECT id_tahun FROM tahun_ajaran WHERE ket_tahun_ajaran='$tahun_ajar' AND NOT id_tahun='$kode'")->num_rows();
   		    if ($cek_update > 0) {
	 			$msg = "Data gagal tersimpan, Adanya Duplikat data !!!";
				$this->session->set_userdata('error', $msg);
				return false; 		
	    	}
    		$sql = "UPDATE tahun_ajaran SET ket_tahun_ajaran='$tahun_ajar', status_thn_pel='$status' WHERE id_tahun='$kode'";
    	}
		$simpan = $this->db->query($sql);
		if ($simpan == 1) {
			$msg = "Data berhasil tersimpan !!!";
			$this->session->set_userdata('msg', $msg);
			return false;
		}else{
			$msg = "Data gagal tersimpan !!!";
			$this->session->set_userdata('error', $msg);
			return false;
		}
    }

    public function hapussiswa(){
    	$id=$_POST['id'];

    	$cek_regis =  $this->db->query("SELECT id_student FROM regis_transaksi WHERE id_student='$id'")->num_rows();
    	$delete_pg =  $this->db->query("DELETE FROM jawaban_uraian WHERE id_student='$id'");
    	$delete_uraian =  $this->db->query("DELETE FROM jawaban WHERE id_student='$id'");
    	if ($cek_regis > 0) {
 			$msg = "Data siswa terkait dengan Registrasi Pembayaran tidak bisa dihapus!";
			$this->session->set_userdata('error', $msg);
			return false;
    	}

		$hapus = $this->db->query("DELETE FROM student WHERE id_student = '$id'");
	        $delete_pg =  $this->db->query("DELETE FROM jawaban_uraian WHERE id_student='$id'");
        	$delete_uraian =  $this->db->query("DELETE FROM jawaban WHERE id_student='$id'");
		if ($hapus == 1) {
			$msg = "Data berhasil terhapus !!!";
			$this->session->set_userdata('msg', $msg);
			return false;
		}else{
			$msg = "Data gagal terhapus !!!";
			$this->session->set_userdata('error', $msg);
			return false;
		}
    }

    public function hapusthnpel(){
    	$id=$_POST['id'];
    	$cek =  $this->db->query("SELECT id_tahun FROM jenis_pembayaran WHERE id_tahun='$id'")->num_rows();
    	if ($cek > 0) {
 			$msg = "Data saling terkait tidak bisa dihapus!";
			$this->session->set_userdata('error', $msg);
			return false;
    	}


		$hapus = $this->db->query("DELETE FROM tahun_ajaran WHERE id_tahun = '$id'");
		if ($hapus == 1) {
			$msg = "Data berhasil terhapus !!!";
			$this->session->set_userdata('msg', $msg);
			return false;
		}else{
			$msg = "Data gagal terhapus !!!";
			$this->session->set_userdata('error', $msg);
			return false;
		}
    }

    public function simpanbeasiswa(){
    	$keterangan = $_POST['keterangan'];
    	$potongan = $_POST['potongan'];
    	$kode = $_POST['kode'];

    	if (empty($kode)) {
    		$cek_insert = $this->db->query("SELECT id_beasiswa FROM beasiswa WHERE ket_beasiswa='$keterangan'")->num_rows();
		    if ($cek_insert > 0) {
	 			$msg = "Data gagal tersimpan, Adanya Duplikat data !!!";
				$this->session->set_userdata('error', $msg);
				return false; 		
	    	}
    		$sql = "INSERT INTO beasiswa (id_beasiswa, ket_beasiswa, potongan) VALUES (NULL,'$keterangan','$potongan')";
    	}else{
    		$cek_update = $this->db->query("SELECT id_beasiswa FROM beasiswa WHERE ket_beasiswa='$keterangan' AND NOT id_beasiswa='$kode'")->num_rows();
   		    if ($cek_update > 0) {
	 			$msg = "Data gagal tersimpan, Adanya Duplikat data !!!";
				$this->session->set_userdata('error', $msg);
				return false; 		
	    	}
    		$sql = "UPDATE beasiswa SET ket_beasiswa='$keterangan', potongan='$potongan' WHERE id_beasiswa='$kode'";
    	}
		$simpan = $this->db->query($sql);
		if ($simpan == 1) {
			$msg = "Data berhasil tersimpan !!!";
			$this->session->set_userdata('msg', $msg);
			return false;
		}else{
			$msg = "Data gagal tersimpan !!!";
			$this->session->set_userdata('error', $msg);
			return false;
		}
    }
    public function hapusbeasiswa(){
    	$id=$_POST['id'];
    	
    	$cek =  $this->db->query("SELECT id_beasiswa FROM regis_transaksi WHERE id_beasiswa='$id'")->num_rows();
    	if ($cek > 0) {
 			$msg = "Data saling terkait tidak bisa dihapus!";
			$this->session->set_userdata('error', $msg);
			return false;
    	}

		$hapus = $this->db->query("DELETE FROM beasiswa WHERE id_beasiswa = '$id'");
		if ($hapus == 1) {
			$msg = "Data berhasil terhapus !!!";
			$this->session->set_userdata('msg', $msg);
			return false;
		}else{
			$msg = "Data gagal terhapus !!!";
			$this->session->set_userdata('error', $msg);
			return false;
		}
    }

    public function simpankelas(){
    	$keterangan = $_POST['keterangan'];
    	$kode = $_POST['kode'];

    	if (empty($kode)) {
    		$cek_insert = $this->db->query("SELECT id_kelas FROM kelas WHERE ket_kelas='$keterangan'")->num_rows();
		    if ($cek_insert > 0) {
	 			$msg = "Data gagal tersimpan, Adanya Duplikat data !!!";
				$this->session->set_userdata('error', $msg);
				return false; 		
	    	}
    		$sql = "INSERT INTO kelas (id_kelas, ket_kelas) VALUES (NULL,'$keterangan')";
    	}else{
    		$cek_update = $this->db->query("SELECT id_kelas FROM kelas WHERE ket_kelas='$keterangan' AND NOT id_kelas='$kode'")->num_rows();
   		    if ($cek_update > 0) {
	 			$msg = "Data gagal tersimpan, Adanya Duplikat data !!!";
				$this->session->set_userdata('error', $msg);
				return false; 		
	    	}
    		$sql = "UPDATE kelas SET ket_kelas='$keterangan' WHERE id_kelas='$kode'";
    	}
		$simpan = $this->db->query($sql);
		if ($simpan == 1) {
			$msg = "Data berhasil tersimpan !!!";
			$this->session->set_userdata('msg', $msg);
			return false;
		}else{
			$msg = "Data gagal tersimpan !!!";
			$this->session->set_userdata('error', $msg);
			return false;
		}
    }
    public function hapuskelas(){
    	$id=$_POST['id'];
    	
    	$cek =  $this->db->query("SELECT id_kelas FROM student WHERE id_kelas='$id'")->num_rows();
    	if ($cek > 0) {
 			$msg = "Data saling terkait tidak bisa dihapus!";
			$this->session->set_userdata('error', $msg);
			return false;
    	}
    	$cek2 =  $this->db->query("SELECT id_kelas FROM mata_pelajaran WHERE id_kelas='$id'")->num_rows();
    	if ($cek2 > 0) {
 			$msg = "Data saling terkait tidak bisa dihapus!";
			$this->session->set_userdata('error', $msg);
			return false;
    	}

		$hapus = $this->db->query("DELETE FROM kelas WHERE id_kelas = '$id'");
		if ($hapus == 1) {
			$msg = "Data berhasil terhapus !!!";
			$this->session->set_userdata('msg', $msg);
			return false;
		}else{
			$msg = "Data gagal terhapus !!!";
			$this->session->set_userdata('error', $msg);
			return false;
		}
    }

    public function simpansiswa(){
    	$no_induk = $_POST['no_induk'];
    	$nisn = $_POST['nisn'];
    	$nama_murid = $_POST['nama_murid'];
    	$tempat_lahir = $_POST['tempat_lahir'];
    	$tgl_lahir = $_POST['tgl_lahir'];
    	$jenis_kelamin = $_POST['jenis_kelamin'];
    	$agama = $_POST['agama'];
    	$kelas = $_POST['kelas'];
    	$alamat = $_POST['alamat'];
    	$nama_ibu = $_POST['nama_ibu'];
    	$nama_ayah = $_POST['nama_ayah'];
    	$hp_siswa = $_POST['hp_siswa'];
    	$hp_orang_tua = $_POST['hp_orang_tua'];
    	$kode = $_POST['kode'];
		$password = password_hash($no_induk, PASSWORD_DEFAULT);

    	if (empty($kode)) {
    		$cek_no_induk = $this->db->query("SELECT id_student FROM student WHERE no_induk='$no_induk'")->num_rows();
    		$cek_nisn = $this->db->query("SELECT id_student FROM student WHERE nisn='$nisn'")->num_rows();
    		$no_hp_ortu = $this->db->query("SELECT id_student FROM student WHERE hp_orang_tua='$hp_orang_tua'")->num_rows();
   		    if ($cek_no_induk > 0) {
	 			$msg = "Data gagal tersimpan, Adanya Duplikat No Induk. !!!";
				$this->session->set_userdata('error', $msg);
				return false; 		
	    	}
   		    if ($cek_nisn > 0) {
	 			$msg = "Data gagal tersimpan, Adanya Duplikat NISN. !!!";
				$this->session->set_userdata('error', $msg);
				return false; 		
	    	}
   		    if ($no_hp_ortu > 0) {
	 			$msg = "Data gagal tersimpan, Adanya Duplikat No HP Ortu. !!!";
				$this->session->set_userdata('error', $msg);
				return false; 		
	    	}
    		$sql = "INSERT INTO student (id_student, no_induk, nisn, nama_murid, tempat_lahir, tgl_lahir, jenis_kelamin, id_agama, id_kelas, alamat, nama_ibu, nama_ayah, hp_siswa, hp_orang_tua, password_student) VALUES 
    		(NULL, '$no_induk', '$nisn', '$nama_murid', '$tempat_lahir', '$tgl_lahir', '$jenis_kelamin', '$agama', '$kelas', '$alamat', '$nama_ibu', '$nama_ayah', '$hp_siswa', '$hp_orang_tua', '$password_student')";
    	}else{
    		$cek_no_induk=$this->db->query("SELECT id_student FROM student WHERE no_induk='$no_induk' AND NOT id_student='$kode'")->num_rows();
    		$cek_nisn = $this->db->query("SELECT id_student FROM student WHERE nisn='$nisn' AND NOT id_student='$kode'")->num_rows();
    		$no_hp_siswa = $this->db->query("SELECT id_student FROM student WHERE hp_siswa='$hp_siswa' AND NOT id_student='$kode'")->num_rows();
    		$no_hp_ortu = $this->db->query("SELECT id_student FROM student WHERE hp_orang_tua='$hp_orang_tua' AND NOT id_student='$kode'")->num_rows();
   		    if ($cek_no_induk > 0) {
	 			$msg = "Data gagal tersimpan, Adanya Duplikat No Induk. !!!";
				$this->session->set_userdata('error', $msg);
				return false; 		
	    	}
   		    if ($cek_nisn > 0) {
	 			$msg = "Data gagal tersimpan, Adanya Duplikat NISN. !!!";
				$this->session->set_userdata('error', $msg);
				return false;	
	    	}
   		    if ($no_hp_ortu > 0) {
	 			$msg = "Data gagal tersimpan, Adanya Duplikat No HP Ortu. !!!";
				$this->session->set_userdata('error', $msg);
				return false; 		
	    	}
    		$sql = "UPDATE student SET no_induk='$no_induk', nisn='$nisn', nama_murid='$nama_murid', tempat_lahir='$tempat_lahir', jenis_kelamin='$jenis_kelamin', id_agama='$agama', id_kelas='$kelas', alamat='$alamat', nama_ibu='$nama_ibu', nama_ayah='$nama_ayah', hp_siswa='$hp_siswa', hp_orang_tua='$hp_orang_tua', password_student='$password_student' WHERE id_student='$kode'";
    	}
		$simpan = $this->db->query($sql);
		if ($simpan == 1) {
			$msg = "Data berhasil tersimpan !!!";
			$this->session->set_userdata('msg', $msg);
			return false;
		}else{
			$msg = "Data gagal tersimpan !!!";
			$this->session->set_userdata('error', $msg);
			return false;
		}
	}

	public function prosesuploadsiswa(){
		$row = $_POST['data'];
		//PECAH LINE
		$get_line = explode("\n", $row);
        	//MAKE ARRAY NULL
		$make_loop_array = array();
		//BEGIN GET LINE
		foreach ($get_line as $key) {
			//BEGIN GET COLUMN
			$get_per_row = explode("\t", $key);
			if (!empty($get_per_row[0])) {
				//HARGA RUPIAH atau DOLAR
				$kelas = $this->db->query("SELECT id_kelas FROM kelas WHERE ket_kelas='$get_per_row[7]'")->row();
				$agama = $this->db->query("SELECT id_agama FROM agama WHERE ket_agama='$get_per_row[6]'")->row();
				if (empty($kelas->id_kelas)) {
					$msg = "Kelas tidak ditemukan, mohon masukan data yang sesuai.";
					$this->session->set_userdata('error', $msg);
					return false;
				}
				if (empty($agama->id_agama)) {
					$msg = "Agama tidak ditemukan, mohon masukan data yang sesuai.";
					$this->session->set_userdata('error', $msg);
					return false;
				}

				if (!is_numeric($get_per_row[0])) {
					$msg = "No Induk harus angka! mohon masukan data yang sesuai.";
					$this->session->set_userdata('error', $msg);
					return false;
				}
				if (!is_numeric($get_per_row[1])) {
					$msg = "NISN harus angka! mohon masukan data yang sesuai.";
					$this->session->set_userdata('error', $msg);
					return false;
				}

				$pch_tgl_lahir = explode('/', $get_per_row[5]);
				$jml_tgl_lahir = count($pch_tgl_lahir);
				if ($jml_tgl_lahir == 3) {
					 $tgl_lahir = $pch_tgl_lahir[2].'-'.$pch_tgl_lahir[0].'-'.$pch_tgl_lahir[1];
				}else{
					$msg = "Format tanggal terima salah, mohon masukan data yang sesuai.";
					$this->session->set_userdata('error', $msg);
					return false;
				}

				//MAKE PASSWORD
				$password = password_hash($get_per_row[0], PASSWORD_DEFAULT);
				//PROSES UPLOAD
				$import = array('no_induk' => $get_per_row[0],
			 			'nisn' => $get_per_row[1],
			 			'nama_murid' => $get_per_row[2],
			 			'tempat_lahir' => $get_per_row[4],
			 			'tgl_lahir' => $tgl_lahir,
			 			'jenis_kelamin' => $get_per_row[3],
			 			'id_agama' => $agama->id_agama,
			 			'id_kelas' => $kelas->id_kelas,
			 			'alamat' => $get_per_row[8],
			 			'nama_ibu' => $get_per_row[10],
			 			'nama_ayah' => $get_per_row[11],
			 			'hp_siswa' => $get_per_row[9],
			 			'hp_orang_tua' => $get_per_row[12],
			 			'password_student' => $password
			 		);
        		//MAKE ARRAY NULL to UPLOAD
				$make_loop_array[] = $import;
			}
			//END GET COLUMN
		}
		//END GET LINE

		//PROSES UPLOAD DAN CEK STATUS UPLOAD
		$duplikat=0;
        $failed=0;
        $success=0;
        $offset = 0;
        foreach ($make_loop_array as $key) {
          // //CEK DUPLIKAT NO INDUK
          $induk= $this->db->query("SELECT no_induk FROM student WHERE no_induk='$key[no_induk]'")->num_rows();
          $nisn = $this->db->query("SELECT nisn FROM student WHERE nisn='$key[nisn]'")->num_rows();
          $hportu=$this->db->query("SELECT hp_orang_tua FROM student WHERE hp_orang_tua='$key[hp_orang_tua]'")->num_rows();
          $str_offset = $induk.'!_.-._!'.$nisn.'!_.-._!'.$hportu.'!_.-._!'.$offset++;
          //UNSET FROM LOOPING

          $pch = explode('!_.-._!', $str_offset);
          	if ($pch[0] == 1 || $pch[1] == 1 || $pch[2] == 1) {
              $duplikat++;
              //OFFSET
              unset($make_loop_array[$pch[3]]);
           }
		}

		$cek_duplikat = count($make_loop_array);
		if ($cek_duplikat > 0) {
			//INSERT MULTIPLE ARRAY
			$arr = $this->db->insert_batch('student', $make_loop_array);
			if ($arr==0) {
	       		$failed = $arr;
			}else{
	        	$success = $arr;
			}
		}

		//MESSAGE BOX
	    $msg = COUNT($make_loop_array)." Berhasil, ".$duplikat." duplikat dan ".$failed." Gagal di unggah.";
	    $this->session->set_userdata('msg', $msg);
	}	

    public function simpanpos_keu(){
    	$nama_pos = $_POST['nama_pos'];
    	$keterangan= $_POST['keterangan'];
    	$kode = $_POST['kode'];

    	if (empty($kode)) {
    		$cek_insert = $this->db->query("SELECT id_pos FROM pos_keuangan WHERE nama_pos='$nama_pos'")->num_rows();
		    if ($cek_insert > 0) {
	 			$msg = "Data gagal tersimpan, Adanya Duplikat data !!!";
				$this->session->set_userdata('error', $msg);
				return false; 		
	    	}
    		$sql = "INSERT INTO pos_keuangan (id_pos, nama_pos, ket_pos) VALUES (NULL,'$nama_pos','$keterangan')";
    	}else{
    		$cek_update = $this->db->query("SELECT id_pos FROM pos_keuangan WHERE nama_pos='$nama_pos' AND NOT id_pos='$kode'")->num_rows();
   		    if ($cek_update > 0) {
	 			$msg = "Data gagal tersimpan, Adanya Duplikat data !!!";
				$this->session->set_userdata('error', $msg);
				return false; 		
	    	}
    		$sql = "UPDATE pos_keuangan SET ket_pos='$keterangan', nama_pos='$nama_pos' WHERE id_pos='$kode'";
    	}
		$simpan = $this->db->query($sql);
		if ($simpan == 1) {
			$msg = "Data berhasil tersimpan !!!";
			$this->session->set_userdata('msg', $msg);
			return false;
		}else{
			$msg = "Data gagal tersimpan !!!";
			$this->session->set_userdata('error', $msg);
			return false;
		}
    }
    public function hapuspos_keu(){
    	$id=$_POST['id'];
    	
    	$cek =  $this->db->query("SELECT id_pos FROM jenis_pembayaran WHERE id_pos='$id'")->num_rows();
    	if ($cek > 0) {
 			$msg = "Data saling terkait tidak bisa dihapus!";
			$this->session->set_userdata('error', $msg);
			return false;
    	}

		$hapus = $this->db->query("DELETE FROM pos_keuangan WHERE id_pos = '$id'");
		if ($hapus == 1) {
			$msg = "Data berhasil terhapus !!!";
			$this->session->set_userdata('msg', $msg);
			return false;
		}else{
			$msg = "Data gagal terhapus !!!";
			$this->session->set_userdata('error', $msg);
			return false;
		}
    }

    public function simpanjenispembayaran(){
    	$pos = $_POST['pos'];
    	$tahun_ajaran= $_POST['tahun_ajaran'];
    	$tipe = $_POST['tipe'];
    	$kode = $_POST['kode'];

    	if (empty($kode)) {
    		$cek_insert = $this->db->query("SELECT id_jp FROM jenis_pembayaran WHERE id_pos='$pos'")->num_rows();
		    if ($cek_insert > 0) {
	 			$msg = "Data gagal tersimpan, Adanya Duplikat data !!!";
				$this->session->set_userdata('error', $msg);
				return false; 		
	    	}
    		$sql = "INSERT INTO jenis_pembayaran (id_jp, id_pos, id_tipe, id_tahun) VALUES (NULL,'$pos','$tipe','$tahun_ajaran')";
    	}else{
    		$cek_update = $this->db->query("SELECT id_jp FROM jenis_pembayaran WHERE id_pos='$pos' AND NOT id_jp='$kode'")->num_rows();
   		    if ($cek_update > 0) {
	 			$msg = "Data gagal tersimpan, Adanya Duplikat data !!!";
				$this->session->set_userdata('error', $msg);
				return false; 		
	    	}
    		$sql = "UPDATE jenis_pembayaran SET id_pos='$pos', id_tipe='$tipe', id_tahun='$tahun_ajaran' WHERE id_jp='$kode'";
    	}
		$simpan = $this->db->query($sql);
		if ($simpan == 1) {
			$msg = "Data berhasil tersimpan !!!";
			$this->session->set_userdata('msg', $msg);
			return false;
		}else{
			$msg = "Data gagal tersimpan !!!";
			$this->session->set_userdata('error', $msg);
			return false;
		}
    }
    public function hapusjp(){
    	$id=$_POST['id'];

    	$cek =  $this->db->query("SELECT id_jp FROM regis_transaksi WHERE id_jp='$id'")->num_rows();
    	if ($cek > 0) {
 			$msg = "Data saling terkait tidak bisa dihapus!";
			$this->session->set_userdata('error', $msg);
			return false;
    	}

		$hapus = $this->db->query("DELETE FROM jenis_pembayaran WHERE id_jp = '$id'");
		if ($hapus == 1) {
			$msg = "Data berhasil terhapus !!!";
			$this->session->set_userdata('msg', $msg);
			return false;
		}else{
			$msg = "Data gagal terhapus !!!";
			$this->session->set_userdata('error', $msg);
			return false;
		}
    }

    public function proses_regis(){
    	$id_student = $_POST['siswa'];
    	$id_jenis_pem = $_POST['jp'];
    	if (!empty($_POST['beasiswa'])) {
	    	$beasiswa = $_POST['beasiswa'];
    	}else{
	    	$beasiswa = '0';
    	}

		if (empty($_POST['tarif_bebas'])) {
			//PEMBAYARAN non bebas
	    	$tarif_sama = $_POST['tarif_sama'];
    		$tarif_bulan = $_POST['bulan'];

		    	//UPDATE
				$cek_regis = $this->db->query("SELECT id_jp FROM regis_transaksi WHERE id_student='$id_student' AND id_jp='$id_jenis_pem'")->num_rows();
				if ($cek_regis > 12) {
		 			$msg = "Data gagal diperbarui, adanya duplikat data !!!";
					$this->session->set_userdata('error', $msg);
					return false; 		
		    	}

			    $cek_array_bulan = count($tarif_bulan);
				$cek_offset_pem_11 = implode('', explode(',', substr($tarif_bulan[0], 3)));
			    if (!empty($cek_offset_pem_11)) {
			    	//TARIF BULAN
			    	// $arr = array();
			    	for ($i=0; $i < $cek_array_bulan; $i++) {
		    			$id_bulan = $i+1;
						$biaya_implode_bln = implode('', explode(',', substr($tarif_bulan[$i], 3)));
				    	$id_regis = $this->db->query("SELECT id_regis FROM regis_transaksi WHERE id_student='$id_student' AND id_jp='$id_jenis_pem' AND id_bulan='$id_bulan'")->row();

				    	$sql = "UPDATE regis_transaksi SET id_beasiswa='$beasiswa', id_bulan='$id_bulan', biaya='$biaya_implode_bln' WHERE id_regis='$id_regis->id_regis'";
				    	// echo "string";
				    	$this->db->query($sql);
				    	echo $biaya_implode_bln;
			    	}
			    	// print_r($arr);
			    	// //for ($i=0; $i < count($arr); $i++) { 
			    	// 	$this->db->query($arr[0]);
			    	// 	$this->db->query($arr[]);
			    	// //}

			  		$msg = "Data Berhasil diperbarui !!!";
					$this->session->set_userdata('error', $msg);
					return false; 
			    }else{
			    	//TARIF SAMA
					$biaya_implode_sama = implode('', explode(',', substr($tarif_sama, 3)));
			    	for ($i=0; $i < 12; $i++) {
		    			$id_bulan = $i+1;
				    	$id_regis = $this->db->query("SELECT id_regis FROM regis_transaksi WHERE id_student='$id_student' AND id_jp='$id_jenis_pem' AND id_bulan='$id_bulan'")->row();

				    	$sql = "UPDATE regis_transaksi SET id_beasiswa='$beasiswa', id_bulan='$id_bulan', biaya='$biaya_implode_sama' WHERE id_regis='$id_regis->id_regis'";
				    	
				    	$insert = $this->db->query($sql);
			    	}
			    	$msg = "Data Berhasil diperbarui !!!";
					$this->session->set_userdata('error', $msg);
					return false; 
			    }
	    		//UPDATE
			}else{
				//PEMBAYARAN bebas
				$id_regis = $this->db->query("SELECT id_regis FROM regis_transaksi WHERE id_student='$id_student' AND id_jp='$id_jenis_pem'")->row();

				$biaya_tarif_bebas = implode('', explode(',', substr($_POST['tarif_bebas'], 3)));
			    $sql = "UPDATE regis_transaksi SET id_beasiswa='$beasiswa', biaya='$biaya_tarif_bebas' WHERE id_regis='$id_regis->id_regis'";
		    	$insert = $this->db->query($sql);
		    	if ($insert > 0) {
			    	$msg = "Regis pembayaran bebas berhasil tersimpan !!!";
					$this->session->set_userdata('msg', $msg);
					return false;
	    		}
			}
    	}

	public function pencarian_kelas(){
		$id = $_POST['id'];
	    $this->session->set_userdata('kelas', $id);
	    $kelas = $this->session->userdata('kelas');
	    if (isset($kelas)) {
	    	echo "berhasil";
	    }else{
	    	echo "Koneksi Timed Out, Please Try Again !!!";
	    }
	}

    public function add_regis(){
    	$id_student = $_POST['siswa'];
    	$id_jenis_pem = $_POST['jp'];

    	if (!empty($_POST['beasiswa'])) {
	    	$beasiswa = $_POST['beasiswa'];
    	}else{
	    	$beasiswa = '0';
    	}

		if (empty($_POST['tarif_bebas'])) {
			//PEMBAYARAN non bebas
	    	$tarif_sama = $_POST['tarif_sama'];
    		$tarif_bulan = $_POST['bulan'];

    		$cek_student = $this->db->query("SELECT id_student FROM student WHERE id_student='$id_student'")->num_rows();
    		if ($cek_student > 1) {
	 			$msg = "Data gagal tersimpan, siswa/i tidak ditemukan !!!";
	 			echo $msg;
				$this->session->set_userdata('error', $msg);
				return false; 		
	    	}
    		$cek_jenis_pem = $this->db->query("SELECT id_jp FROM jenis_pembayaran WHERE id_jp='$id_jenis_pem'")->num_rows();
    		if ($cek_jenis_pem > 1) {
	 			$msg = "Data gagal tersimpan, jenis pembayaran tidak ditemukan !!!";
	 			echo $msg;
				$this->session->set_userdata('error', $msg);
				return false; 		
	    	}
    		//CEK Regis Transaksi
    		$cek_regis = $this->db->query("SELECT id_jp FROM regis_transaksi WHERE id_student='$id_student' AND id_jp='$id_jenis_pem'")->num_rows();
    		if ($cek_regis > 1) {
	 			$msg = "Data gagal tersimpan, Transaksi siswa/i sudah didaftarkan !!!";
	 			echo $msg;
				$this->session->set_userdata('error', $msg);
				return false; 		
	    	}
			
			$cek_array_bulan = count($tarif_bulan);	
			$biaya_bln_sama = implode('', explode(',', substr($tarif_sama, 3)));
		    if (!empty($biaya_bln_sama) ) {
		    	//LOOP NOT ARRAY
		    	for ($i=0; $i < $cek_array_bulan; $i++) {
	    			$id_bulan = $i+1;
	    			$sql = "INSERT INTO regis_transaksi (id_regis, id_student, id_beasiswa, id_jp, id_bulan, biaya) VALUES (NULL,'$id_student','$beasiswa','$id_jenis_pem', '$id_bulan', '$biaya_bln_sama')";
	    			$insert = $this->db->query($sql);
		    	}
	 	    	if ($insert > 0) {
		        	$msg = "Regis bulanan berhasil tersimpan !!!";
					$this->session->set_userdata('msg', $msg);
					return false;
    			}
		    }else{
		    	for ($i=0; $i < $cek_array_bulan; $i++) {
					$biaya_implode_beda = implode('', explode(',', substr($tarif_bulan[$i], 3)));
	    			$id_bulan = $i+1;
		     		$sql = "INSERT INTO regis_transaksi (id_regis, id_student, id_beasiswa, id_jp, id_bulan, biaya) VALUES (NULL,'$id_student','$beasiswa','$id_jenis_pem', '$id_bulan', '$biaya_implode_beda')";
	    			$insert = $this->db->query($sql);
	     		}
	 	    	if ($insert > 0) {
		        	$msg = "Regis bulanan berhasil tersimpan !!!";
					$this->session->set_userdata('msg', $msg);
					return false;
    			}
		    }
		}else{
			//PEMBAYARAN bebas
			$biaya_tarif_bebas = implode('', explode(',', substr($_POST['tarif_bebas'], 3)));
		    $sql = "INSERT INTO regis_transaksi (id_regis, id_student, id_beasiswa, id_jp, biaya) VALUES (NULL,'$id_student','$beasiswa','$id_jenis_pem', '$biaya_tarif_bebas')";
	    	$insert = $this->db->query($sql);
	    	if ($insert > 0) {
		    	$msg = "Regis pembayaran bebas berhasil tersimpan !!!";
				$this->session->set_userdata('msg', $msg);
				return false;
    		}
		}
}
///ADD


    public function paid_bln(){
    	$id = $_POST['id'];
    	$bulan = $_POST['bulan'];
		$total_beasiswa = $_POST['total_beasiswa_bln'];

    	$tahun_ajaran = DATE('Y');
    	$no_transaksi = $this->db->query("SELECT regis_transaksi.no_transaksi FROM regis_transaksi 
				INNER JOIN jenis_pembayaran ON jenis_pembayaran.id_jp=regis_transaksi.id_jp
				INNER JOIN tahun_ajaran ON tahun_ajaran.id_tahun=jenis_pembayaran.id_tahun
				WHERE tahun_ajaran.ket_tahun_ajaran LIKE '%$tahun_ajaran%'
				ORDER BY regis_transaksi.no_transaksi DESC")->row();
    	$no = $no_transaksi->no_transaksi + 1;

    	$update = $this->db->query("UPDATE regis_transaksi SET status_bayar = '1', date_bayar=NOW(), no_transaksi='$no', paid='$total_beasiswa' WHERE id_regis='$id'");

    	if ($update==1) {
    		$msg = "Pembayaran bulan ".$bulan." sukses dibayar !!!";
			$this->session->set_userdata('msg', $msg);
			return false;
    	}else{
    		$msg = "Pembayaran bulan ".$bulan." gagal dibayar !!!";
			$this->session->set_userdata('error', $msg);
			return false;
    	}
    }

    public function unpaid_bln(){
    	$id = $_POST['id'];
    	$bulan = $_POST['bulan'];
		$total_beasiswa = $_POST['total_beasiswa'];

    	$update=$this->db->query("UPDATE regis_transaksi SET status_bayar = '0',date_bayar='',no_transaksi='', paid='' WHERE id_regis='$id'");
    	if ($update==1) {
    		$msg = "Pembayaran bulan ".$bulan." telah dibatalkan !!!";
			$this->session->set_userdata('msg', $msg);
			return false;
    	}else{
    		$msg = "Pembayaran bulan ".$bulan." gagal dibatalkan !!!";
			$this->session->set_userdata('error', $msg);
			return false;
    	}
    }

    public function paid_bebas(){
    	$id = $_POST['id'];
    	$sisa_bayar = $_POST['sisa'];
		$nominal = $_POST['nominal'];
		$nama_pos = $_POST['nama_pos'];
		$total_tagihan= $_POST['total_pot'];
		if ($nominal=='') {
    		$msg = "Nominal pembayaran harus diisi.";
			$this->session->set_userdata('error', $msg);
			return false;
		}elseif ($nominal > $sisa_bayar) {
    		$msg = "Pembayaran tagihan melebihi.";
			$this->session->set_userdata('error', $msg);
			return false;
		}

    	$tahun_ajaran = DATE('Y');
    	$no_transaksi = $this->db->query("SELECT no_transaksi FROM regis_transaksi 
				WHERE date_bayar LIKE '%$tahun_ajaran%'
				ORDER BY no_transaksi DESC")->row();

    	$no = $no_transaksi->no_transaksi + 1;
    	$get_paid = $this->db->query("SELECT paid FROM regis_transaksi WHERE id_regis='$id'")->row();
    	$paid_update = $get_paid->paid + $nominal;
    	//CEK PAID TIDAK SAMA
    	$sql="UPDATE regis_transaksi SET status_bayar='1', date_bayar=NOW(), no_transaksi='$no', paid='$paid_update' WHERE id_regis='$id'";
    	$update = $this->db->query($sql);

    	if ($update==1) {
    		$msg = "Pembayaran ".$nama_pos." sukses dibayar !!!";
			$this->session->set_userdata('msg', $msg);
			return false;
    	}else{
    		$msg = "Pembayaran ".$nama_pos." gagal dibayar !!!";
			$this->session->set_userdata('error', $msg);
			return false;
    	}
    }

    public function unpaid_bebas(){
    	$id = $_POST['id'];
    	$nama_pos = $_POST['nama_pos'];

	   	$update=$this->db->query("UPDATE regis_transaksi SET status_bayar = '0', date_bayar='', no_transaksi='', paid='' WHERE id_regis='$id'");
   		if ($update==1) {
    		$msg = "Pembayaran ".$bebas->nama_pos." telah dibatalkan !!!";
			$this->session->set_userdata('msg', $msg);
			return false;
    	}else{
    		$msg = "Pembayaran ".$bebas->nama_pos." gagal dibatalkan !!!";
			$this->session->set_userdata('error', $msg);
			return false;
    	}
    }

    public function pencarian_pembayaran(){
    	$id = $_POST['id'];
    	$this->session->set_userdata('pencarian_noinduk', $id);
    }

    public function naik_kelas(){
    	$id_student = $_POST['id'];
    	$id_kelas_baru = $_POST['dari_kelas'];

    	if (count($id_student) == 0) {
    	    	$msg = "Pilih siswa/i yang akan naik tingkat.";
				$this->session->set_userdata('error', $msg);
				return false;	
    	}

    	if ($id_kelas_baru == '-Pilih Kelas-') {
    	    	$msg = "Naik Ke Kelas* masih kosong.";
				$this->session->set_userdata('error', $msg);
				return false;	
    	}

    	for ($i=0; $i < count($id_student); $i++) { 
    		$sql = "UPDATE student SET id_kelas='$id_kelas_baru' WHERE id_student='$id_student[$i]'";
    		$this->db->query($sql);
    	}

    	$msg = "Proses pemindahan kelas selesai";
    	$this->session->unset_userdata('pencarian_noinduk');
		$this->session->set_userdata('msg', $msg);
		return false;
    }

    public function kelulusan(){
    	$id_student = $_POST['id'];
    	$id_kelas_baru = $_POST['kelulusan'];

    	if (count($id_student) == 0) {
    	    	$msg = "Pilih siswa/i yang akan naik tingkat.";
				$this->session->set_userdata('error', $msg);
				return false;	
    	}

    	if ($id_kelas_baru == '1') {
    		$stat = 'Kelulusan';
    	}elseif ($id_kelas_baru == '2') {
    		$stat = 'Pindah kelas';
    	}elseif ($id_kelas_baru == '3') {
    		$stat = 'DROP OUT';
    	}

    	for ($i=0; $i < count($id_student); $i++) { 
    		$sql = "UPDATE student SET status_murid='$id_kelas_baru' WHERE id_student='$id_student[$i]'";
    		$this->db->query($sql);
    	}

    	$msg = "Proses ".$stat." siswa/i selesai";
    	$this->session->unset_userdata('pencarian_noinduk');
		$this->session->set_userdata('msg', $msg);
		return false;
    }

    public function batalkan_kelulusan(){
    	$id_student = $_POST['id'];

    	for ($i=0; $i < count($id_student); $i++) { 
    		$sql = "UPDATE student SET status_murid='0' WHERE id_student='$id_student'";
    		$this->db->query($sql);
    	}

    	$msg = "Proses kelulusan siswa/i dibatalkan";
		$this->session->set_userdata('msg', $msg);
		return false;
    }

	public function hapusregispem(){
		$stu= $_POST['stu'];
		$jp = $_POST['jp'];

    	$sql = "DELETE FROM `regis_transaksi` WHERE `id_student`='$stu' AND id_jp='$jp'";
    	echo $sql;
    	$delete = $this->db->query($sql);

    	if ($delete	== 1) {
    		$msg = "Regis pembayaran siswa/i telah dihapus.";
			$this->session->set_userdata('msg', $msg);
			return false;
    	}else{
    		$msg = "Regis pembayaran siswa/i gagal dihapus.";
			$this->session->set_userdata('error', $msg);
			return false;
    	}
	}


	public function set_sekolah(){
		$yayasan = $_POST['yayasan'];
		$nama_sekolah = $_POST['nama_sekolah'];
		$alamat_sekolah = $_POST['alamat_sekolah'];
		$kab_kota = $_POST['kab_kota'];
		$no_telp = $_POST['no_telp'];
		$email = $_POST['email'];

		$kepsek = $_POST['kepsek'];
		$nip_kepsek = $_POST['nip_kepsek'];
		$bendahara = $_POST['bendahara'];
		$nip_bendahara = $_POST['nip_bendahara'];
		
		$config['upload_path']="./asset/images";
        $config['allowed_types']='gif|jpg|png';
        $config['encrypt_name'] = TRUE;

        $this->load->library('upload', $config);
	    if($this->upload->do_upload("file")){
	        $data = array('upload_data' => $this->upload->data());
	    }
		
		$cek_gambar=$this->db->query("SELECT logo FROM sekolah WHERE id_sekolah='$_POST[kode]'")->row();
		if (!empty($data['upload_data']['file_name'])) {
			$path = './asset/images'.$cek_gambar->logo;
			unlink($path);
			$gambar = $data['upload_data']['file_name'];
		}else{
			if (empty($cek_gambar->logo)) {
				$gambar = '';
			}else{
				$gambar = $cek_gambar->logo;
				// $path = 'asset/images/'.$get_file->pict;
				// unlink($path);
			}
		}


		if (empty($_POST['kode'])) {
			$insert = $this->db->query("INSERT INTO sekolah (yayasan, nama_sekolah, alamat_sekolah, kab_kota, no_telp_sekolah, nama_email, nama_bendahara, nama_kepsek, nip_bendahara, nip_kepsek, logo) VALUES ('$yayasan', '$nama_sekolah', '$alamat_sekolah', '$kab_kota', '$no_telp', '$email', '$bendahara', '$kepsek', '$nip_bendahara', '$nip_kepsek', '$gambar')");
		}else{
			$insert = $this->db->query("UPDATE sekolah SET yayasan='$yayasan', nama_sekolah='$nama_sekolah', alamat_sekolah='$alamat_sekolah', kab_kota='$kab_kota', no_telp_sekolah='$no_telp', nama_email='$email', nama_bendahara='$bendahara', nama_kepsek='$kepsek', nip_bendahara='$nip_bendahara', nip_kepsek='$nip_kepsek', logo='$gambar' WHERE id_sekolah='$_POST[kode]'");
		}

    	if ($insert	== 1) {
    		$msg = "Data berhasil disimpan.";
			$this->session->set_userdata('msg', $msg);
			return false;
    	}else{
    		$msg = "Data gagal disimpan.";
			$this->session->set_userdata('error', $msg);
			return false;
    	}
	}

	public function simpanjurmasuk(){
		$tanggal = $_POST['tanggal'];
		$keterangan = $_POST['keterangan'];
		$biaya = $_POST['jml_biaya'];
		$jml_biaya = implode('', explode(',', substr($biaya, 3)));

		if (empty($_POST['kode'])) {
			$insert = $this->db->query("INSERT INTO jurnal_umul (tanggal_jurnal, ket_jurnal, biaya_jurnal, stat_peng_msk) VALUES ('$tanggal','$keterangan','$jml_biaya', '1')");
		}else{
			$insert = $this->db->query("UPDATE jurnal_umul SET tanggal_jurnal='$tanggal', ket_jurnal='$keterangan', biaya_jurnal='$jml_biaya', stat_peng_msk=1 WHERE id_jurnal='$_POST[kode]'");
		}

	   	if ($insert	== 1) {
    		$msg = "Data berhasil disimpan.";
			$this->session->set_userdata('msg', $msg);
			return false;
    	}else{
    		$msg = "Data gagal disimpan.";
			$this->session->set_userdata('error', $msg);
			return false;
    	}
	}

	public function hapusjurmasuk(){
		$id = $_POST['id'];
		$delete = $this->db->query("DELETE FROM jurnal_umul WHERE id_jurnal='$id'");
	   	if ($delete	== 1) {
    		$msg = "Jurnal masuk berhasil dihapus.";
			$this->session->set_userdata('msg', $msg);
			return false;
    	}else{
    		$delete = "Jurnal masuk gagal dihapus.";
			$this->session->set_userdata('error', $msg);
			return false;
    	}
	}

	public function simpanjurkeluar(){
		$tanggal = $_POST['tanggal'];
		$keterangan = $_POST['keterangan'];
		$biaya = $_POST['jml_biaya'];
		$jml_biaya = implode('', explode(',', substr($biaya, 3)));


		if (empty($_POST['kode'])) {
			$insert = $this->db->query("INSERT INTO jurnal_umul (tanggal_jurnal, ket_jurnal, biaya_jurnal, stat_peng_msk) VALUES ('$tanggal','$keterangan','$jml_biaya',2)");
		}else{
			$insert = $this->db->query("UPDATE jurnal_umul SET tanggal_jurnal='$tanggal', ket_jurnal='$keterangan', biaya_jurnal='$jml_biaya', stat_peng_msk=2 WHERE id_jurnal='$_POST[kode]'");
		}

	   	if ($insert	== 1) {
    		$msg = "Data berhasil disimpan.";
			$this->session->set_userdata('msg', $msg);
			return false;
    	}else{
    		$msg = "Data gagal disimpan.";
			$this->session->set_userdata('error', $msg);
			return false;
    	}
	}

	public function hapusjurkeluar(){
		$id = $_POST['id'];
		$delete = $this->db->query("DELETE FROM jurnal_umul WHERE id_jurnal='$id'");
	   	if ($delete	== 1) {
    		$msg = "Jurnal pengeluaran berhasil dihapus.";
			$this->session->set_userdata('msg', $msg);
			return false;
    	}else{
    		$delete = "Jurnal pengeluaran gagal dihapus.";
			$this->session->set_userdata('error', $msg);
			return false;
    	}
	}

	public function cari_lap(){
		$tgl1 = $_POST['tgl1'];
		$tgl2 = $_POST['tgl2'];
		$this->session->set_userdata('tgl1', $tgl1);
		$this->session->set_userdata('tgl2', $tgl2);
	}

	public function simpanuser(){
		$username = $_POST['username'];
		$post_password = $_POST['password'];
		$role = $_POST['role'];

		$cek_user_exist = $this->db->query("SELECT username FROM user_login WHERE username='$username'")->num_rows();
		if ($cek_user_exist == 1) {
			$msg = 'Username sudah terdaftar.';
			$this->session->set_userdata('error', $msg);
			return false;
		}
		
		$password=password_hash($post_password, PASSWORD_DEFAULT);
		if (empty($_POST['kode'])) {
			$insert=$this->db->query("INSERT INTO user_login (username,password,role) VALUES ('$username','$password','$role')");
		}else{
			if (!empty($post_password)) {
			   $insert=$this->db->query("UPDATE user_login SET username='$username',password='$password',role='$role' WHERE id_user='$_POST[kode]'");
			}else{
			   $insert=$this->db->query("UPDATE user_login SET username='$username',role='$role' WHERE id_user='$_POST[kode]'");
			}
		}

	   	if ($insert	== 1) {
    		$msg = "User berhasil disimpan.";
			$this->session->set_userdata('msg', $msg);
			return false;
    	}else{
    		$msg = "User gagal disimpan.";
			$this->session->set_userdata('error', $msg);
			return false;
    	}
	}

	public function update_pwsiswa(){
		$post_password = $_POST['password'];

		if (!empty($post_password)) {
		   $password=password_hash($post_password, PASSWORD_DEFAULT);
		   $insert=$this->db->query("UPDATE student SET password='$password' WHERE id_student='$_POST[kode]'");
		}else{
		   $insert="Tidak ada yang di perbarui.";
		}

	   	if (!empty($insert)) {
    		$msg = "User berhasil disimpan.";
			$this->session->set_userdata('msg', $msg);
			return false;
    	}else{
    		$msg = "User gagal disimpan.";
			$this->session->set_userdata('error', $msg);
			return false;
    	}
	}



//SOAL PG
	public function prosesuploasoal(){
		$kode_soal = $_POST['kode_soal'];
		$kunci_jawaban = $_POST['kunci_jawaban'];
		$soal = $_POST['soal'];
		$a = $_POST['a'];
		$b = $_POST['b'];
		$c = $_POST['c'];
		$d = $_POST['d'];

		$config['upload_path']="./asset/images/soal";
        $config['allowed_types']='gif|jpg|png';
        $config['encrypt_name'] = TRUE;

        $this->load->library('upload', $config);
	    if($this->upload->do_upload("gambar")){
	        $data1 = array('upload_data' => $this->upload->data());
	    }

		if (!empty($data1['upload_data']['file_name'])) {
			$cek_gambar=$this->db->query("SELECT gambar FROM soal WHERE id_soal='$_POST[kode]'")->row();
			$path = './asset/images/soal/'.$cek_gambar->gambar;
			unlink($path);
			$gambar = $data1['upload_data']['file_name'];
		}else{
			$cek_gambar=$this->db->query("SELECT gambar FROM soal WHERE id_soal='$_POST[kode]'")->row();
			if (empty($cek_gambar->gambar)) {
				$gambar = '';
			}else{
				$gambar = $cek_gambar->gambar;
			}
		}
		//OPSI A
	    if($this->upload->do_upload("gambar_a")){
	        $data2 = array('upload_data' => $this->upload->data());
	    }
		if (!empty($data2['upload_data']['file_name'])) {
			$cek_gambar=$this->db->query("SELECT gambar_a FROM soal WHERE id_soal='$_POST[kode]'")->row();
			$path = './asset/images/soal/'.$cek_gambar->gambar_a;
			unlink($path);
			$gambar_a = $data2['upload_data']['file_name'];
		}else{
			$cek_gambar=$this->db->query("SELECT gambar_a FROM soal WHERE id_soal='$_POST[kode]'")->row();
			if (empty($cek_gambar->gambar_a)) {
				$gambar_a = '';
			}else{
				$gambar_a = $cek_gambar->gambar_a;
			}
		}
		//OPSI B
	    if($this->upload->do_upload("gambar_b")){
	        $data3 = array('upload_data' => $this->upload->data());
	    }
		if (!empty($data3['upload_data']['file_name'])) {
			$cek_gambar=$this->db->query("SELECT gambar_b FROM soal WHERE id_soal='$_POST[kode]'")->row();
			$path = './asset/images/soal/'.$cek_gambar->gambar_b;
			unlink($path);
			$gambar_b = $data3['upload_data']['file_name'];
		}else{
			$cek_gambar=$this->db->query("SELECT gambar_b FROM soal WHERE id_soal='$_POST[kode]'")->row();
			if (empty($cek_gambar->gambar_b)) {
				$gambar_b = '';
			}else{
				$gambar_b = $cek_gambar->gambar_b;
			}
		}
		//OPSI C
	    if($this->upload->do_upload("gambar_c")){
	        $data4 = array('upload_data' => $this->upload->data());
	    }
		if (!empty($data4['upload_data']['file_name'])) {
			$cek_gambar=$this->db->query("SELECT gambar_c FROM soal WHERE id_soal='$_POST[kode]'")->row();
			$path = './asset/images/soal/'.$cek_gambar->gambar_c;
			unlink($path);
			$gambar_c = $data4['upload_data']['file_name'];
		}else{
			$cek_gambar=$this->db->query("SELECT gambar_c FROM soal WHERE id_soal='$_POST[kode]'")->row();
			if (empty($cek_gambar->gambar_c)) {
				$gambar_c = '';
			}else{
				$gambar_c = $cek_gambar->gambar_c;
			}
		}
		//OPSI D
	    if($this->upload->do_upload("gambar_d")){
	        $data5 = array('upload_data' => $this->upload->data());
	    }
		if (!empty($data5['upload_data']['file_name'])) {
			$cek_gambar=$this->db->query("SELECT gambar_d FROM soal WHERE id_soal='$_POST[kode]'")->row();
			$path = './asset/images/soal/'.$cek_gambar->gambar_d;
			unlink($path);
			$gambar_d = $data5['upload_data']['file_name'];
		}else{
			$cek_gambar=$this->db->query("SELECT gambar_d FROM soal WHERE id_soal='$_POST[kode]'")->row();
			if (empty($cek_gambar->gambar_d)) {
				$gambar_d = '';
			}else{
				$gambar_d = $cek_gambar->gambar_d;
			}
		}

		if (empty($_POST['kode'])) {
			$sql = "INSERT INTO soal (kode_soal,soal,a,b,c,d,kunci_jawaban,gambar,gambar_a,gambar_b,gambar_c,gambar_d) VALUES ('$kode_soal','$soal','$a','$b','$c','$d','$kunci_jawaban','$gambar','$gambar_a','$gambar_b','$gambar_c','$gambar_d')";
		}else{
			$sql = "UPDATE soal SET kode_soal=$kode_soal, soal='$soal', a='$a', b='$b', c='$c', d='$d', gambar_a='$gambar_a', gambar_b='$gambar_b', gambar_c='$gambar_c', gambar_d='$gambar_d', kunci_jawaban='$kunci_jawaban' WHERE id_soal='$_POST[kode]'";
		}

		$insert = $this->db->query($sql);

	   	if ($insert	== 1) {
    		$msg = "Soal berhasil disimpan.";
			$this->session->set_userdata('msg', $msg);
			return false;
    	}else{
    		$msg = "Soal gagal disimpan.";
			$this->session->set_userdata('error', $msg);
			return false;
    	}
	}

	//soal uraian
	public function prosesuploasoaluraian(){
		$kode_soal = $_POST['kode_soal'];
		$kunci_jawaban = $_POST['kunci_jawaban'];
		$soal = $_POST['soal'];

		$config['upload_path']="./asset/images/soal";
        $config['allowed_types']='gif|jpg|png';
        $config['encrypt_name'] = TRUE;

        $this->load->library('upload', $config);
	    if($this->upload->do_upload("gambar")){
	        $data = array('upload_data' => $this->upload->data());
	    }
		if (!empty($data['upload_data']['file_name'])) {
			$cek_gambar=$this->db->query("SELECT gambar FROM soal_uraian WHERE id_soal_uraian='$_POST[kode]'")->row();
			$path = './asset/images/soal/'.$cek_gambar->gambar;
			unlink($path);
			$gambar = $data['upload_data']['file_name'];
		}else{
			$cek_gambar=$this->db->query("SELECT gambar FROM soal_uraian WHERE id_soal_uraian='$_POST[kode]'")->row();
			if (empty($cek_gambar->gambar)) {
				$gambar = '';
			}else{
				$gambar = $cek_gambar->gambar;
			}
		}

		if (empty($_POST['kode'])) {
			$sql = "INSERT INTO soal_uraian (kode_soal, soal, kunci_jawaban, gambar) VALUES ('$kode_soal','$soal','$kunci_jawaban','$gambar')";
		}else{
			$sql = "UPDATE soal_uraian SET kode_soal=$kode_soal, soal='$soal', kunci_jawaban='$kunci_jawaban', gambar='$gambar' WHERE id_soal_uraian='$_POST[kode]'";
		}

		$insert = $this->db->query($sql);

	   	if ($insert	== 1) {
    		$msg = "Soal berhasil disimpan.";
			$this->session->set_userdata('msg', $msg);
			return false;
    	}else{
    		$msg = "Soal gagal disimpan.";
			$this->session->set_userdata('error', $msg);
			return false;
    	}
	}
	public function hapussoaluraian(){
    	$id=$_POST['id'];
		$cek_gambar=$this->db->query("SELECT gambar FROM soal_uraian WHERE id_soal_uraian='$id'")->row();
		$gambar = $cek_gambar->gambar;
		$path = './asset/images/soal/'.$cek_gambar->gambar;
		unlink($path);
		$hapus = $this->db->query("DELETE FROM soal_uraian WHERE id_soal_uraian='$id'");
		if ($hapus == 1) {
			$msg = "Soal berhasil terhapus !!!";
			$this->session->set_userdata('msg', $msg);
			return false;
		}else{
			$msg = "Soal gagal terhapus !!!";
			$this->session->set_userdata('error', $msg);
			return false;
		}
    }


	public function hapussoal(){
    	$id=$_POST['id'];
		$cek_gambar=$this->db->query("SELECT gambar, gambar_a, gambar_b, gambar_c, gambar_d FROM soal WHERE id_soal='$id'")->row();
		$path1 = './asset/images/soal/'.$cek_gambar->gambar;
		unlink($path1);
		
		$path2 = './asset/images/soal/'.$cek_gambar->gambar_a;
		unlink($path2);
		
		$path3 = './asset/images/soal/'.$cek_gambar->gambar_b;
		unlink($path3);
		
		$path4 = './asset/images/soal/'.$cek_gambar->gambar_c;
		unlink($path4);

		$path5 = './asset/images/soal/'.$cek_gambar->gambar_d;
		unlink($path5);
		$hapus = $this->db->query("DELETE FROM soal WHERE id_soal = '$id'");
		if ($hapus == 1) {
			$msg = "Soal berhasil terhapus !!!";
			$this->session->set_userdata('msg', $msg);
			return false;
		}else{
			$msg = "Soal gagal terhapus !!!";
			$this->session->set_userdata('error', $msg);
			return false;
		}
    }

	public function pilihkodesoal(){
		$id = $_POST['id'];
	    $this->session->set_userdata('kode_soal', $id);
	    $kode = $this->session->userdata('kode_soal');
	    if (isset($kode)) {
	    	echo "berhasil";
	    }else{
	    	echo "Koneksi Timed Out, Please Try Again !!!";
	    }
	}

	public function savejawaban(){
		$arr_jwb_pg = $_POST['jawaban'];
		$jwb_pg 	= implode(',', $arr_jwb_pg);
		$ket_page 	= $_POST['ket_page'];
		$kodesoal 	= $_POST['kodesoal'];

		//USER LOGIN
	    $login = $this->session->userdata('arr_login');
        $get_login = explode('*&*&*', $login);
        $this->data['id_user'] = $get_login[2];

        //UPDATE JAWABAN
        $update_jwb= $this->db->query("UPDATE jawaban SET $ket_page='$jwb_pg' WHERE id_student='$get_login[2]' AND kode_soal='$kodesoal'");
        if ($update_jwb > 0) {
        	echo "Berhasil";
        }else{
        	echo "Gagal";
        }
	}

	public function savejawabanuraian(){
		$arr_jwb_pg = $_POST['jawaban'];
		$jwb_pg 	= implode('[*<*]', $arr_jwb_pg);
		$kodesoal 	= $_POST['kodesoal'];

		//USER LOGIN
	    $login = $this->session->userdata('arr_login');
        $get_login = explode('*&*&*', $login);
        $this->data['id_user'] = $get_login[2];

        //UPDATE JAWABAN
        $update_jwb= $this->db->query("UPDATE jawaban_uraian SET jawaban_uraian='$jwb_pg' WHERE id_student='$get_login[2]' AND kode_soal='$kodesoal'");
        if ($update_jwb > 0) {
        	echo "Berhasil";
        }else{
        	echo "Gagal";
        }
	}

	public function update_timer(){
		$sisa_waktu = $_POST['sisa_waktu'];
		$kodesoal 	= $_POST['kodesoal'];

		//USER LOGIN
	    $login = $this->session->userdata('arr_login');
        $get_login = explode('*&*&*', $login);
        $this->data['id_user'] = $get_login[2];
		
		//UPDATE
		$this->db->query("UPDATE jawaban SET waktu_sisa='$sisa_waktu' WHERE id_student='$get_login[2]' AND kode_soal='$kodesoal'");
	}

	public function update_timer_uraian(){
		$sisa_waktu = $_POST['sisa_waktu'];
		$kodesoal 	= $_POST['kodesoal'];
		//USER LOGIN
	    $login = $this->session->userdata('arr_login');
        $get_login = explode('*&*&*', $login);
        $this->data['id_user'] = $get_login[2];
		
		//UPDATE
		$this->db->query("UPDATE jawaban_uraian SET waktu_sisa='$sisa_waktu' WHERE id_student='$get_login[2]' AND kode_soal='$kodesoal'");
	}

	public function koreksi_uraian(){

        if (empty($_POST['koreksi_nilai'])) {
	    	$checked= '0';
	 	   	$benar  = '0';
        }else{
        	$checked= $_POST['koreksi_nilai'];
	 	   	$benar  = count($checked);
        }

    	$kode_soal=$_POST['kode_soal'];
    	$id_student=$_POST['id'];
    	$get_num_soal=$this->db->query("SELECT kode_soal FROM soal_uraian WHERE kode_soal='$kode_soal'")->num_rows();    
    	$salah = $get_num_soal - $benar;
        $nilai = $benar / $get_num_soal * 100;

		$update = $this->db->query("UPDATE jawaban_uraian SET benar='$benar', salah='$salah', nilai='$nilai' WHERE id_student='$id_student' AND kode_soal='$kode_soal'");

		if ($update == 1) {
			$msg = "Soal berhasil di koreksi !!!";
			$this->session->set_userdata('msg', $msg);
			return false;
		}else{
			$msg = "Soal gagal dikoreksi !!!";
			$this->session->set_userdata('error', $msg);
			return false;
		}
    }

    public function simpanmapel(){
    	$mapel = $_POST['mapel'];
		$kelas = $_POST['kelas'];
		$durasi= $_POST['durasi'];
		$kode_soal = rand();

	    $login = $this->session->userdata('arr_login');
        $get_login = explode('*&*&*', $login);
		
        if (empty($_POST['kode'])) {
        	$sql = "INSERT INTO mata_pelajaran (id_user, mata_pelajaran, kode_soal, id_kelas, tgl_dibuat, timer) VALUES ('$get_login[2]', '$mapel', '$kode_soal', '$kelas', NOW(), '$durasi')";
        }else{
        	$sql = "UPDATE mata_pelajaran SET mata_pelajaran='$mapel', id_kelas='$kelas', timer='$durasi' WHERE id_pelajaran='$_POST[kode]'";
        }

		$insert = $this->db->query($sql);

	    if ($insert == 1) {
 			$msg = "Data berhasil tersimpan";
			$this->session->set_userdata('msg', $msg);
			return false; 		
    	}else{
    		$msg = "Data gagal tersimpan";
			$this->session->set_userdata('error', $msg);
			return false;
    	}
    }

    public function hapusmapel(){
    	$id = $_POST['id'];
    	$uraian = $this->db->query("SELECT kode_soal FROM soal_uraian WHERE kode_soal='$id'")->num_rows();
    	if ($uraian > 0) {
 			$msg = "Data saling terkait tidak bisa dihapus!";
			$this->session->set_userdata('error', $msg);
			return false;
    	}
    	$pg =  $this->db->query("SELECT kode_soal FROM soal WHERE kode_soal='$id'")->num_rows();
    	if ($pg > 0) {
 			$msg = "Data saling terkait tidak bisa dihapus!";
			$this->session->set_userdata('error', $msg);
			return false;
    	}

    	$delete = $this->db->query("DELETE FROM mata_pelajaran WHERE kode_soal='$id'");
    	if ($delete > 0) {
 			$msg = "Data berhasil dihapus!";
			$this->session->set_userdata('error', $msg);
			return false;
    	}
    }

    public function prosesuploadblog(){
		$judul  = $_POST['judul'];
		$kode_soal = $_POST['kode_soal'];

		$config['upload_path']="./asset/images/materi";
        $config['allowed_types']='gif|jpg|png';
        $config['encrypt_name'] = TRUE;
        $this->load->library('upload', $config);
	    if($this->upload->do_upload("gambar")){
	        $data = array('upload_data' => $this->upload->data());
	    }

		$cek_gambar=$this->db->query("SELECT gambar_blog FROM materi_blog WHERE id_blog='$_POST[kode]'")->row();
		if (!empty($data['upload_data']['file_name'])) {
			$path = './asset/images/materi/'.$cek_gambar->gambar_blog;
			unlink($path);
			$gambar = $data['upload_data']['file_name'];
		}else{
			if (empty($cek_gambar->gambar_blog)) {
				$gambar = '';
			}else{
				$gambar = $cek_gambar->gambar_blog;
			}
		}

		$content= $_POST['content'];
		$rand_blog = RAND();
		if (empty($_POST['kode'])) {
			$sql = "INSERT INTO materi_blog (judul_blog, gambar_blog, editor_blog,kode_soal,rand_blog) VALUES ('$judul','$gambar','$content','$kode_soal','$rand_blog')";
		}else{
			$sql = "UPDATE materi_blog SET judul_blog='$judul', gambar_blog='$gambar', editor_blog='$content', kode_soal='$kode_soal' WHERE id_blog='$_POST[kode]'";
		}

		$insert = $this->db->query($sql);
	   	if ($insert	== 1) {
    		$msg = "Materi pembelajaran berhasil diupload.";
			$this->session->set_userdata('msg', $msg);
			return false;
    	}else{
    		$msg = "Materi pembelajaran gagal diupload.";
			$this->session->set_userdata('error', $msg);
			return false;
    	}
	}

	public function hapusblog(){
    	$id=$_POST['id'];
		$cek_gambar=$this->db->query("SELECT gambar_blog FROM materi_blog WHERE id_blog='$id'")->row();
		$path = './asset/images/materi/'.$cek_gambar->gambar_blog;
		unlink($path);
		$hapus = $this->db->query("DELETE FROM materi_blog WHERE id_blog = '$id'");
		if ($hapus == 1) {
			$msg = "Materi berhasil terhapus !!!";
			$this->session->set_userdata('msg', $msg);
			return false;
		}else{
			$msg = "Gagal terhapus !!!";
			$this->session->set_userdata('error', $msg);
			return false;
		}
    }

    public function prosesuploadebook(){
		$judul  = $_POST['judul'];
		$kode_soal = $_POST['kode_soal'];
		 
		$config['upload_path']="./asset/images/ebook";
        $config['allowed_types']='gif|jpg|png|pdf|doc|docx|xls|xlsx';
        $config['encrypt_name'] = TRUE;
        $this->load->library('upload', $config);
	    if($this->upload->do_upload("gambar")){
	        $data = array('upload_data' => $this->upload->data());
	    }
		if (!empty($data['upload_data']['file_name'])) {
			$gambar = $data['upload_data']['file_name'];
		}

	    if($this->upload->do_upload("ebook")){
	        $data1 = array('upload_data' => $this->upload->data());
	    }
		if (!empty($data1['upload_data']['file_name'])) {
			$ebook = $data1['upload_data']['file_name'];
		}

		$sql = "INSERT INTO maeri_ebook (nama_ebook, gambar_ebook, kode_soal, file_ebook) VALUES ('$judul','$gambar','$kode_soal','$ebook')";

		$insert = $this->db->query($sql);
	   	if ($insert	== 1) {
    		$msg = "Materi pembelajaran berhasil diupload.";
			$this->session->set_userdata('msg', $msg);
			return false;
    	}else{
    		$msg = "Materi pembelajaran gagal diupload.";
			$this->session->set_userdata('error', $msg);
			return false;
    	}
	}

	public function hapusebook(){
    	$id=$_POST['id'];
		$cek_gambar=$this->db->query("SELECT gambar_ebook, file_ebook FROM maeri_ebook WHERE id_ebook='$id'")->row();
		$path = './asset/images/ebook/'.$cek_gambar->gambar_ebook;
		unlink($path);
		$path2 = './asset/images/ebook/'.$cek_gambar->file_ebook;
		unlink($path2);

		$hapus = $this->db->query("DELETE FROM maeri_ebook WHERE id_ebook = '$id'");
		if ($hapus == 1) {
			$msg = "Materi berhasil terhapus !!!";
			$this->session->set_userdata('msg', $msg);
			return false;
		}else{
			$msg = "Gagal terhapus !!!";
			$this->session->set_userdata('error', $msg);
			return false;
		}
    }


}
?>


