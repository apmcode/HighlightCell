<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	function __construct() {
        parent::__construct();
		date_default_timezone_set("Asia/Jakarta");
        $this->load->model('m_p');
    }

	public function index(){
		$this->load->view('login/login_page');
	}
	public function logout(){
		$this->session->unset_userdata('arr_login');
		redirect('login');
	}

	public function login(){
		$username= $_POST['username'];
		$password= $_POST['password'];
		// $role	 = $_POST['role'];
		$cek_role = $this->db->query("SELECT role FROM user_login WHERE username='$username'")->row();
		// $role = $cek_role->role;
		if (empty($cek_role->role)) {
			$cek_login_siswa = $this->db->query("SELECT id_student, no_induk, password_student FROM student WHERE no_induk='$username'")->row();
			if (empty($cek_login_siswa->no_induk)) {
				$msg = "No induk tidak ditemukan.";
				$this->session->set_userdata('error', $msg);
				echo $msg;
				return false;
			}elseif (password_verify($password, $cek_login_siswa->password_student) == 0) {
				$msg = "Password salah.";
				$this->session->set_userdata('error', $msg);
				echo $msg;
				return false;
			}else{
				$role_siswa='Siswa';
				$array_login = $cek_login_siswa->no_induk.'*&*&*'.$role_siswa.'*&*&*'.$cek_login_siswa->id_student;
				$this->session->set_userdata('arr_login', $array_login);
				$msg = "Login berhasil";
				echo 'Siswa';
				$this->session->set_userdata('msg', $msg);
				return false;
			}
		}else{
			$cek_login = $this->db->query("SELECT * FROM user_login WHERE username='$username' AND role='$cek_role->role'")->row();
			if (empty($cek_login->username)) {
				$msg = "Username tidak ditemukan.";
				$this->session->set_userdata('error', $msg);
				echo $msg;
				return false;
			}elseif (password_verify($password, $cek_login->password) == 0) {
				$msg = "Password salah.";
				$this->session->set_userdata('error', $msg);
				echo $msg;
				return false;
			}else{
				$array_login = $cek_login->username.'*&*&*'.$cek_login->role.'*&*&*'.$cek_login->id_user;
				$this->session->set_userdata('arr_login', $array_login);
				$msg_data = $cek_role->role;
				$msg = "Login berhasil";
				echo $msg_data;
				$this->session->set_userdata('msg', $msg);
				return false;
			}
		}
	}
}
?>
