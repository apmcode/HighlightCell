<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Siswa extends CI_Controller {

	function __construct() {
        parent::__construct();
        $this->load->model('m_p');

        $cek = $this->session->userdata('arr_login');
        $cek_role = explode('*&*&*', $cek);
        if ($cek_role[1] !== 'Siswa') {
            redirect('login');
            return false;
        }
    }

	public function index(){
		redirect('siswa/listsoalpg');
	}


    public function edituser(){
        $login = $this->session->userdata('arr_login');
        $get_login = explode('*&*&*', $login);
        $this->data['id_user'] = $get_login[2];

        $this->load->view('template/header');
        $this->data['tampil'] = $this->db->query("SELECT id_student, no_induk, nama_murid FROM student WHERE id_student='$get_login[2]'")->row();
        $this->load->view('pengguna/editpenggunasiswa', $this->data);
    }


    public function listsoalpg(){
        $login = $this->session->userdata('arr_login');
        $get_login = explode('*&*&*', $login);
        $this->data['id_user'] = $get_login[2];

        $id_kelas = $this->db->query("SELECT id_kelas FROM student WHERE id_student='$get_login[2]'")->row();
    	$this->data['tampil'] = $this->db->query("SELECT mata_pelajaran.mata_pelajaran, mata_pelajaran.kode_soal, user_login.username, kelas.ket_kelas, mata_pelajaran.tgl_dibuat, mata_pelajaran.timer
					FROM mata_pelajaran
					INNER JOIN user_login ON user_login.id_user=mata_pelajaran.id_user
					INNER JOIN kelas ON kelas.id_kelas=mata_pelajaran.id_kelas
                    INNER JOIN soal ON soal.kode_soal=mata_pelajaran.kode_soal
					WHERE mata_pelajaran.id_kelas='$id_kelas->id_kelas'
                    GROUP BY mata_pelajaran.kode_soal")->result_array();
        $this->load->view('template/header');
    	$this->load->view('listsoalsiswa/soalsiswa', $this->data);
    }

	public function tespg(){
        if (!$_GET['kd']) {
            $msg = "Url Invalid";
            $this->session->set_userdata('error', $msg);
            redirect('siswa/listsoalpg');
        }

        $login = $this->session->userdata('arr_login');
        $get_login = explode('*&*&*', $login);
        $this->data['id_user'] = $get_login[2];

        $session_kdsoal=$this->session->set_userdata("kdsoal", $_GET['kd']);

        //INSERT DEFAULT
       	//GET TIMER
        $cek_jawaban_user = $this->db->query("SELECT * FROM jawaban WHERE id_student='$get_login[2]' AND kode_soal='$_GET[kd]'")->row();
        $timer = $this->db->query("SELECT timer FROM mata_pelajaran WHERE kode_soal='$_GET[kd]'")->row();
		$jwb_default = "0,0,0,0,0";
        if (empty($cek_jawaban_user->id_student)) {
		    $this->db->query("INSERT INTO jawaban (waktu_sisa,kode_soal,id_student, page_1, page_2, page_3, page_4, page_5, page_6, page_7, page_8, page_9, page_10, page_11, page_12, page_13, page_14, page_15, page_16, page_17, page_18, page_19, page_20) VALUES ('$timer->timer','$_GET[kd]','$get_login[2]', '$jwb_default', '$jwb_default', '$jwb_default', '$jwb_default', '$jwb_default', '$jwb_default', '$jwb_default', '$jwb_default', '$jwb_default', '$jwb_default', '$jwb_default', '$jwb_default', '$jwb_default', '$jwb_default', '$jwb_default', '$jwb_default', '$jwb_default', '$jwb_default', '$jwb_default', '$jwb_default')");        	
        }

        $this->session->set_userdata('kd', $_GET['kd']);
        //CEK STATUS JSWABAN 
        if ($cek_jawaban_user->status_jawaban == '1') {
            $msg = 'Kamu sudah melakukan tes!';
			$this->session->set_userdata('error', $msg);
			redirect('siswa/listsoalpg');
			return false;
       	}

        $this->data['timer'] = $cek_jawaban_user->waktu_sisa;
    	$this->load->view('template/header');
    	$this->load->view('soaltes/soaltes', $this->data);
	}

    public function akhirtespg(){
        $login = $this->session->userdata('arr_login');
        $get_login = explode('*&*&*', $login);

       	$kode_soal=$this->session->userdata("kdsoal");
	    $id_student = $get_login[2];
      	
      	//CEK JAWABAN
        $get_kunci_jawaban = $this->db->query("SELECT kunci_jawaban FROM soal WHERE kode_soal='$kode_soal' ORDER BY id_soal ASC")->result_array();
        $arr_kunci_jawaban = array();
        foreach ($get_kunci_jawaban as $key) {
            $arr_kunci_jawaban[] = $key['kunci_jawaban'];            
        }

        $get_jawaban_siswa = $this->db->query("SELECT page_1, page_2, page_3, page_4, page_5, page_6, page_7, page_8, page_9, page_10, page_11, page_12, page_13, page_14, page_15, page_16, page_17, page_18, page_19, page_20 FROM jawaban WHERE id_student='$id_student' AND kode_soal='$kode_soal' ORDER BY id_jawaban ASC")->row();

        $jwb_siswa = $get_jawaban_siswa->page_1.','.$get_jawaban_siswa->page_2.','.$get_jawaban_siswa->page_3.','.$get_jawaban_siswa->page_4.','.$get_jawaban_siswa->page_5.','.$get_jawaban_siswa->page_6.','.$get_jawaban_siswa->page_6.','.$get_jawaban_siswa->page_7.','.$get_jawaban_siswa->page_8.','.$get_jawaban_siswa->page_9.','.$get_jawaban_siswa->page_10.','.$get_jawaban_siswa->page_11.','.$get_jawaban_siswa->page_12.','.$get_jawaban_siswa->page_13.','.$get_jawaban_siswa->page_14.','.$get_jawaban_siswa->page_15.','.$get_jawaban_siswa->page_16.','.$get_jawaban_siswa->page_17.','.$get_jawaban_siswa->page_18.','.$get_jawaban_siswa->page_19.','.$get_jawaban_siswa->page_20;

        $arr_jawaban_siswa = explode(',', $jwb_siswa);

        $benar=0;
        $salah=0;
        for ($i=0; $i < count($arr_kunci_jawaban); $i++) { 
            if ($arr_kunci_jawaban[$i] == $arr_jawaban_siswa[$i]) {
                $benar++;
            }else{
                $salah++;
            }
        }

        //UPDATE SKOR
        $nilai = $benar / count($arr_kunci_jawaban) * 100;
       	$update = $this->db->query("UPDATE jawaban SET benar='$benar', salah='$salah', nilai='$nilai', status_jawaban='1' WHERE id_student='$id_student' AND kode_soal='$kode_soal'");

       	if ($update == 0) {
       		$msg = 'Jawaban gagal tersimpan, Coba refresh kembali halaman';
			$this->session->set_userdata('error', $msg);
			return false;
       	}

       	//NOTIF
        $mapel = $this->db->query("SELECT mata_pelajaran FROM mata_pelajaran WHERE kode_soal='$kode_soal'")->row();
        $this->data['benar_salah']= "Jawaban Benar: ".$benar."<br>"."Jawaban Salah : ".$salah;
        $this->data['skor'] = 'Skor : '.$benar / count($arr_kunci_jawaban) * 100;
        $this->data['mapel']= 'Mata Pelajaran : '.$mapel->mata_pelajaran; 

        $this->load->view('template/header');
        $this->load->view('listsoalsiswa/hasilpg', $this->data);
    }

    public function listsoaluraian(){
        $login = $this->session->userdata('arr_login');
        $get_login = explode('*&*&*', $login);
        $this->data['id_user'] = $get_login[2];

        $id_kelas = $this->db->query("SELECT id_kelas FROM student WHERE id_student='$get_login[2]'")->row();
        $this->data['tampil'] = $this->db->query("SELECT mata_pelajaran.mata_pelajaran, mata_pelajaran.kode_soal, user_login.username, kelas.ket_kelas, mata_pelajaran.tgl_dibuat, mata_pelajaran.timer
            FROM mata_pelajaran
            INNER JOIN user_login ON user_login.id_user=mata_pelajaran.id_user
            INNER JOIN kelas ON kelas.id_kelas=mata_pelajaran.id_kelas
            INNER JOIN soal_uraian ON soal_uraian.kode_soal=mata_pelajaran.kode_soal
            WHERE mata_pelajaran.id_kelas='$id_kelas->id_kelas'
            GROUP BY mata_pelajaran.kode_soal")->result_array();

        $this->load->view('template/header');
        $this->load->view('listsoalsiswa/soalsiswauraian', $this->data);  
    }

    public function tesuraian(){
        if (!isset($_GET['kd'])) {
            $msg = "Url Invalid";
            $this->session->set_userdata('error', $msg);
            redirect('siswa/listsoaluraian');
        }
        $login = $this->session->userdata('arr_login');
        $get_login = explode('*&*&*', $login);
        $this->data['id_user'] = $get_login[2];

        $session_kdsoal=$this->session->set_userdata("kdsoal", $_GET['kd']);
        //INSERT DEFAULT
        //GET TIMER
        $cek_jawaban_user = $this->db->query("SELECT * FROM jawaban_uraian WHERE id_student='$get_login[2]' AND kode_soal='$_GET[kd]'")->row();
        $timer = $this->db->query("SELECT timer FROM mata_pelajaran WHERE kode_soal='$_GET[kd]'")->row();
        if (empty($cek_jawaban_user->id_student)) {
            $this->db->query("INSERT INTO jawaban_uraian (waktu_sisa,kode_soal,id_student) VALUES ('$timer->timer','$_GET[kd]','$get_login[2]')");
        }

        $cek_jawaban_user = $this->db->query("SELECT * FROM jawaban_uraian WHERE id_student='$get_login[2]' AND kode_soal='$_GET[kd]'")->row();
        //CEK STATUS JAWABAN 
        if ($cek_jawaban_user->status_jawaban == '1') {
            $msg = 'Kamu sudah melakukan tes!';
            $this->session->set_userdata('error', $msg);
            redirect('siswa/listsoaluraian');
            return false;
        }

        $this->data['timer'] = $cek_jawaban_user->waktu_sisa;
        $this->load->view('template/header');
        $this->load->view('soaltes/soaltesuraian', $this->data);
    }

    public function akhirtesuraian(){
        $login = $this->session->userdata('arr_login');
        $get_login = explode('*&*&*', $login);
        $kode_soal=$this->session->userdata("kdsoal");
        $id_student = $get_login[2];
        $update = $this->db->query("UPDATE jawaban_uraian SET status_jawaban='1' WHERE id_student='$id_student' AND kode_soal='$kode_soal'");
        if ($update==1) {
            $msg = "Sesi Tes uraian sudah selesai.";
            $this->session->set_userdata('msg', $msg);
            redirect('siswa/listsoaluraian');
            return false;
        }
    }

    public function listblog(){ //admin
        $login = $this->session->userdata('arr_login');
        $get_login = explode('*&*&*', $login);
        $this->data['id_user'] = $get_login[2];
        
        $this->load->view('template/header');
        $this->load->view('blog/listblog', $this->data);
    }
    public function detailblog(){
        $login = $this->session->userdata('arr_login');
        $get_login = explode('*&*&*', $login);
        $this->data['id_user'] = $get_login[2];
        $this->data['role'] = $get_login[1];
        $this->data['tampil'] = $this->db->query("SELECT * FROM materi_blog WHERE rand_blog='$_GET[id]'")->row();
        if (empty($this->data['tampil'])) {
            $msg = "Url Invalid...";
            $this->session->set_userdata('error', $msg);
            redirect('elearn/listblog');
            return false;            
        }
        $this->load->view('template/header');
        $this->load->view('blog/detailblog', $this->data);
    }
    public function listebook(){
        $login = $this->session->userdata('arr_login');
        $get_login = explode('*&*&*', $login);
        $this->data['id_user'] = $get_login[2];
        
        $this->load->view('template/header');
        $this->load->view('blog/listebook', $this->data);
    }

    public function tagihanpembayaran(){
        $login = $this->session->userdata('arr_login');
        $get_login = explode('*&*&*', $login);
        $this->data['id_user'] = $get_login[2];
        
        $this->load->view('template/header');
        $this->load->view('laporan/tagihan_siswa', $this->data);
    }
}
?>
