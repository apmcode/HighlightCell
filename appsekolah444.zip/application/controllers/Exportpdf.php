<?php
Class Exportpdf extends CI_Controller{
    
    function __construct() {
        parent::__construct();
        $this->load->library('pdf');
        date_default_timezone_set("Asia/Jakarta");
    }
    
    function formpengeluaran(){
        $get = $_GET['noform'];
        $get_no_from = $this->db->query("SELECT inv_pengeluaran.no_form, inv_pengeluaran.ket_out, dept.to_dept, inv_pengeluaran.tanggal FROM inv_pengeluaran
                                    INNER JOIN inv_stock ON inv_stock.id_stock=inv_pengeluaran.id_stock
                                    INNER JOIN dept ON dept.id_dept=inv_pengeluaran.id_dept
                                    WHERE inv_pengeluaran.no_form='$get'")->row();
        if (empty($get_no_from->no_form)) {
            redirect('tes/formpengeluaran');
        }

        $pdf = new FPDF('L','mm','A4');
        $pdf->SetMargins(11,11);
        // membuat halaman baru
        $pdf->AddPage();
        // setting jenis font yang akan digunakan
        // mencetak string 
        $pdf->Image('icon/daunbiru.png',15,7,30);
        $pdf->SetFont('Arial','B',7);
        $pdf->Ln(5);
        $pdf->Cell(273,0,'FR/FA/DBE/027/ rev.02',0,1,'R');
        $pdf->Ln(10);
        $pdf->SetFont('Arial','B',16);
        $pdf->Cell(285,0,'FORM PERMINTAAN DAN PENYERAHAN BARANG',0,1,'C');
        $pdf->Ln(10);
        $pdf->SetFont('Arial','B',7);
        $pdf->Cell(40,0,$get_no_from->to_dept.': '.$get_no_from->ket_out ,0,1,'L');
        $pdf->Ln(5);
        //$pch_no_from=explode(',', $get_no_from->no_form);
        //$pdf->Cell(40,0,'No. '.$pch_no_from[0].'/PMT/DBE/'.$pch_no_from[1] ,0,1,'L');
        $pdf->Cell(40,0,'No. '.$get_no_from->no_form ,0,1,'L');

        $originalDate = $get_no_from->tanggal;
        $newDate = date("d M Y", strtotime($originalDate));

        $pdf->Cell(273,0,'Bogor, '.$newDate,0,1,'R');
        $pdf->Ln(3);
        $pdf->SetDrawColor(000,000,000);
        $pdf->setFillColor(120,120,120);
        $pdf->setTextColor(255,255,255);

        $pdf->SetFont('Arial','B',7);
        $pdf->Cell(8,7,'No.',1,0,'C',1);
        $pdf->Cell(50,7,'Nama Barang',1,0,'C',1);
        $pdf->Cell(35,7,'Kode Barang',1,0,'C',1);
        $pdf->Cell(35,7,'Lokasi',1,0,'C',1);
        $pdf->Cell(35,7,'Dept.',1,0,'C',1);
        $pdf->Cell(50,7,'Keterangan',1,0,'C',1);
        $pdf->Cell(15,7,'Jumlah',1,0,'C',1);
        $pdf->Cell(22,7,'Harga Satuan',1,0,'C',1);
        $pdf->Cell(23,7,'Total Harga',1,1,'C',1);
        $no = 1;
        $pdf->setTextColor(000,000,000);
        $pdf->setFillColor(255,255,255);

        $cell_height=9;
        $jumlah_row = 20;
        if ($jumlah_row<10){ $row = 10-$jumlah_row;$cell= $jumlah_row+$row; }else{ $cell= $jumlah_row;}
        $no=1;

        $sql = "SELECT inv_pengeluaran.tanggal, inv_pengeluaran.no_form, inv_lokasi.lokasi, inv_stock.manufaktur, inv_stock.nama_barang, inv_stock.pict, inv_pengeluaran.qty_out,inv_pengeluaran.ket_out, dept.to_dept, inv_stock.harga_satuan
                FROM inv_stock 
                INNER JOIN inv_pengeluaran ON inv_pengeluaran.id_stock=inv_stock.id_stock
                INNER JOIN inv_lokasi ON inv_lokasi.id_lokasi=inv_stock.id_lokasi
                INNER JOIN dept ON dept.id_dept=inv_pengeluaran.id_dept WHERE inv_pengeluaran.no_form = '$get'";
        $get_detail = $this->db->query($sql)->result_array();

        foreach ($get_detail as $key) {
            $pdf->SetFont('Arial','B',7);
            $pdf->Cell(8,$cell_height, $no++, 1,0,'C',true);

            if (strlen($key['nama_barang'])>34) {
                $pdf->Multicell(50, 4.5, $key['nama_barang'], 1);
            }else{
                $pdf->Multicell(50, 9, $key['nama_barang'], 1);                
            }

            $x = $pdf->GetX();
            $y = $pdf->GetY();       
        
            $pdf->SetXY($x+58, $y-9);
            if (strlen($key['manufaktur'])>21) {
                $pdf->Multicell(35, 4.5, $key['manufaktur'] ,1);
            }else{
                $pdf->Multicell(35, 9, $key['manufaktur'], 1,'C',false);
            }
 
            $pdf->SetXY($x+93, $y-9);
            if (strlen($key['lokasi'])>21) {
                $pdf->Multicell(35, 4.5, $key['lokasi'] ,1);
            }else{
                $pdf->Multicell(35, 9, $key['lokasi'], 1,'C',false);
            }

            //$pdf->SetXY($x+118, $y-9);
            //$pdf->Multicell(15, 9, $pdf->Image('asset/images/'.$key['pict'], $pdf->GetX()+5, $pdf->GetY()+2.5, 5),  1);

            $pdf->SetXY($x+128, $y-9);
            if (strlen($key['to_dept'])>26) {
                $pdf->Multicell(35, 4.5, $key['to_dept'] ,1);
            }else{
                $pdf->Multicell(35, 9, $key['to_dept'], 1,'C',false);
            }

            $pdf->SetXY($x+163, $y-9);
            if (strlen($key['to_dept'])>34) {
                $pdf->Multicell(50, 4.5, $key['ket_out'] ,1);
            }else{
                $pdf->Multicell(50, 9, $key['ket_out'], 1,'C',false);
            }

            $pdf->SetXY($x+213, $y-9);
            $pdf->Multicell(15, 9, number_format($key['qty_out']), 1,'C',false);

            $pdf->SetXY($x+228, $y-9);
            $pdf->Multicell(22, 9, 'Rp.'.number_format($key['harga_satuan']), 1,'C',false);
            
            $pdf->SetXY($x+250, $y-9);
            $pdf->Multicell(23, 9, 'Rp.'.number_format($key['harga_satuan']), 1,'C',false);
        }

        if (count($get_detail)<10) {
            for ($i=0; $i < 10-count($get_detail); $i++) { 
                $pdf->Cell(8,$cell_height, $no++, 1,0,'C',true);

                $pdf->Multicell(50, 9, '', 1);                    

                $x = $pdf->GetX();
                $y = $pdf->GetY();       
            
                $pdf->SetXY($x+58, $y-9);
                $pdf->Multicell(35, 9, '', 1,'C',false);
     
                $pdf->SetXY($x+93, $y-9);
                $pdf->Multicell(35, 9, '', 1,'C',false);

                //$pdf->SetXY($x+118, $y-9);
                //$pdf->Multicell(15, 9, '',  1);

                $pdf->SetXY($x+128, $y-9);
                $pdf->Multicell(35, 9, '', 1,'C',false);

                $pdf->SetXY($x+163, $y-9);
                $pdf->Multicell(50, 9, '', 1,'C',false);

                $pdf->SetXY($x+213, $y-9);
                $pdf->Multicell(15, 9, '', 1,'C',false);

                $pdf->SetXY($x+228, $y-9);
                $pdf->Multicell(22, 9, '', 1,'C',false);
                
                $pdf->SetXY($x+250, $y-9);
                $pdf->Multicell(23, 9, '', 1,'C',false);
            }
        }

        $jumlah = $this->db->query("SELECT inv_pengeluaran.qty_out, inv_stock.harga_satuan FROM inv_pengeluaran
                                    INNER JOIN inv_stock ON inv_stock.id_stock=inv_pengeluaran.id_stock
                                    WHERE inv_pengeluaran.no_form='$get'")->result_array();
        $pdf->Ln(1);
        $sum = 0;
        foreach ($jumlah as $key) {
            $sum += $key['qty_out'] * $key['harga_satuan'];
        }
        $pdf->Cell(273,$cell_height, 'Total Harga: Rp.'.number_format($sum), 1,1,'R',true);

        $pdf->Ln(10);        
        $pdf->SetFont('Arial','B',7);
        $pdf->setTextColor(000,000,000);

        $pdf->Ln(5);
        $pdf->Cell(35,0,'Pemohon',0,1,'R');
        $pdf->Cell(100,0,'Dept. Head',0,1,'R');
        $pdf->Cell(170,0,'Yang Menyerahkan',0,1,'R');
        $pdf->Cell(250,0,'Mengetahui',0,1,'R');
        $pdf->Ln(20);
        $pdf->Cell(175,0,'_______________________',0,1,'R');
        $pdf->Cell(260,0,'_______________________',0,1,'R');
        $pdf->Cell(45,0,'_______________________',0,1,'R');
        $pdf->Cell(110,0,'_______________________',0,1,'R');

        //OUTPUT SET FILENAME DOWNLOAD
        $pdf->Output('I', $get.'pdf');
    }

function barcode(){
        $pdf = new FPDF('P','mm','A4');
        $pdf->SetMargins(4,4);
        $pdf->AddPage();
        $pdf->SetFont('Arial','B',6);

        $barcode = $this->db->query("SELECT manufaktur FROM inv_stock");
        $jumlah = $barcode->num_rows();
        if ($jumlah == '0') {
            $pdf->Cell(37,40, 'Data Masih Kosong, silahkan isi terlebih dahulu.', 0,'C',1);
        }else{
            $pch = $barcode->result_array();
            foreach ($pch as $key) {
            $pdf->Cell(42, 20, $pdf->Image('asset/barcode/PA43201-2474.png', $pdf->GetX(), $pdf->GetY()+3, 0, 15), 1, 0, 'C', false);
            $pdf->Cell(42, 20, $pdf->Image('asset/barcode/'.$key['manufaktur'].'.png', $pdf->GetX(), $pdf->GetY(), 0, 15), 1, 0, 'C', false);
            }
            //$pdf->Cell( 42, 20, $pdf->Image('asset/barcode/PA43201-2474.png', $pdf->GetX(), $pdf->GetY()+3, 0, 15), 1, 0, 'L', false );
        }

        $pdf->Output('I', 'Scanner');
    }

    function kwitansisiswa(){
        $pdf = new FPDF('P','mm','A4');
        $pdf->SetMargins(18,15);
        $pdf->AddPage();

        // $sekolah = $this->db->query("")->row();
        $sekolah = $this->db->query("SELECT * FROM sekolah")->row();

        $pdf->Image('./asset/images/'.$sekolah->logo,25,15,25);

        $pdf->SetFont('Arial','B',16);
        $pdf->Cell(190,7,$sekolah->nama_sekolah,0,1,'C');
        $pdf->Ln(2);

        $pdf->SetFont('Arial','',9);
        $pdf->Ln(3);
        $pdf->Cell(190,0,$sekolah->alamat_sekolah,0,1,'C');
        $pdf->Ln(5);
        $pdf->Cell(190,0,'Kecamatan '.$sekolah->nama_kecamatan.', nama_kota '.$sekolah->nama_kota, 0,1,'C');
        $pdf->Ln(5);
        $pdf->Cell(190,0,'Telepon '.$sekolah->no_telp_sekolah.', Web / Email '.$sekolah->web_email, 0,1,'C');

        //MEMEBERIKAN LINE/GARIS DENGAN MARGIN 20 (210-20) 
        $pdf->line(18,43, 210-18, 43);

        $pdf->Ln(10);

        $pdf->SetDrawColor(000,000,000);
        $pdf->setFillColor(200,200,200);
        $pdf->setTextColor(000,000,000);
        $pdf->SetFont('Arial','B',8);

        $pdf->Cell(9,8, 'No.',1,0,'C',1);
        $pdf->Cell(30,8,'Nama Siswa/i',1,0,'C',1);
        $pdf->Cell(30,8,'POS',1,0,'C',1);
        $pdf->Cell(20,8,'Bulan',1,0,'C',1); 
        $pdf->Cell(20,8,'Biaya',1,0,'C',1);
        $pdf->Cell(25,8,'Beasiswa',1,0,'C',1);
        $pdf->Cell(20,8,'Total Tagihan',1,0,'C',1);
        $pdf->Cell(20,8,'Status',1,1,'C',1);  

        $no = 1;
        $get_data = $this->db->query("
            SELECT 
            regis_transaksi.id_regis, pos_keuangan.nama_pos, pos_keuangan.ket_pos, tipe_bayar.ket_tipe,
            regis_transaksi.status_bayar, student.id_student, regis_transaksi.biaya, beasiswa.ket_beasiswa, 
            beasiswa.potongan, student.nama_murid, regis_transaksi.date_bayar, student.no_induk
            FROM regis_transaksi
            INNER JOIN student ON student.id_student=regis_transaksi.id_student
            INNER JOIN beasiswa ON beasiswa.id_beasiswa=regis_transaksi.id_beasiswa
            INNER JOIN jenis_pembayaran ON jenis_pembayaran.id_jp=regis_transaksi.id_jp
            INNER JOIN tipe_bayar ON tipe_bayar.id_tipe=jenis_pembayaran.id_tipe
            INNER JOIN pos_keuangan ON pos_keuangan.id_pos=jenis_pembayaran.id_pos
            WHERE regis_transaksi.id_student='2' AND jenis_pembayaran.id_jp='1'
        ")->result_array();
        
        $bulan = $this->db->query("SELECT nama_bulan FROM bulan")->result_array();
        $offset = 0;
        foreach ($get_data as $key) {
            $pdf->setTextColor(000,000,000);
            $pdf->setFillColor(255,255,255);

            if (!is_numeric($key['potongan'])) {
                $num = floatval($key['potongan']); 
                $persen = ($num/100)*$key['biaya'];
                $total_beasiswa_bebas = $key['biaya'] - $persen;
            }else{
                $total_beasiswa_bebas = $key['biaya'] - $key['potongan'];
            }
            
            $pdf->SetFont('Arial','',7);
            $pdf->Cell(9,8, $no++,1,0,'C',1);
            $pdf->Cell(30,8,$key['nama_murid'],1,0,'C',1);
            $pdf->Cell(30,8,$key['nama_pos'],1,0,'C',1);
            $pdf->Cell(20,8,$bulan[$offset++]['nama_bulan'],1,0,'C',1);
            $pdf->Cell(20,8,'Rp.'.number_format($key['biaya']),1,0,'C',1);
            $pdf->Cell(25,8,$key['ket_beasiswa'].'-'.$key['potongan'],1,0,'C',1);

            $pdf->Cell(20,8,'Rp.'.number_format($total_beasiswa_bebas),1,0,'C',1);
            if ($key['status_bayar'] == 1) {
                $paid = 'Paid';
            }else{
                $paid = 'Un-Paid';
            }
            $pdf->Cell(20,8, $paid, 1,1,'C',1);

        }

        //$pdf->Output();
        //OUTPUT SET FILENAME DOWNLOAD
        $pdf->Output('I',$get_data[0]['no_induk'].'-'.$get_data[0]['nama_murid'].'pdf');
    }



    function detailpembayaran(){
        $pdf = new FPDF('P','mm','A4');
        $pdf->SetMargins(18,15);
        $pdf->AddPage();

        $sekolah = $this->db->query("SELECT * FROM sekolah")->row();
        $pdf->line(18,13, 210-18, 13);
        $pdf->Image('./asset/images/'.$sekolah->logo,21,17,15);
        $pdf->SetFont('Arial','B',20);
        $pdf->Cell(22,8,'',0,0,'L');
        $pdf->Cell(90,8,'DETAIL PEMBAYARAN',0,1,'L');

        $pdf->SetFont('Arial','',10);
        $pdf->Cell(22,5,'',0,0,'L');
        if(!empty($sekolah->yayasan)) { $yayasan=$sekolah->yayasan; }else{ $yayasan='';}
        $pdf->Cell(190,5,$yayasan,0,1,'L');

        $pdf->SetFont('Arial','B',12);
        $pdf->Cell(22,5,'',0,0,'L');
        if(!empty($sekolah->nama_sekolah)) { $nama_sekolah=$sekolah->nama_sekolah; }else{ $nama_sekolah='nama_sekolah';}
        $pdf->Cell(190,5,$nama_sekolah,0,1,'L');

        $pdf->SetFont('Arial','',8);
        $pdf->Cell(22,5,'',0,0,'L');
        if(!empty($sekolah->alamat_sekolah)) { $alamat_sekolah=$sekolah->alamat_sekolah; }else{ $alamat_sekolah='alamat_sekolah';}
        if(!empty($sekolah->kab_kota)) { $kab_kota=$sekolah->kab_kota; }else{ $kab_kota='kab_kota';}
        $pdf->Cell(190,5,$alamat_sekolah.', Kab/Kota: '.$kab_kota,0,1,'L');

        $pdf->Cell(22,3,'',0,0,'L');
        if(!empty($sekolah->no_telp_sekolah)) { $no_telp_sekolah=$sekolah->no_telp_sekolah; }else{ $no_telp_sekolah='no_telp_sekolah';}
        if(!empty($sekolah->nama_email)) { $nama_email=$sekolah->nama_email; }else{ $nama_email='nama_email';}
        $pdf->Cell(190,3,'Telepon: '.$no_telp_sekolah.', Web / Email: '.$sekolah->nama_email, 0,1,'L');

        $pdf->line(18,43, 210-18, 43);

        $pdf->Ln(5);
        $pdf->SetFont('Arial','B',8);
        $no = 1;
        $get_data = $this->db->query("
            SELECT 
            regis_transaksi.id_regis, pos_keuangan.nama_pos, pos_keuangan.ket_pos, tipe_bayar.ket_tipe, student.id_kelas,
            regis_transaksi.status_bayar, student.id_student, regis_transaksi.biaya, beasiswa.ket_beasiswa, regis_transaksi.paid,
            beasiswa.potongan, student.nama_murid, regis_transaksi.date_bayar, student.no_induk, regis_transaksi.id_bulan
            FROM regis_transaksi
            INNER JOIN student ON student.id_student=regis_transaksi.id_student
            INNER JOIN beasiswa ON beasiswa.id_beasiswa=regis_transaksi.id_beasiswa
            INNER JOIN jenis_pembayaran ON jenis_pembayaran.id_jp=regis_transaksi.id_jp
            INNER JOIN tipe_bayar ON tipe_bayar.id_tipe=jenis_pembayaran.id_tipe
            INNER JOIN pos_keuangan ON pos_keuangan.id_pos=jenis_pembayaran.id_pos
            WHERE regis_transaksi.id_regis='$_GET[reg]'
        ")->row();

        if (empty($get_data)) {
            $msg = "Url Invalid ..";
            $this->session->set_userdata('error', $msg);
            redirect('p/transaksi_pembayaran');
            return false;
        }
        
        $bulan = $this->db->query("SELECT nama_bulan FROM bulan WHERE id_bulan='$get_data->id_bulan'")->row();
        $kelas = $this->db->query("SELECT ket_kelas FROM kelas WHERE id_kelas='$get_data->id_kelas'")->row();
        $offset = 0;

            $pdf->setTextColor(000,000,000);
            $pdf->setFillColor(255,255,255);

            if (!is_numeric($get_data->potongan)) {
                $num = floatval($get_data->potongan); 
                $persen = ($num/100)*$get_data->biaya;
                $total_beasiswa_bebas = $get_data->biaya - $persen;
            }else{
                $total_beasiswa_bebas = $get_data->biaya - $get_data->potongan;
            }
            
            $pdf->SetFont('Arial','',7);
            $pdf->Cell(149,8,$get_data->no_induk.' - '.$get_data->nama_murid.' - '.$kelas->ket_kelas,0,0,'L',1);

            if ($get_data->status_bayar == 1) {
                $sisa_tagihan = $total_beasiswa_bebas-$get_data->paid;
                if (empty($sisa_tagihan)) {
                    $paid = 'LUNAS';                    
                }else{
                    $paid = 'Belum Lunas';
                }
            }else{
                $paid = 'BELUM LUNAS';
            }
            $pdf->Cell(25,8, $paid, 1,1,'C',1);


        $pdf->Ln(3);
        $pdf->SetDrawColor(000,000,000);
        $pdf->setFillColor(240,240,240);
        $pdf->setTextColor(000,000,000);

        $pdf->SetFont('Arial','B',8);
        $pdf->Cell(140,8,'Deskripsi',1,0,'C',1);
        $pdf->Cell(34,8, 'Total',1,1,'C',1);

        $pdf->setTextColor(000,000,000);
        $pdf->setFillColor(255,255,255);

        $pdf->SetFont('Arial','',8);
        if ($get_data->ket_tipe == 'Bulanan') { $ket_pem = 'bulan '.$bulan->nama_bulan;}else{ $ket_pem = 'Lain-nya'; }

        $pdf->Cell(140,8, $get_data->nama_pos.' - '.$get_data->ket_pos.' (Pembayaran ' .$ket_pem.')', 1,0,'L',1);
        $pdf->Cell(34,8, 'Rp.'.number_format($get_data->biaya),1,1,'C',1);

        $pdf->SetDrawColor(000,000,000);
        $pdf->setFillColor(240,240,240);
        $pdf->setTextColor(000,000,000);
        $pdf->Cell(140,8, 'Sub Total', 1,0,'R',1);
        $pdf->Cell(34,8, 'Rp.'.number_format($get_data->biaya),1,1,'C',1);
        $pdf->Cell(140,8, 'Beasiswa', 1,0,'R',1);
        $pdf->Cell(34,8, $get_data->ket_beasiswa,1,1,'C',1);
        $pdf->Cell(140,8, 'Potongan', 1,0,'R',1);
        $pdf->Cell(34,8, $get_data->potongan,1,1,'C',1);

        $pdf->Cell(140,8, 'Total Tagihan', 1,0,'R',1);
        $pdf->Cell(34,8, 'Rp.'.number_format($total_beasiswa_bebas),1,1,'C',1);

        $pdf->Cell(140,8, 'Jumlah Dibayarkan', 1,0,'R',1);
        $pdf->Cell(34,8, 'Rp.'.number_format($get_data->paid),1,1,'C',1);

        $pdf->Cell(140,8, 'Sisa Tagihan', 1,0,'R',1);
        $pdf->Cell(34,8, 'Rp.'.number_format($total_beasiswa_bebas - $get_data->paid),1,1,'C',1);                                            
        $pdf->Cell(140,8, 'Dibayar Pada', 1,0,'R',1);
        $pdf->Cell(34,8, $get_data->date_bayar,1,1,'C',1);

        $pdf->Ln(5);
        $pdf->setTextColor(000,000,000);
        $pdf->setFillColor(255,255,255);
        $pdf->Cell(174,8,'PDF Generated On '.DATE('d/M/Y'),0,1,'C',1);

        $pdf->Ln(10);
        $pdf->Cell(130,8,'',0,0,'C',1);
        $pdf->Cell(44,3, 'Bendahara Sekolah', 0,1,'C',1);
        $pdf->Ln(25);
        $pdf->Cell(130,4,'',0,0,'C',1);
        $pdf->Cell(44,4, $sekolah->nama_bendahara, 0,1,'C',1);
        $pdf->Cell(130,4,'',0,0,'C',1);
        $pdf->Cell(44,0.1, '', 1,1,'C',1);
        $pdf->Cell(130,4,'',0,0,'C',1);
        $pdf->Cell(44,4, 'NIP: '.$sekolah->nip_bendahara, 0,1,'C',1);
        $pdf->Output('I',$get_data->no_induk.'-'.$get_data->nama_murid.'.pdf');
    }

    function kwitansipembayaran(){
        $pdf = new FPDF('P','mm','A4');
        $pdf->SetMargins(18,15);
        $pdf->AddPage();

        $id_student= $_GET['stu'];
        $id_regis  = $_GET['reg'];

        // $sekolah = $this->db->query("")->row();
        $sekolah = $this->db->query("SELECT * FROM sekolah")->row();
        $pdf->line(18,13, 210-18, 13);
        $pdf->Image('./asset/images/'.$sekolah->logo,21,17,15);
        $pdf->SetFont('Arial','B',20);
        $pdf->Cell(125,10,'',0,0,'L');
        $pdf->Cell(45,10,'KWITANSI',1,1,'C');
        $pdf->Ln(-10);

        $pdf->SetFont('Arial','',10);
        $pdf->Cell(25,5,'',0,0,'L');
        if(!empty($sekolah->yayasan)) { $yayasan=$sekolah->yayasan; }else{ $yayasan='';}
        $pdf->Cell(190,5,$yayasan,0,1,'L');

        $pdf->SetFont('Arial','B',12);
        $pdf->Cell(25,5,'',0,0,'L');
        if(!empty($sekolah->nama_sekolah)) { $nama_sekolah=$sekolah->nama_sekolah; }else{ $nama_sekolah='nama_sekolah';}
        $pdf->Cell(190,5,$nama_sekolah,0,1,'L');

        $pdf->SetFont('Arial','',8);
        $pdf->Cell(25,5,'',0,0,'L');
        if(!empty($sekolah->alamat_sekolah)) { $alamat_sekolah=$sekolah->alamat_sekolah; }else{ $alamat_sekolah='alamat_sekolah';}
        if(!empty($sekolah->kab_kota)) { $kab_kota=$sekolah->kab_kota; }else{ $kab_kota='';}
        $pdf->Cell(190,5,$alamat_sekolah.', Kab/Kota: '.$kab_kota,0,1,'L');

        $pdf->Cell(25,3,'',0,0,'L');
        if(!empty($sekolah->no_telp_sekolah)) { $no_telp_sekolah=$sekolah->no_telp_sekolah; }else{ $no_telp_sekolah='no_telp_sekolah';}
        if(!empty($sekolah->nama_email)) { $nama_email=$sekolah->nama_email; }else{ $nama_email='nama_email';}
        $pdf->Cell(190,3,'Telepon: '.$no_telp_sekolah.', Web / Email: '.$sekolah->nama_email, 0,1,'L');

        $pdf->line(18,36, 210-18, 36);

        $ket_siswa=$this->db->query("SELECT student.no_induk, student.nama_murid, kelas.ket_kelas FROM student 
                            INNER JOIN kelas ON student.id_kelas=kelas.id_kelas WHERE student.id_student='$id_student'")->row();
        
        if (empty($ket_siswa)) {
            $msg = "Url Invalid ..";
            $this->session->set_userdata('error', $msg);
            redirect('p/transaksi_pembayaran');
            return false;
        }

        $get_id_regis =$this->db->query("SELECT no_transaksi, date_bayar FROM regis_transaksi WHERE id_regis='$id_regis'")->row();

        $pdf->Ln(5);
        $pdf->Cell(25,5, 'No. Transaksi: ',0,0,'R',0);
        $pch_date = explode('-', $get_id_regis->date_bayar);
        $pdf->Cell(90,5, 'KW-'.$get_id_regis->no_transaksi.'-'.substr($pch_date[2], 0, 2).$pch_date[1].$pch_date[0],0,0,'L',0);
        $pdf->Cell(19,5, 'No. Induk: ',0,0,'R',0);
        $pdf->Cell(40,5, $ket_siswa->no_induk,0,1,'L',0);

        $pdf->Cell(25,5, 'Tanggal: ',0,0,'R',0);
        $pdf->Cell(90,5, DATE('d/M/Y'),0,0,'L',0);
        $pdf->Cell(19,5, 'Nama Siswa: ',0,0,'R',0);
        $pdf->Cell(40,5, $ket_siswa->nama_murid,0,1,'L',0);

        $pdf->Cell(25,5, 'Waktu: ',0,0,'R',0);
        $pdf->Cell(90,5, DATE('h:i:s'),0,0,'L',0);
        $pdf->Cell(19,5, 'Kelas: ',0,0,'R',0);
        $pdf->Cell(40,5, $ket_siswa->ket_kelas,0,1,'L',0);

        $pdf->Ln(2);
        $pdf->SetDrawColor(000,000,000);
        $pdf->setFillColor(200,200,200);
        $pdf->setTextColor(000,000,000);
        $pdf->SetFont('Arial','B',8);

        $pdf->Cell(10,8, 'No',1,0,'C',1);
        $pdf->Cell(90,8,'Jenis Pembayaran',1,0,'C',1);
        $pdf->Cell(37,8,'Jumlah',1,0,'C',1);
        $pdf->Cell(37,8,'Sisa Pembayaran',1,1,'C',1); 

        $pdf->SetDrawColor(000,000,000);
        $pdf->setFillColor(255,255,255);
        $pdf->setTextColor(000,000,000);
        
        $list_tr=$this->db->query("SELECT
                        pos_keuangan.nama_pos,regis_transaksi.id_student,regis_transaksi.id_jp, beasiswa.potongan
                        FROM regis_transaksi
                        INNER JOIN jenis_pembayaran ON jenis_pembayaran.id_jp=regis_transaksi.id_jp
                        INNER JOIN pos_keuangan ON pos_keuangan.id_pos=jenis_pembayaran.id_pos
                        INNER JOIN beasiswa ON beasiswa.id_beasiswa=regis_transaksi.id_beasiswa
                        WHERE regis_transaksi.id_student='$id_student'
                        GROUP BY regis_transaksi.id_jp")->result_array();
        $no=1;
        $total_jumlah = array();
        $total_sisa = array();
        foreach ($list_tr as $key) {
            $pdf->Cell(10,8, $no++,1,0,'C',1);
            $pdf->Cell(90,8,$key['nama_pos'],1,0,'L',1);

            $jumlah=$this->db->query("SELECT SUM(biaya) FROM regis_transaksi 
                WHERE id_student='$key[id_student]' AND id_jp='$key[id_jp]'")->result_array();
            $pot = $key['potongan'];
            if (!is_numeric($pot)) {
                $num = floatval($pot); 
                $per = ($num/100)*$jumlah[0]['SUM(biaya)'];
                $total_beasiswa = $jumlah[0]['SUM(biaya)'] - $per;
            }else{
                $total_beasiswa = $jumlah[0]['SUM(biaya)'] - $pot;
            }


            $pdf->Cell(37,8,'Rp.'.number_format($total_beasiswa),1,0,'C',1);

            $sudah_bayar=$this->db->query("SELECT SUM(paid) FROM regis_transaksi 
                WHERE id_student='$key[id_student]' AND id_jp='$key[id_jp]' AND status_bayar='1'")->result_array();

            $sisa_pembayaran=$total_beasiswa-$sudah_bayar[0]['SUM(paid)'];
            $pdf->Cell(37,8,'Rp.'.number_format($sisa_pembayaran),1,1,'C',1);
            $total_sisa[] = $sisa_pembayaran;
            $total_jumlah[] = $jumlah[0]['SUM(biaya)'];
        }

        $pdf->Ln(2);
        $pdf->Cell(174,0,'',1,1,'L',1);
        $pdf->Ln(2);
        $pdf->Cell(80,8,'',0,0,'C',1); 
        $pdf->Cell(20,8,'Total',1,0,'C',1); 
        $pdf->Cell(37,8,'Rp.'.number_format(array_sum($total_jumlah)),1,0,'C',1);
        $pdf->Cell(37,8,'Rp.'.number_format(array_sum($total_sisa)),1,1,'C',1);

        $pdf->Ln(4);
        $pdf->SetFont('Arial','',10);
        $pdf->Cell(110,5,'',0,0,'L',1);
        $pdf->Cell(64,5,'Bogor,',0,1,'C',1);
        $pdf->Cell(110,5,'',0,0,'L',1);
        $pdf->Cell(64,5,'Yang Menerima',0,1,'C',1);
        $pdf->Ln(20);
        $pdf->Cell(110,5,'',0,0,'L',1);
        if(!empty($sekolah->nama_bendahara)) { $nama_bendahara=$sekolah->nama_bendahara; }else{ $nama_bendahara='';}
        $pdf->Cell(64,5,$nama_bendahara,0,1,'C',1);
        $pdf->Cell(122,5,'',0,0,'L',1);
        $pdf->Cell(39,0,'',1,1,'C',1);
        $pdf->Cell(110,5,'',0,0,'L',1);
        if(!empty($sekolah->nip_bendahara)) { $nip_bendahara=$sekolah->nip_bendahara; }else{ $nip_bendahara='';}
        $pdf->Cell(64,5,'NIP. '.$nip_bendahara,0,1,'C',1);
        $pdf->Ln(-14);
        $pdf->Cell(110,4,'Catatan:',0,1,'L',1);
        $pdf->Cell(110,4,'- Disimpan sebagai pembayaran yang sah',0,1,'L',1);
        $pdf->Cell(110,4,'- Uang yang sudah dibayarkan tidak dapat diminta kembali',0,1,'L',1);
    
       $pdf->Output('I', 'KW-'.$get_id_regis->no_transaksi.'-'.substr($pch_date[2], 0, 2).$pch_date[1].$pch_date[0].'.pdf');
    }

    function kartupembayaran(){
        $pdf = new FPDF('P','mm','A4');
        $pdf->SetMargins(18,15);
        $pdf->AddPage();

        $sekolah = $this->db->query("SELECT * FROM sekolah")->row();
        $pdf->line(18,13, 210-18, 13);
        $pdf->Image('./asset/images/'.$sekolah->logo,21,17,15);
        $pdf->SetFont('Arial','B',20);
        $pdf->Cell(174,10,'KARTU PEMBAYARAN',0,1,'C');

        $pdf->SetFont('Arial','B',12);
        if(!empty($sekolah->nama_sekolah)) { $nama_sekolah=$sekolah->nama_sekolah; }else{ $nama_sekolah='nama_sekolah';}
        $pdf->Cell(174,5,$nama_sekolah,0,1,'C');

        $pdf->SetFont('Arial','',8);
        if(!empty($sekolah->alamat_sekolah)) { $alamat_sekolah=$sekolah->alamat_sekolah; }else{ $alamat_sekolah='alamat_sekolah';}
        if(!empty($sekolah->kab_kota)) { $kab_kota=$sekolah->kab_kota; }else{ $kab_kota='kab_kota';}
        $pdf->Cell(174,5,$alamat_sekolah.', Kab/Kota: '.$kab_kota,0,1,'C');

        if(!empty($sekolah->no_telp_sekolah)) { $no_telp_sekolah=$sekolah->no_telp_sekolah; }else{ $no_telp_sekolah='no_telp_sekolah';}
        if(!empty($sekolah->nama_email)) { $nama_email=$sekolah->nama_email; }else{ $nama_email='nama_email';}
        $pdf->Cell(174,4,'Telepon: '.$no_telp_sekolah.', Web / Email: '.$sekolah->nama_email, 0,1,'C');

        $pdf->line(18,42, 210-18, 42);

        $student = $_GET['stu'];
        $ket_student = $this->db->query("SELECT student.no_induk, student.nama_murid, kelas.ket_kelas FROM student 
            INNER JOIN kelas ON kelas.id_kelas=student.id_kelas
            WHERE student.id_student='$student'")->row();

        if (empty($ket_student)) {
            $msg = "Url Invalid ..";
            $this->session->set_userdata('error', $msg);
            redirect('p/transaksi_pembayaran');
            return false;
        }

        $pdf->Ln(5);
        $pdf->SetFont('Arial','B',8);
        $pdf->Cell(25,5, 'No Induk: ',0,0,'R',0);
        $pdf->Cell(149,5,$ket_student->no_induk,0,1,'L',0);
        $pdf->Cell(25,5, 'Nama: ',0,0,'R',0);
        $pdf->Cell(149,5,$ket_student->nama_murid,0,1,'L',0);
        $pdf->Cell(25,5, 'Kelas: ',0,0,'R',0);
        $pdf->Cell(149,5,$ket_student->ket_kelas,0,1,'L',0);

        $pdf->Ln(3);

        $list_bulanan = $this->db->query("SELECT 
                        pos_keuangan.nama_pos, pos_keuangan.ket_pos,
                        regis_transaksi.status_bayar,
                        bulan.nama_bulan, regis_transaksi.biaya, beasiswa.potongan
                        FROM regis_transaksi
                        INNER JOIN student ON student.id_student=regis_transaksi.id_student
                        INNER JOIN jenis_pembayaran ON jenis_pembayaran.id_jp=regis_transaksi.id_jp
                        INNER JOIN beasiswa ON beasiswa.id_beasiswa=regis_transaksi.id_beasiswa
                        INNER JOIN tipe_bayar ON tipe_bayar.id_tipe=jenis_pembayaran.id_tipe
                        INNER JOIN pos_keuangan ON pos_keuangan.id_pos=jenis_pembayaran.id_pos
                        INNER JOIN bulan ON bulan.id_bulan=regis_transaksi.id_bulan
                        WHERE regis_transaksi.id_student='$student' AND jenis_pembayaran.id_tipe=1")->result_array();

        $pdf->SetFont('Arial','B',8);
        $pdf->Cell(68,5, 'Pembayaran Bulanan',1,0,'C',0);
        $pdf->Cell(4,6, '',0,0,'C',0);
        $pdf->Cell(102,5, 'Pembayaran Lainnya',1,1,'C',0);
        $pdf->Cell(45,6, 'Bulan',1,0,'C',0);
        $pdf->Cell(23,6, 'Bayar',1,0,'C',0);
        $pdf->Cell(4,6, '',0,0,'C',0);
        $pdf->Cell(34,6, 'Jenis',1,0,'C',0);
        $pdf->Cell(34,6, 'Bayar',1,0,'C',0);
        $pdf->Cell(34,6, 'Kurang',1,1,'C',0);

        $list_lainnya = $this->db->query("SELECT 
                        pos_keuangan.nama_pos, pos_keuangan.ket_pos,
                        regis_transaksi.status_bayar, regis_transaksi.paid,
                        regis_transaksi.biaya, beasiswa.potongan
                        FROM regis_transaksi
                        INNER JOIN student ON student.id_student=regis_transaksi.id_student
                        INNER JOIN jenis_pembayaran ON jenis_pembayaran.id_jp=regis_transaksi.id_jp
                        INNER JOIN beasiswa ON beasiswa.id_beasiswa=regis_transaksi.id_beasiswa
                        INNER JOIN tipe_bayar ON tipe_bayar.id_tipe=jenis_pembayaran.id_tipe
                        INNER JOIN pos_keuangan ON pos_keuangan.id_pos=jenis_pembayaran.id_pos
                        WHERE regis_transaksi.id_student='$student' AND jenis_pembayaran.id_tipe=2")->result_array();

        foreach ($list_lainnya as $key) {
            $pdf->Cell(72,6, '',0,0,'C',0);
            $pdf->Cell(34,6, $key['nama_pos'],1,0,'C',0);
            
            $pot = $key['potongan'];
            if (!is_numeric($pot)) {
                $num = floatval($pot); 
                $per = ($num/100)*$key['biaya'];
                $total_beasiswa_lain = $key['biaya'] - $per;
            }else{
                $total_beasiswa_lain = $key['biaya'] - $pot;
            }

            $pdf->Cell(34,6, 'Rp.'.number_format($total_beasiswa_lain),1,0,'R',0);
            $pdf->Cell(34,6, 'Rp.'.number_format(floatval($total_beasiswa_lain) - floatval($key['paid'])),1,1,'R',0);
        }

        $space=6;
        if (count($list_lainnya) > 0) {
            $enter = $space * count($list_lainnya);
        }
        $pdf->Ln(-$enter);

        foreach ($list_bulanan as $key) {
            $pdf->SetFont('Arial','B',8);
            $pdf->Cell(45,6, $key['nama_pos'].' - '.$key['nama_bulan'],1,0,'L',0);

            $pot = $key['potongan'];
            if (!is_numeric($pot)) {
                $num = floatval($pot); 
                $per = ($num/100)*$key['biaya'];
                $total_beasiswa_bln = $key['biaya'] - $per;
            }else{
                $total_beasiswa_bln = $key['biaya'] - $pot;
            }
            $pdf->Cell(23,6, 'Rp.'.number_format($total_beasiswa_bln),1,1,'R',0);
        }

        $pdf->setTextColor(000,000,000);
        $pdf->setFillColor(255,255,255);

        $pdf->SetFont('Arial','',8);
        $pdf->Ln(5);
        $pdf->setTextColor(000,000,000);
        $pdf->setFillColor(255,255,255);

        $pdf->Ln(10);
        $pdf->Cell(130,3,'',0,0,'C',1);
        $pdf->Cell(44,3, 'Bendahara Sekolah', 0,1,'C',1);
        $pdf->Ln(25);
        $pdf->Cell(130,4,'',0,0,'C',1);
        $pdf->Cell(44,4, $sekolah->nama_bendahara, 0,1,'C',1);
        $pdf->Cell(130,4,'',0,0,'C',1);
        $pdf->Cell(44,0.1, '', 1,1,'C',1);
        $pdf->Cell(130,4,'',0,0,'C',1);
        $pdf->Cell(44,4, 'NIP: '.$sekolah->nip_bendahara, 0,1,'C',1);

        $pdf->Ln(-35);
        $pdf->Cell(105,20,'',1,1,'C',1);
        $pdf->Ln(-15);
        $pdf->Cell(80,5,' 1.Kartu Ini Sebagai Tanda Pembayaran Yang Sah',0,1,'L',1);
        $pdf->Cell(80,5,' 2.Jika terdapat perbedaan pembayaran Hubungi Petugas Untuk Di cek Ulang',0,1,'L',1);




        $pdf->Output('I','contoh.pdf');
    }













}