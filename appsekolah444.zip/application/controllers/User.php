<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

	function __construct() {
        parent::__construct();
        $this->load->model('m_p');

        //Load Session
		$this->data['session']  = $this->session->userdata('diklat_sesspasial');
		$this->data['nama_and_foto'] = $this->m_p->get_nama_and_foto($this->data['session'])->row();

		//LAST ACCESS
		$session = $this->session->userdata('diklat_sesspasial');
		$this->data['last_access'] = $this->db->query("SELECT last_access FROM admin WHERE email_daftar='$session'")->row();
		
		date_default_timezone_set("Asia/Jakarta");

		//JIKA TIDAK ADA SESSION LOGIN MAKA USER AKAN DILEMPAR KEMBALI KEHALAMAN SELANJUTNYA
			if (!isset($session)) {
				
				//TAPI JIKA USER SEDANG MENGAKSES HALAMAN LOGIN DAN DAFTAR MAKA DIIJINKAN
				if (uri_string() == 'user/login') {
					return false;	
				}
				elseif(uri_string() == 'user/daftar'){
					return false;
				}
				elseif(uri_string() == 'user/buat_akun'){
					return false;
				}
				
			echo "<script>alert('Maaf anda harus login atau mendaftar dengan email dan password yang sudah anda buat.')</script>";
			echo "<script>window.location = '".site_url('user/login')."';</script>";
			return false;
		}

    }

	public function daftar()
	{	
		$this->load->view('daftar');
	}

	public function buat_akun()
	{
		$nama_lengkap = $_POST['nama_lengkap'];
		$email 		  = $_POST['email'];
		$password 	  = $_POST['password'];
		$hash_password= password_hash($password, PASSWORD_DEFAULT);

		$cek_email_terdaftar = $this->m_p->cek_email('admin', $email);
		$cek_hasil			 = $cek_email_terdaftar->num_rows();
		if ($cek_hasil > 0) {
			echo "<div style='text-align:center;font-weight:600;margin:5px;padding-top:100px'>Email Sudah terdaftar</div>";
			echo "<div style='text-align:center;font-weight:400'><a href='".site_url('user/daftar')."'>Coba daftar dengan Email lain.</a><div>";
			return false;
		}

		$data_akun	  = array('nama_lengkap' => $nama_lengkap, 'email_daftar' => $email, 'password' => $hash_password);
		$buat_akun 	  = $this->m_p->buat_akun('admin', $data_akun);
		
		//jika buat akun sukses, maka alihkan ke registrasi
		if ($buat_akun > 0) {
			redirect('user/login');
		}
	}

	public function login()
	{	
		$this->load->view('login');
	}

	public function p_login()
	{
		$email 		  = $_POST['email'];
		$password 	  = $_POST['password'];
		$cek_email_terdaftar = $this->m_p->cek_email('admin', $email);

		//jika FORM Login tidak diakses maka akan dialihkan ke login.php
		if (empty($email && $password)) {
			redirect('user/login');
		}

		//verifikasi email
		$cek_email			 = $cek_email_terdaftar->num_rows();
		$cek_password		 = $cek_email_terdaftar->row();

		if ($cek_email == 0) {
			echo "<div style='text-align:center;font-weight:400;padding-top:100px'>Email yang dimasukan salah silahkan <a href='".site_url('user/login')."'>Coba Lagi</a><div>";
			return false;
		}

		//verifikasi password
		$password_from_table = $cek_password->password;
		$verifikasi_password = password_verify($password , $password_from_table);
		//untuk membuat session berdasarkan email
		$email_from_table	 = $cek_password->email_daftar;

		if (!empty($cek_password->password)) {
			$password_from_table = $cek_password->password;
			$verifikasi_password = password_verify($password, $password_from_table);
				if ($verifikasi_password == 1) {
					//PERBARUI WAKTU KETIKA LOGIN
					$waktu	= DATE('Y-m-d H:i:s');
					$this->db->query("UPDATE admin SET last_access='$waktu' WHERE email_daftar='$email_from_table'");

					//menampilkan session berdasarkan email
					$this->session->set_userdata('diklat_sesspasial', $email_from_table);

					$session = $this->session->userdata('diklat_sesspasial');
					if ($session == 'diklat@big.go.id') {
						redirect('admin/dashboard');
					}else{
						redirect('user/dashboard');	
					}
					exit();
				}else{
					echo "<div style='text-align:center;font-weight:400;padding-top:100px'>Passsword yang dimasukan silahkan <a href='".site_url('user/login')."'>Coba Lagi</a><div>";
				}
		}
	}
	

	public function dashboard(){

		$this->data['provinsi'] = $this->db->query('SELECT * FROM provinsi')->result_array();
		$this->data['data_pendaftaran'] = $this->m_p->get_data_peserta($this->data['session'])->row();
		$this->data['rumpun_diklat'] = $this->db->query('SELECT * FROM rumpun_diklat')->result_array();
		$this->load->view('peserta', $this->data);
	}

	public function ajax_ket_pelatihan()
	{
		$pelatihan = $_POST['pelatihan'];
		$keterangan = $this->db->query("SELECT * FROM rumpun_diklat WHERE id_pelatihan='$pelatihan'")->row();
		    echo "<div class='form-group input-group'>
	            	<span class='input-group-addon'>Harga Rp.</span>
	            	<input type='text' class='form-control' name='biaya' value='".number_format($keterangan->harga_pelatihan)."' readonly required/>
            	</div>
	            <div class='form-group input-group'>
		            <span class='input-group-addon'>Durasi / Lama</span>
		            <input type='text' class='form-control' name='lama_pelatihan' id='lama_pelatihan' value='".$keterangan->hari_pelatihan."'>
		            <span class='input-group-addon'>Hari</span>
	            </div>";
	}

	public function p_daftar(){
		$nama_lengkap 		= $_POST['nama_lengkap'];
		$asal_peserta 		= $_POST['asal_peserta'];
		$jenis_kelamin		= $_POST['jenis_kelamin'];
		$tp_tgl_lahir 		= $_POST['tp_tgl_lahir'];
		$status 			= $_POST['status'];
		$no_hp 				= $_POST['no_hp'];
		$email 				= $this->session->userdata('diklat_sesspasial');
		$pendidikan_terakhir= $_POST['pendidikan_terakhir'];
		$pelatihan_khusus 	= $_POST['pelatihan_khusus'];
		$alamat_rumah 		= $_POST['alamat_rumah'];
		$nip 				= $_POST['nip'];
		$instansi_asal 		= $_POST['instansi_asal'];
		$unit_kerja 		= $_POST['unit_kerja'];
		$pangkat 			= $_POST['pangkat'];
		$jabatan 			= $_POST['jabatan'];
		$alamat_kantor 		= $_POST['alamat_kantor'];
		$tanggung_jawab 	= $_POST['tanggung_jawab'];

		$waktu	= DATE('Y-m-d H:i:s');

		//LIBRARY UPLOAD
		$config['upload_path'] = 'foto/user';
		$config['file_name']= RAND();
		$config['allowed_types'] = 'jpg|png|jpeg';    
		$config['max_size']  = '2048';    
		$config['remove_space'] = TRUE;      
		$this->load->library('upload', $config); 

	    if($this->upload->do_upload('foto')){
	    	$foto = $this->upload->data();
        	$foto_biodata = $foto['file_name'];
		}else{
			$foto_biodata = "";
		}

		//FROM AJAX PELATIHAN

		$random = str_shuffle('2345672312');;
		$data = array(	'id_daftar' => 'ID-'.$random,
						'id_prov' => $asal_peserta,
						'waktu_daftar' => $waktu,
						'nama_daftar' => $nama_lengkap,
						'jk_daftar' => $jenis_kelamin,
						'tp_tgl_daftar' => $tp_tgl_lahir,
						'instansi_daftar' => $instansi_asal,
						'unit_kerja_daftar' => $unit_kerja,
						'pangkat_daftar' => $pangkat,
						'jabatan_daftar' => $jabatan,
						'nip_daftar' => $nip,
						'status_daftar' => $status,
						'no_hp_daftar' => $no_hp,
						'email_daftar' => $email,
						'alamat_kantor_daftar' => $alamat_kantor,
						'alamat_rumah_daftar' => $alamat_rumah,
						'pendidikan_daftar' => $pendidikan_terakhir,
						'pelatihan_daftar' => $pelatihan_khusus,
						'tanggung_jawab_daftar' => $tanggung_jawab,
						'foto1' => $foto_biodata);
		$insert_peserta  = $this->m_p->insert_daftar('pen_user', $data);

		echo "<script>window.location = '".site_url('user/dashboard')."';</script>";

	}

	public function u_daftar(){
		$nama_lengkap 		= $_POST['nama_lengkap'];
		$asal_peserta 		= $_POST['asal_peserta'];
		$jenis_kelamin		= $_POST['jenis_kelamin'];
		$tp_tgl_lahir 		= $_POST['tp_tgl_lahir'];
		$status 			= $_POST['status'];
		$no_hp 				= $_POST['no_hp'];
		$email 				= $this->session->userdata('diklat_sesspasial');
		$pendidikan_terakhir= $_POST['pendidikan_terakhir'];
		$pelatihan_khusus 	= $_POST['pelatihan_khusus'];
		$alamat_rumah 		= $_POST['alamat_rumah'];
		$nip 				= $_POST['nip'];
		$instansi_asal 		= $_POST['instansi_asal'];
		$unit_kerja 		= $_POST['unit_kerja'];
		$pangkat 			= $_POST['pangkat'];
		$jabatan 			= $_POST['jabatan'];
		$alamat_kantor 		= $_POST['alamat_kantor'];
		$tanggung_jawab 	= $_POST['tanggung_jawab'];

		//LIBRARY UPLOAD
		$config['upload_path'] = 'foto/user';
		$config['file_name']= $nama_lengkap.'-'.RAND();
		$config['allowed_types'] = 'jpg|png|jpeg';    
		$config['max_size']  = '2048';    
		$config['remove_space'] = TRUE;      
		$this->load->library('upload', $config); 
		
		//JIKA ADA FOTO PADA TABLE
		$get_foto = $this->db->query("SELECT foto1 FROM pen_user WHERE email_daftar='$email'")->row();
		$foto = $get_foto->foto1;

	    if($this->upload->do_upload('foto')){
	    	//JIKA SESEORANG MELAKUKAN INPUT FOTO PADA FORM MAKA FOTO AKAN DI HAPUS
	    	if (!empty($foto)) 
			{ 	
				unlink($_SERVER['DOCUMENT_ROOT']."/codeigniter/foto/user/".$foto);
			}
	    	$foto = $this->upload->data();
        	$foto_biodata = $foto['file_name'];
		}else{
			//JIKA SESEORANG TIDAK MELAKUKAN INPUT FOTO MAKA TIDAK ADA PERUBAHAN
			$foto_biodata = $foto;
		}

$data = 'id_prov='.'"'.$asal_peserta .'" , '.
		'nama_daftar='.'"'.$nama_lengkap .'" , '.
		'jk_daftar='.'"'.$jenis_kelamin .'" , '.
		'tp_tgl_daftar='.'"'.$tp_tgl_lahir .'" , '.
		'instansi_daftar='.'"'.$instansi_asal .'" , '.
		'unit_kerja_daftar='.'"'.$unit_kerja .'" , '.
		'pangkat_daftar='.'"'.$pangkat .'" , '.
		'jabatan_daftar='.'"'.$jabatan .'" , '.
		'nip_daftar='.'"'.$nip .'" , '.
		'status_daftar='.'"'.$status .'" , '. 
		'no_hp_daftar='.'"'.$no_hp .'" , '.
		'alamat_kantor_daftar='.'"'.$alamat_kantor .'" , '.
		'alamat_rumah_daftar='.'"'.$alamat_rumah .'" , '.
		'pendidikan_daftar='.'"'.$pendidikan_terakhir .'" , '. 
		'pelatihan_daftar='.'"'.$pelatihan_khusus .'" , '.
		'tanggung_jawab_daftar='.'"'.$tanggung_jawab .'" , '. 
		'foto1='.'"'.$foto_biodata .'"';

		$this->m_p->update_daftar($data, $email);
	}



	//HALAMAN JADWAL
	public function jadwal()
	{
		$this->data['rumpun_diklat'] = $this->db->query('SELECT * FROM rumpun_diklat')->result_array();
		
		$session = $this->session->userdata('diklat_sesspasial');


		$this->data['data_jadwal'] = $this->db->query("
			SELECT rumpun_diklat.jenis_pelatihan, transaksi.pembayaran_sukses, transaksi.id_transaksi
			FROM pen_user INNER JOIN transaksi ON transaksi.id_daftar=pen_user.id_daftar
			INNER JOIN rumpun_diklat ON rumpun_diklat.id_pelatihan=transaksi.id_pelatihan
			WHERE pen_user.email_daftar='$session'
			GROUP BY rumpun_diklat.jenis_pelatihan
			ORDER BY transaksi.pembayaran_sukses DESC
		")->result_array();

		$this->load->view('jadwal', $this->data);
	}

	public function p_daftar_baru(){
		$session = $this->session->userdata('diklat_sesspasial');

		$id_daftar = $this->db->query("SELECT id_daftar FROM pen_user WHERE email_daftar='$session'")->row();
		$id = $id_daftar->id_daftar;

		$bidang_pelatihan = $_POST['bidang_pelatihan'];
		$lama_pelatihan = $_POST['ajax_lama_pelatihan'];

		$random = str_shuffle('2345672312');
		$transaksi 		  = 'TR-'.$random;
		
       for ($i=1; $i <= $lama_pelatihan; $i++) {
			$this->db->query("INSERT INTO transaksi (id_transaksi,id_pelatihan,id_daftar,pembayaran_sukses,hari) VALUES
							('$transaksi','$bidang_pelatihan','$id','0','Hari $i')");
        }

		$pembayaran 	  = 'PO-'.$random;
		$data_pembayaran  = array('id_pembayaran' => $pembayaran, 'id_transaksi' => $transaksi, 'status' => 'Belum Bayar');
		$insert_pembayaran= $this->m_p->insert_pembayaran('pembayaran', $data_pembayaran);

	}

//Hapus Jadwal Pelatihan Peserta
public function d_jadwal_pay(){
	$id_transaksi = $_GET['jd'];
	$delete = $this->m_p->hapus_jadwal_dan_pembayaran($id_transaksi);
	if ($delete > 0) {
		echo "<script>alert('Sukses Terhapus.');</script>";
		echo "<script>window.location = '".site_url('user/dashboard')."';</script>";
	}
}

	//HALAMAN PEMBAYARAN
	public function payment(){
		$this->data['cek_pembayaran'] = $this->m_p->cek_pembayaran($this->data['session'])->result_array();
		$this->load->view('pembayaran', $this->data);
	}

	public function p_pembayaran(){
		$po_pembayaran = $_POST['po_pembayaran'];
		$status_proses = 'Proses';

		//GET FOTO
		$get_foto 	= $this->db->query("SELECT foto_resi FROM pembayaran WHERE id_pembayaran='$po_pembayaran'")->row();
		$foto = $get_foto->foto_resi;
		//JIKA BUKTI FOTO SUDAH DIUPLOAD MAKA AKAN DIHAPUS
		if (!empty($foto)) 
		{ 	
			unlink($_SERVER['DOCUMENT_ROOT']."/codeigniter/foto/pembayaran/".$foto);
		}
		//LIBRARY UPLOAD
		$config['upload_path'] = 'foto/pembayaran';
		$config['file_name']= $po_pembayaran;
		$config['allowed_types'] = 'jpg|png|jpeg';    
		$config['max_size']  = '2048';    
		$config['remove_space'] = TRUE;      
		$this->load->library('upload', $config); 

	    if($this->upload->do_upload('bukti_pembayaran')){
	    	$img = $this->upload->data();
        	$bukti_bayar = $img['file_name'];
		}else{
			$bukti_bayar = "";
		}

		date_default_timezone_set("Asia/Jakarta");
		$waktu_sekarang	= DATE('Y-m-d H:i:s');

		$data 		= array('foto_resi' => $bukti_bayar , 'po_tanggal' => $waktu_sekarang, 'status' => $status_proses,);

		$update_resi= $this->m_p->update_resi('pembayaran', $data, $po_pembayaran);

		if ($update_resi > 0) {
			$this->load->view('resi_sukses', $this->data);
		} 
	}

	public function keluar(){
		$this->session->sess_destroy();
		redirect('p/index');
	}

}
?>
