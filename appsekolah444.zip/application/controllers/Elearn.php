<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Elearn extends CI_Controller {

	function __construct() {
        parent::__construct();
        $this->load->model('m_p');
        date_default_timezone_set("Asia/Jakarta");
        $cek = $this->session->userdata('arr_login');
        $cek_role = explode('*&*&*', $cek);
        if ($cek_role[1] !== 'Guru') {
            redirect('login');
            return false;
        }
    }
    
    public function index(){
        redirect('elearn/edashboard');
    }

    public function edashboard(){
        $this->load->view('template/header');
        $this->load->view('dashboard/dashboard_elearn');
    }


    public function pengguna(){
        $this->load->view('template/header');
        $this->data['tampil'] = $this->db->query("SELECT * FROM user_login WHERE role='Guru'")->result_array();
        $this->load->view('pengguna/pengguna', $this->data);
    }
    
    public function edituser(){
        $this->load->view('template/header');
        $this->data['tampil'] = $this->db->query("SELECT * FROM user_login WHERE id_user='$_GET[edituser]'")->row();
        $this->load->view('pengguna/editpengguna', $this->data);
    }


	public function addsoal(){
    	$this->load->view('template/header');
    	$this->load->view('soal/uploadsoal');
	}

	// ?editsoal=4&&page=soal
	public function editsoal(){
    	$this->load->view('template/header');
    	$this->data['tampil'] = $this->db->query("SELECT * FROM soal WHERE id_soal='$_GET[editsoal]'")->row();
    	$this->load->view('soal/uploadsoal', $this->data);
	}

	public function pilihanganda(){ //admin
        $login = $this->session->userdata('arr_login');
        $get_login = explode('*&*&*', $login);
        $this->data['id_user'] = $get_login[2];
    	
    	$this->load->view('template/header');
    	$this->load->view('lihatsoalpg/lihatsoal', $this->data);
	}

    public function hasilpilihanganda(){
        $this->data['tampil'] = $this->db->query("SELECT student.nama_murid, jawaban.id_student, kelas.ket_kelas, mata_pelajaran.mata_pelajaran, jawaban.kode_soal, jawaban.benar, jawaban.salah, jawaban.nilai
                                    FROM jawaban
                                    INNER JOIN student ON student.id_student=jawaban.id_student
                                    INNER JOIN kelas ON kelas.id_kelas=student.id_kelas
                                    INNER JOIN mata_pelajaran ON mata_pelajaran.kode_soal=jawaban.kode_soal 
                                    WHERE jawaban.status_jawaban='1'")->result_array();
        $this->load->view('template/header');
        $this->load->view('lihatsoalpg/hasilpg', $this->data);
    }

    public function uraian(){ //admin
        $login = $this->session->userdata('arr_login');
        $get_login = explode('*&*&*', $login);
        $this->data['id_user'] = $get_login[2];
        $this->load->view('template/header');
        $this->load->view('lihatsoaluraian/lihatsoal', $this->data);
    }
    public function addsoaluraian(){
        $this->load->view('template/header');
        $this->load->view('soal/uploadsoaluraian');
    }
    public function editsoaluraian(){
        $this->load->view('template/header');
        $this->data['tampil'] = $this->db->query("SELECT * FROM soal_uraian WHERE id_soal_uraian='$_GET[editsoal]'")->row();
        $this->load->view('soal/uploadsoaluraian', $this->data);
    }

    public function hasiluraian(){
        $this->data['tampil'] = $this->db->query("SELECT 
                                    student.nama_murid, jawaban_uraian.id_student, kelas.ket_kelas,mata_pelajaran.mata_pelajaran, jawaban_uraian.kode_soal, 
                                    jawaban_uraian.benar, jawaban_uraian.salah, jawaban_uraian.nilai
                                    FROM jawaban_uraian
                                    INNER JOIN student ON student.id_student=jawaban_uraian.id_student
                                    INNER JOIN kelas ON kelas.id_kelas=student.id_kelas
                                    INNER JOIN mata_pelajaran ON mata_pelajaran.kode_soal=jawaban_uraian.kode_soal
                                    WHERE jawaban_uraian.status_jawaban='1'")->result_array();
        $this->load->view('template/header');
        $this->load->view('lihatsoaluraian/hasiluraian', $this->data);
    }

    public function cekuraian(){ //admin
        $login = $this->session->userdata('arr_login');
        $get_login = explode('*&*&*', $login);
        $this->data['id_user'] = $get_login[2];

        $this->data['soal'] = $this->db->query("SELECT 
                soal_uraian.id_soal_uraian, soal_uraian.soal, soal_uraian.gambar, 
                mata_pelajaran.mata_pelajaran, soal_uraian.kunci_jawaban
                FROM soal_uraian
                INNER JOIN mata_pelajaran ON mata_pelajaran.kode_soal=soal_uraian.kode_soal
                INNER JOIN jawaban_uraian ON jawaban_uraian.kode_soal=mata_pelajaran.kode_soal
                INNER JOIN user_login ON user_login.id_user=mata_pelajaran.id_user
                WHERE soal_uraian.kode_soal='$_GET[kd]' AND jawaban_uraian.id_student='$_GET[id]'")->result_array();

        $this->load->view('template/header');
        $this->load->view('lihatsoaluraian/cekjwburaian', $this->data);
    }

    public function mapel(){
        $login = $this->session->userdata('arr_login');
        $get_login = explode('*&*&*', $login);
        $this->data['id_user'] = $get_login[2];

        $this->data['tampil'] = $this->db->query("SELECT * FROM mata_pelajaran INNER JOIN kelas ON kelas.id_kelas=mata_pelajaran.id_kelas WHERE mata_pelajaran.id_user='$get_login[2]'")->result_array();
        $this->load->view('template/header');
        $this->load->view('mata_pelajaran/mapel', $this->data);
    }

    public function addmapel(){
        $this->load->view('template/header');
        $this->load->view('mata_pelajaran/editmapel');
    }
    public function editmapel(){
        $login = $this->session->userdata('arr_login');
        $get_login = explode('*&*&*', $login);
        $this->data['id_user'] = $get_login[2];

        $this->data['tampil'] = $this->db->query("SELECT * FROM mata_pelajaran INNER JOIN kelas ON kelas.id_kelas=mata_pelajaran.id_kelas WHERE mata_pelajaran.id_user='$get_login[2]' AND id_pelajaran='$_GET[edit_mapel]'")->row();
        
        $this->load->view('template/header');
        $this->load->view('mata_pelajaran/editmapel', $this->data);
    }

    public function postblog(){
        $login = $this->session->userdata('arr_login');
        $get_login = explode('*&*&*', $login);
        $this->data['id_user'] = $get_login[2];

        $this->load->view('template/header');
        $this->load->view('blog/blog', $this->data);
    }
    public function editblog(){
        $login = $this->session->userdata('arr_login');
        $get_login = explode('*&*&*', $login);
        $this->data['id_user'] = $get_login[2];
        $this->data['tampil'] = $this->db->query("SELECT * FROM materi_blog WHERE rand_blog='$_GET[editblog]'")->row();
        if (empty($this->data['tampil'])) {
            $msg = "Url Invalid...";
            $this->session->set_userdata('error', $msg);
            redirect('elearn/listblog');
            return false;            
        }
        $this->load->view('template/header');
        $this->load->view('blog/blog', $this->data);
    }
    public function listblog(){ //admin
        $login = $this->session->userdata('arr_login');
        $get_login = explode('*&*&*', $login);
        $this->data['id_user'] = $get_login[2];
        
        $this->load->view('template/header');
        $this->load->view('blog/listblog', $this->data);
    }
    public function detailblog(){
        $login = $this->session->userdata('arr_login');
        $get_login = explode('*&*&*', $login);
        $this->data['id_user'] = $get_login[2];
        $this->data['tampil'] = $this->db->query("SELECT * FROM materi_blog WHERE rand_blog='$_GET[id]'")->row();
        if (empty($this->data['tampil'])) {
            $msg = "Url Invalid...";
            $this->session->set_userdata('error', $msg);
            redirect('elearn/listblog');
            return false;            
        }
        $this->load->view('template/header');
        $this->load->view('blog/detailblog', $this->data);
    }


    public function listebook(){
        $login = $this->session->userdata('arr_login');
        $get_login = explode('*&*&*', $login);
        $this->data['id_user'] = $get_login[2];
        
        $this->load->view('template/header');
        $this->load->view('blog/listebook', $this->data);
    }
    public function uploadebook(){
        $login = $this->session->userdata('arr_login');
        $get_login = explode('*&*&*', $login);
        $this->data['id_user'] = $get_login[2];

        $this->load->view('template/header');
        $this->load->view('blog/ebook', $this->data);
    }


}
?>
