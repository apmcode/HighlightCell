<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Exportexcel extends CI_Controller {
	
	public function __construct(){
		parent::__construct();
        date_default_timezone_set("Asia/Jakarta");
		$cek = $this->session->userdata('arr_login');
		if (empty($cek)) {
			redirect('login');
			return false;
		}
	}
	

public function template_upload(){
		// Load plugin PHPExcel nya
		include APPPATH.'third_party/PHPExcel/PHPExcel.php';
		
		// Panggil class PHPExcel nya
		$excel = new PHPExcel();

		// Settingan awal fil excel
		$excel->getProperties()->setCreator('SPPS - Sahrul Ramdhani')
							   ->setLastModifiedBy('SPPS - Sahrul Ramdhani')
							   ->setTitle("SPPS")
							   ->setSubject("SPPS")
							   ->setDescription("Template Upload SPPS")
							   ->setKeywords("SPPS");

	    $style1 = array(
			'font' => array('bold' => true, 'size' => 10), // Set font nya jadi bold
	        'alignment' => array(
	            'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER, //SET TEXT CENTER
	            'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER, //SET MIDDLE CENTER
	        ),
				'borders' => array(
				'top' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border top dengan garis tipis
				'right' => array('style'  => PHPExcel_Style_Border::BORDER_THIN),  // Set border right dengan garis tipis
				'bottom' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border bottom dengan garis tipis
				'left' => array('style'  => PHPExcel_Style_Border::BORDER_THIN) // Set border left dengan garis tipis
			),
		        'fill' => array(
		            'type' => PHPExcel_Style_Fill::FILL_SOLID,
		            'color' => array('rgb' => '78c7c7')
		    )
	    );

	    $style = array(
	        'alignment' => array(
	            //'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER, //SET TEXT CENTER
	            'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER, //SET MIDDLE CENTER
	        ),
				'borders' => array(
				'top' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border top dengan garis tipis
				'right' => array('style'  => PHPExcel_Style_Border::BORDER_THIN),  // Set border right dengan garis tipis
				'bottom' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border bottom dengan garis tipis
				'left' => array('style'  => PHPExcel_Style_Border::BORDER_THIN) // Set border left dengan garis tipis
			)
	    );

	 	$style_red = array(
			'font' => array('bold' => true, 'color' => array('rgb' => 'ffff'), 'size' => 10), // Set font nya jadi bold
	        'alignment' => array(
	            'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER, //SET TEXT CENTER
	            'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER, //SET MIDDLE CENTER
	        ),
				'borders' => array(
				'top' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border top dengan garis tipis
				'right' => array('style'  => PHPExcel_Style_Border::BORDER_THIN),  // Set border right dengan garis tipis
				'bottom' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border bottom dengan garis tipis
				'left' => array('style'  => PHPExcel_Style_Border::BORDER_THIN) // Set border left dengan garis tipis
			),	
			'fill' => array(
		            'type' => PHPExcel_Style_Fill::FILL_SOLID,
		            'color' => array('rgb' => 'ea0000')
		    )
	    );

		$excel->setActiveSheetIndex(0);
		$excel->getActiveSheet()->setCellValue('A1', 'NO INDUK');
		$excel->getActiveSheet()->setCellValue('B1', 'NISN');
		$excel->getActiveSheet()->setCellValue('C1', 'NAMA SISWA');
		$excel->getActiveSheet()->setCellValue('D1', 'JENIS KELAMIN');
		$excel->getActiveSheet()->setCellValue('E1', 'TEMPAT LAHIR');
		$excel->getActiveSheet()->setCellValue('F1', 'TGL LAHIR');
		$excel->getActiveSheet()->setCellValue('G1', 'AGAMA');
		$excel->getActiveSheet()->setCellValue('H1', 'KELAS');
		$excel->getActiveSheet()->setCellValue('I1', 'ALAMAT');
		$excel->getActiveSheet()->setCellValue('J1', 'HP SISWA');
		$excel->getActiveSheet()->setCellValue('K1', 'NAMA IBU KANDUNG');
		$excel->getActiveSheet()->setCellValue('L1', 'NAMA AYAH KANDUNG');
		$excel->getActiveSheet()->setCellValue('M1', 'HP ORANG TUA');

		//DIISI
		$excel->getActiveSheet()->setCellValue('A2', 'DIISI');
		$excel->getActiveSheet()->setCellValue('B2', 'DIISI');
		$excel->getActiveSheet()->setCellValue('C2', 'DIISI');
		$excel->getActiveSheet()->setCellValue('D2', 'DIISI');
		$excel->getActiveSheet()->setCellValue('E2', 'DIISI');
		$excel->getActiveSheet()->setCellValue('F2', 'dd/mm/yy');
		$excel->getActiveSheet()->setCellValue('G2', 'DIISI');
		$excel->getActiveSheet()->setCellValue('H2', 'DIISI');
		$excel->getActiveSheet()->setCellValue('I2', 'OPTIONAL');
		$excel->getActiveSheet()->setCellValue('J2', 'OPTIONAL');
		$excel->getActiveSheet()->setCellValue('K2', 'DIISI');
		$excel->getActiveSheet()->setCellValue('L2', 'DIISI');
		$excel->getActiveSheet()->setCellValue('M2', 'DIISI');
		//END DIISI

		$get_kelas = $this->db->query("SELECT ket_kelas FROM kelas")->result_array();
		$num_cell_get_kelas = 1;
		foreach ($get_kelas as $nama_kelas) {
			$excel->getActiveSheet()->setCellValue('Z'.$num_cell_get_kelas++, $nama_kelas['ket_kelas']);
			$this->session->set_userdata("cell_kelas", $num_cell_get_kelas);
		}
		
		$get_agama = $this->db->query("SELECT ket_agama FROM agama")->result_array();
		$num_cell_agama = 1;
		foreach ($get_agama as $agama) {
			$excel->getActiveSheet()->setCellValue('Y'.$num_cell_agama++, $agama['ket_agama']);
			$this->session->set_userdata("cell_agama", $num_cell_agama);
		}

		$session_cell_kelas = $this->session->userdata("cell_kelas") - 1;
		$session_cell_agama = $this->session->userdata("cell_agama") - 1;
		$validation_agama = '$Z$1:$Z$'.$session_cell_kelas;  
		$validation_kelas = '$Y$1:$Y$'.$session_cell_agama;  
		$excel->getActiveSheet()->setCellValue('X1', 'L');
		$excel->getActiveSheet()->setCellValue('X2', 'P');
		$validation_jk = '$X$1:$X$2';  

	for ($i=3; $i < 104; $i++) { 
		$cell_kelas='G'.$i;
		$cell_agama='H'.$i;
		$cell_jk='D'.$i;
		//GET SHEET
		$objValidation_kelas = $excel->getActiveSheet()->getCell($cell_kelas)->getDataValidation();
		$objValidation_kelas->setType( PHPExcel_Cell_DataValidation::TYPE_LIST );
		$objValidation_kelas->setShowDropDown(true);
		$objValidation_kelas->setFormula1($validation_kelas);

		$objValidation_agama = $excel->getActiveSheet()->getCell($cell_agama)->getDataValidation();
		$objValidation_agama->setType( PHPExcel_Cell_DataValidation::TYPE_LIST );
		$objValidation_agama->setShowDropDown(true);
		$objValidation_agama->setFormula1($validation_agama);

		$objValidation_jk = $excel->getActiveSheet()->getCell($cell_jk)->getDataValidation();
		$objValidation_jk->setType( PHPExcel_Cell_DataValidation::TYPE_LIST );
		$objValidation_jk->setShowDropDown(true);
		$objValidation_jk->setFormula1($validation_jk);


		$excel->getActiveSheet()->setCellValue('G'.$i, 'Pilih Agama');
		$excel->getActiveSheet()->setCellValue('H'.$i, 'Pilih Kelas');
		$excel->getActiveSheet()->setCellValue('D'.$i, 'Pilih JK');
		$excel->getActiveSheet()->getStyle('A'.$i)->applyFromArray($style);
		$excel->getActiveSheet()->getStyle('B'.$i)->applyFromArray($style);
		$excel->getActiveSheet()->getStyle('C'.$i)->applyFromArray($style);
		$excel->getActiveSheet()->getStyle('D'.$i)->applyFromArray($style);
		$excel->getActiveSheet()->getStyle('E'.$i)->applyFromArray($style);
		$excel->getActiveSheet()->getStyle('F'.$i)->applyFromArray($style);
		$excel->getActiveSheet()->getStyle('G'.$i)->applyFromArray($style);
		$excel->getActiveSheet()->getStyle('H'.$i)->applyFromArray($style);
		$excel->getActiveSheet()->getStyle('I'.$i)->applyFromArray($style);
		$excel->getActiveSheet()->getStyle('J'.$i)->applyFromArray($style);
		$excel->getActiveSheet()->getStyle('K'.$i)->applyFromArray($style);
		$excel->getActiveSheet()->getStyle('L'.$i)->applyFromArray($style);
		$excel->getActiveSheet()->getStyle('M'.$i)->applyFromArray($style);
	}


		$excel->getActiveSheet()->getStyle('A1')->applyFromArray($style1);
		$excel->getActiveSheet()->getStyle('B1')->applyFromArray($style1);
		$excel->getActiveSheet()->getStyle('C1')->applyFromArray($style1);
		$excel->getActiveSheet()->getStyle('D1')->applyFromArray($style1);
		$excel->getActiveSheet()->getStyle('E1')->applyFromArray($style1);
		$excel->getActiveSheet()->getStyle('F1')->applyFromArray($style1);
		$excel->getActiveSheet()->getStyle('G1')->applyFromArray($style1);
		$excel->getActiveSheet()->getStyle('H1')->applyFromArray($style1);
		$excel->getActiveSheet()->getStyle('I1')->applyFromArray($style1);
		$excel->getActiveSheet()->getStyle('J1')->applyFromArray($style1);
		$excel->getActiveSheet()->getStyle('K1')->applyFromArray($style1);
		$excel->getActiveSheet()->getStyle('L1')->applyFromArray($style1);
		$excel->getActiveSheet()->getStyle('M1')->applyFromArray($style1);

		$excel->getActiveSheet()->getStyle('A2')->applyFromArray($style_red);
		$excel->getActiveSheet()->getStyle('B2')->applyFromArray($style_red);
		$excel->getActiveSheet()->getStyle('C2')->applyFromArray($style_red);
		$excel->getActiveSheet()->getStyle('D2')->applyFromArray($style_red);
		$excel->getActiveSheet()->getStyle('E2')->applyFromArray($style_red);
		$excel->getActiveSheet()->getStyle('F2')->applyFromArray($style_red);
		$excel->getActiveSheet()->getStyle('G2')->applyFromArray($style_red);
		$excel->getActiveSheet()->getStyle('H2')->applyFromArray($style_red);
		$excel->getActiveSheet()->getStyle('I2')->applyFromArray($style_red);
		$excel->getActiveSheet()->getStyle('J2')->applyFromArray($style_red);
		$excel->getActiveSheet()->getStyle('K2')->applyFromArray($style_red);
		$excel->getActiveSheet()->getStyle('L2')->applyFromArray($style_red);
		$excel->getActiveSheet()->getStyle('M2')->applyFromArray($style_red);

		// $excel->getActiveSheet()->getStyle('I1:I999')->getAlignment()->setWrapText(true); 
		// $excel->getActiveSheet()->getStyle('C1:C999')->getAlignment()->setWrapText(true); 
	//	$excel->getActiveSheet()->freezePane('4');

		// Set width kolom
		$excel->getActiveSheet()->getColumnDimension('A')->setWidth(15); // Set width kolom A
		$excel->getActiveSheet()->getColumnDimension('B')->setWidth(15); // Set width kolom B
		$excel->getActiveSheet()->getColumnDimension('C')->setWidth(25); // Set width kolom B
		$excel->getActiveSheet()->getColumnDimension('D')->setWidth(15); // Set width kolom B
		$excel->getActiveSheet()->getColumnDimension('E')->setWidth(20); // Set width kolom B
		$excel->getActiveSheet()->getColumnDimension('F')->setWidth(15); // Set width kolom B
		$excel->getActiveSheet()->getColumnDimension('G')->setWidth(15); // Set width kolom B
		$excel->getActiveSheet()->getColumnDimension('H')->setWidth(20); // Set width kolom B
		$excel->getActiveSheet()->getColumnDimension('I')->setWidth(25); // Set width kolom B
		$excel->getActiveSheet()->getColumnDimension('J')->setWidth(20); // Set width kolom B
		$excel->getActiveSheet()->getColumnDimension('K')->setWidth(20); // Set width kolom B
		$excel->getActiveSheet()->getColumnDimension('L')->setWidth(20); // Set width kolom B
		$excel->getActiveSheet()->getColumnDimension('M')->setWidth(20); // Set width kolom B
		$excel->getActiveSheet()->getColumnDimension('X')->setWidth(1); // Set width kolom B
		$excel->getActiveSheet()->getColumnDimension('Y')->setWidth(1); // Set width kolom B
		$excel->getActiveSheet()->getColumnDimension('Z')->setWidth(1); // Set width kolom B
		// Set height semua kolom menjadi auto (mengikuti height isi dari kolommnya, jadi otomatis)
		$excel->getActiveSheet()->getDefaultRowDimension()->setRowHeight(-1);

		// Set orientasi kertas jadi LANDSCAPE
		$excel->getActiveSheet()->getPageSetup()->setOrientation(PHPExcel_Worksheet_PageSetup::ORIENTATION_LANDSCAPE);

		// Set judul file excel nya
		$excel->getActiveSheet(0)->setTitle("Template Data Siswa");
		$excel->setActiveSheetIndex(0);
		//Create a new worksheet, after the default sheet

		// Proses file excel
		header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
		header('Content-Disposition: attachment; filename="TemplatePengisianDataSiswa.xlsx"'); // Set nama file excel nya
		header('Cache-Control: max-age=0');

		$write = PHPExcel_IOFactory::createWriter($excel, 'Excel2007');
		$write->save('php://output');
	}


public function lap_keu(){
		// Load plugin PHPExcel nya
		include APPPATH.'third_party/PHPExcel/PHPExcel.php';
		
		// Panggil class PHPExcel nya
		$excel = new PHPExcel();

		// Settingan awal fil excel
		$excel->getProperties()->setCreator('SPPS - Sahrul Ramdhani')
							   ->setLastModifiedBy('SPPS - Sahrul Ramdhani')
							   ->setTitle("SPPS")
							   ->setSubject("SPPS")
							   ->setDescription("Lap. Keu Upload SPPS")
							   ->setKeywords("SPPS");

	    $style1 = array(
			'font' => array('bold' => true, 'size' => 10), // Set font nya jadi bold
	        'alignment' => array(
	            'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER, //SET TEXT CENTER
	            'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER, //SET MIDDLE CENTER
	        ),
				'borders' => array(
				'top' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border top dengan garis tipis
				'right' => array('style'  => PHPExcel_Style_Border::BORDER_THIN),  // Set border right dengan garis tipis
				'bottom' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border bottom dengan garis tipis
				'left' => array('style'  => PHPExcel_Style_Border::BORDER_THIN) // Set border left dengan garis tipis
			),
		        'fill' => array(
		            'type' => PHPExcel_Style_Fill::FILL_SOLID,
		            'color' => array('rgb' => '78c7c7')
		    )
	    );

	    $style = array(
	        'alignment' => array(
	            //'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER, //SET TEXT CENTER
	            'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER, //SET MIDDLE CENTER
	        ),
				'borders' => array(
				'top' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border top dengan garis tipis
				'right' => array('style'  => PHPExcel_Style_Border::BORDER_THIN),  // Set border right dengan garis tipis
				'bottom' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border bottom dengan garis tipis
				'left' => array('style'  => PHPExcel_Style_Border::BORDER_THIN) // Set border left dengan garis tipis
			)
	    );

	 	$style_red = array(
			'font' => array('bold' => true, 'color' => array('rgb' => 'ffff'), 'size' => 10), // Set font nya jadi bold
	        'alignment' => array(
	            'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER, //SET TEXT CENTER
	            'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER, //SET MIDDLE CENTER
	        ),
				'borders' => array(
				'top' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border top dengan garis tipis
				'right' => array('style'  => PHPExcel_Style_Border::BORDER_THIN),  // Set border right dengan garis tipis
				'bottom' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border bottom dengan garis tipis
				'left' => array('style'  => PHPExcel_Style_Border::BORDER_THIN) // Set border left dengan garis tipis
			),	
			'fill' => array(
		            'type' => PHPExcel_Style_Fill::FILL_SOLID,
		            'color' => array('rgb' => 'ea0000')
		    )
	    );

		$tgl_jur1 = $this->session->userdata('tgl1');
		$tgl_jur2 = $this->session->userdata('tgl2');

		$excel->setActiveSheetIndex(0);
		$nama_sekolah = $this->db->query("SELECT nama_sekolah FROM sekolah")->row();
		$excel->getActiveSheet()->setCellValue('A1', 'Laporan Keuangan');
		if (!empty($nama_sekolah->nama_sekolah)) { $nama_sekolah = $nama_sekolah->nama_sekolah; }else{ $nama_sekolah='nama_sekolah'; }
		$excel->getActiveSheet()->setCellValue('A2', $nama_sekolah);
		$excel->getActiveSheet()->setCellValue('A3', 'Tanggal Laporan: '.$tgl_jur1.' s/d '.$tgl_jur2);
		$excel->getActiveSheet()->setCellValue('A4', 'Tanggal Unduh: '.date('Y-m-d h:i:s'));

		$cek = $this->session->userdata('arr_login');
        $cek_username = explode('*&*&*', $cek);
		$excel->getActiveSheet()->setCellValue('C4', 'Pengunduh: '.$cek_username[0]);


		$excel->getActiveSheet()->setCellValue('A6', 'NO INDUK');
		$excel->getActiveSheet()->setCellValue('B6', 'NAMA MURID');
		$excel->getActiveSheet()->setCellValue('C6', 'KELAS');
		$excel->getActiveSheet()->setCellValue('D6', 'POS & BULAN');
		$excel->getActiveSheet()->setCellValue('E6', 'BEASISWA');
		$excel->getActiveSheet()->setCellValue('F6', 'TOTAL TAGIHAN');
		$excel->getActiveSheet()->setCellValue('G6', 'SISA TAGIHAN');
		$excel->getActiveSheet()->setCellValue('H6', 'TAGIHAN TERBAYAR');
		$excel->getActiveSheet()->setCellValue('I6', 'TGL BAYAR');

		$excel->getActiveSheet()->setCellValue('K6', 'NO INDUK');
		$excel->getActiveSheet()->setCellValue('L6', 'NAMA MURID');
		$excel->getActiveSheet()->setCellValue('M6', 'KELAS');
		$excel->getActiveSheet()->setCellValue('N6', 'POS & TIPE');
		$excel->getActiveSheet()->setCellValue('O6', 'BEASISWA');
		$excel->getActiveSheet()->setCellValue('P6', 'TOTAL TAGIHAN');
		$excel->getActiveSheet()->setCellValue('Q6', 'SISA TAGIHAN');
		$excel->getActiveSheet()->setCellValue('R6', 'TAGIHAN TERBAYAR');
		$excel->getActiveSheet()->setCellValue('S6', 'TGL BAYAR');

		$excel->getActiveSheet()->setCellValue('U6', 'STATUS');
		$excel->getActiveSheet()->setCellValue('V6', 'TANGGAL');
		$excel->getActiveSheet()->setCellValue('W6', 'TOTAL TAGIHAN');
		$excel->getActiveSheet()->setCellValue('X6', 'KETERANGAN');

		$tgl1 = $this->session->userdata('tgl1').' 23:59:00';
		$tgl2 = $this->session->userdata('tgl2').' 23:59:00';

//BEBAS
		$sql_not_bln = "SELECT 
				student.no_induk, pos_keuangan.nama_pos, regis_transaksi.biaya, beasiswa.ket_beasiswa, beasiswa.potongan, regis_transaksi.date_bayar, student.nama_murid, kelas.ket_kelas, regis_transaksi.paid
				FROM regis_transaksi
				INNER JOIN student ON student.id_student=regis_transaksi.id_student
				INNER JOIN kelas ON kelas.id_kelas=student.id_kelas
				INNER JOIN beasiswa ON beasiswa.id_beasiswa=regis_transaksi.id_beasiswa
				INNER JOIN jenis_pembayaran ON jenis_pembayaran.id_jp=regis_transaksi.id_jp
				INNER JOIN pos_keuangan ON pos_keuangan.id_pos=jenis_pembayaran.id_pos
				INNER JOIN tipe_bayar ON tipe_bayar.id_tipe=jenis_pembayaran.id_tipe
				WHERE tipe_bayar.id_tipe=2 AND regis_transaksi.date_bayar BETWEEN '$tgl1' AND '$tgl2'";
			$bebas = $this->db->query($sql_not_bln)->result_array();
			$numrow_b=7;
		$count_bebas = count($bebas);
		if ($count_bebas > 0) {
			foreach ($bebas as $key) {
				$excel->getActiveSheet()->setCellValue('K'.$numrow_b, $key['no_induk']);
				$excel->getActiveSheet()->setCellValue('L'.$numrow_b, $key['nama_murid']);
				$excel->getActiveSheet()->setCellValue('M'.$numrow_b, $key['ket_kelas']);
				$excel->getActiveSheet()->setCellValue('N'.$numrow_b, $key['nama_pos'].' - Lainnya');
				$excel->getActiveSheet()->setCellValue('O'.$numrow_b, $key['ket_beasiswa'].' - '.$key['potongan']);
		        $pot = $key['potongan'];
		        if (!is_numeric($pot)) {
		            $num = floatval($pot); 
		            $per = ($num/100)*$key['biaya'];
		            $total_beasiswa_bln = $key['biaya'] - $per;
		        }else{ $total_beasiswa_bln = $key['biaya'] - $pot;}
				$excel->getActiveSheet()->setCellValue('P'.$numrow_b, $total_beasiswa_bln);
				$excel->getActiveSheet()->setCellValue('Q'.$numrow_b, $total_beasiswa_bln - $key['paid']);
				$excel->getActiveSheet()->setCellValue('R'.$numrow_b, $key['paid']);
				$excel->getActiveSheet()->setCellValue('S'.$numrow_b, $key['date_bayar']);
				$excel->getActiveSheet()->getStyle('K'.$numrow_b)->applyFromArray($style);
				$excel->getActiveSheet()->getStyle('L'.$numrow_b)->applyFromArray($style);
				$excel->getActiveSheet()->getStyle('M'.$numrow_b)->applyFromArray($style);
				$excel->getActiveSheet()->getStyle('N'.$numrow_b)->applyFromArray($style);
				$excel->getActiveSheet()->getStyle('O'.$numrow_b)->applyFromArray($style);
				$excel->getActiveSheet()->getStyle('P'.$numrow_b)->applyFromArray($style);
				$excel->getActiveSheet()->getStyle('Q'.$numrow_b)->applyFromArray($style);
				$excel->getActiveSheet()->getStyle('R'.$numrow_b)->applyFromArray($style);
				$excel->getActiveSheet()->getStyle('S'.$numrow_b)->applyFromArray($style);
				$numrow_b++;
			}
		}else{
			$excel->getActiveSheet()->mergeCells('K7:S7')->setCellValue('K7', 'Tidak Ada Laporan Keuangan');
			$excel->getActiveSheet()->getStyle('K7:S7')->applyFromArray($style_red);
		}

//END BEBAS

//BULANAN
		$sql = "SELECT 
				student.no_induk, pos_keuangan.nama_pos, bulan.nama_bulan, regis_transaksi.biaya, beasiswa.potongan, beasiswa.ket_beasiswa, regis_transaksi.date_bayar, student.nama_murid, kelas.ket_kelas, regis_transaksi.paid
				FROM regis_transaksi
				INNER JOIN student ON student.id_student=regis_transaksi.id_student
				INNER JOIN kelas ON kelas.id_kelas=student.id_kelas
				INNER JOIN beasiswa ON beasiswa.id_beasiswa=regis_transaksi.id_beasiswa
				INNER JOIN jenis_pembayaran ON jenis_pembayaran.id_jp=regis_transaksi.id_jp
				INNER JOIN pos_keuangan ON pos_keuangan.id_pos=jenis_pembayaran.id_pos
				INNER JOIN bulan ON bulan.id_bulan=regis_transaksi.id_bulan
				WHERE regis_transaksi.date_bayar BETWEEN '$tgl1' AND '$tgl2'";
		$bulanan = $this->db->query($sql)->result_array();
		$numrow=7;
		$count_bln = count($bulanan);
		if ($count_bln > 0) {
			foreach ($bulanan as $key) {
				$excel->getActiveSheet()->setCellValue('A'.$numrow, $key['no_induk']);
				$excel->getActiveSheet()->setCellValue('B'.$numrow, $key['nama_murid']);
				$excel->getActiveSheet()->setCellValue('C'.$numrow, $key['ket_kelas']);
				$excel->getActiveSheet()->setCellValue('D'.$numrow, $key['nama_pos'].'-'.$key['nama_bulan']);
				$excel->getActiveSheet()->setCellValue('E'.$numrow, $key['ket_beasiswa'].' - '.$key['potongan']);
		        $pot = $key['potongan'];
		        if (!is_numeric($pot)) {
		            $num = floatval($pot); 
		            $per = ($num/100)*$key['biaya'];
		            $total_beasiswa_bln = $key['biaya'] - $per;
		        }else{ $total_beasiswa_bln = $key['biaya'] - $pot; }
				$excel->getActiveSheet()->setCellValue('F'.$numrow, $total_beasiswa_bln);
				$excel->getActiveSheet()->setCellValue('G'.$numrow, $total_beasiswa_bln - $key['paid']);
				$excel->getActiveSheet()->setCellValue('H'.$numrow, $key['paid']);
				$excel->getActiveSheet()->setCellValue('I'.$numrow, $key['date_bayar']);
				$excel->getActiveSheet()->getStyle('A'.$numrow)->applyFromArray($style);
				$excel->getActiveSheet()->getStyle('B'.$numrow)->applyFromArray($style);
				$excel->getActiveSheet()->getStyle('C'.$numrow)->applyFromArray($style);
				$excel->getActiveSheet()->getStyle('D'.$numrow)->applyFromArray($style);
				$excel->getActiveSheet()->getStyle('E'.$numrow)->applyFromArray($style);
				$excel->getActiveSheet()->getStyle('F'.$numrow)->applyFromArray($style);
				$excel->getActiveSheet()->getStyle('G'.$numrow)->applyFromArray($style);
				$excel->getActiveSheet()->getStyle('H'.$numrow)->applyFromArray($style);
				$excel->getActiveSheet()->getStyle('I'.$numrow)->applyFromArray($style);
				$numrow++;
			}
		}else{
			$excel->getActiveSheet()->mergeCells('A7:I7')->setCellValue('A7', 'Tidak Ada Laporan Keuangan');
			$excel->getActiveSheet()->getStyle('A7:A7')->applyFromArray($style_red);
		}
//END BULANAN

//JURNAL
		$sql_jurnal_umul = "SELECT * FROM `jurnal_umul` WHERE tanggal_jurnal BETWEEN '$tgl_jur1' AND '$tgl_jur2' ORDER BY stat_peng_msk DESC";
			$jurnal = $this->db->query($sql_jurnal_umul)->result_array();
			$numrow_jb=7;
		$count_jurnal = count($jurnal);
		if ($count_jurnal > 0) {
			foreach ($jurnal as $key) {
				if ($key['stat_peng_msk'] == 1) { $stat = 'Penerimaan'; }elseif ($key['stat_peng_msk'] == 2) { $stat = 'Pengeluaran'; }

				$excel->getActiveSheet()->setCellValue('U'.$numrow_jb, 'Pengeluaran');
				$excel->getActiveSheet()->setCellValue('V'.$numrow_jb, $key['tanggal_jurnal']);
				$excel->getActiveSheet()->setCellValue('W'.$numrow_jb, $key['biaya_jurnal']);
				$excel->getActiveSheet()->setCellValue('X'.$numrow_jb, $key['ket_jurnal']);

				$excel->getActiveSheet()->getStyle('U'.$numrow_jb)->applyFromArray($style);
				$excel->getActiveSheet()->getStyle('V'.$numrow_jb)->applyFromArray($style);
				$excel->getActiveSheet()->getStyle('W'.$numrow_jb)->applyFromArray($style);
				$excel->getActiveSheet()->getStyle('X'.$numrow_jb)->applyFromArray($style);
				$numrow_jb++;
			}
		}else{
			$excel->getActiveSheet()->mergeCells('U7:X7')->setCellValue('U7', 'Tidak Ada Laporan Keuangan');
			$excel->getActiveSheet()->getStyle('U7:X7')->applyFromArray($style_red);
		}

//END JURNAL

		// $excel->getActiveSheet()->getStyle('X1:X999')->getAlignment()->setWrapText(true); 
		$excel->getActiveSheet()->getStyle('A6')->applyFromArray($style1);
		$excel->getActiveSheet()->getStyle('B6')->applyFromArray($style1);
		$excel->getActiveSheet()->getStyle('C6')->applyFromArray($style1);
		$excel->getActiveSheet()->getStyle('D6')->applyFromArray($style1);
		$excel->getActiveSheet()->getStyle('E6')->applyFromArray($style1);
		$excel->getActiveSheet()->getStyle('F6')->applyFromArray($style1);
		$excel->getActiveSheet()->getStyle('G6')->applyFromArray($style1);
		$excel->getActiveSheet()->getStyle('H6')->applyFromArray($style1);
		$excel->getActiveSheet()->getStyle('I6')->applyFromArray($style1);
		$excel->getActiveSheet()->getStyle('K6')->applyFromArray($style1);
		$excel->getActiveSheet()->getStyle('L6')->applyFromArray($style1);
		$excel->getActiveSheet()->getStyle('M6')->applyFromArray($style1);
		$excel->getActiveSheet()->getStyle('N6')->applyFromArray($style1);
		$excel->getActiveSheet()->getStyle('O6')->applyFromArray($style1);
		$excel->getActiveSheet()->getStyle('P6')->applyFromArray($style1);
		$excel->getActiveSheet()->getStyle('Q6')->applyFromArray($style1);
		$excel->getActiveSheet()->getStyle('R6')->applyFromArray($style1);
		$excel->getActiveSheet()->getStyle('S6')->applyFromArray($style1);
		$excel->getActiveSheet()->getStyle('U6')->applyFromArray($style1);
		$excel->getActiveSheet()->getStyle('V6')->applyFromArray($style1);
		$excel->getActiveSheet()->getStyle('W6')->applyFromArray($style1);
		$excel->getActiveSheet()->getStyle('X6')->applyFromArray($style1);

	//	$excel->getActiveSheet()->freezePane('4');
		// Set width kolom
		$excel->getActiveSheet()->getColumnDimension('A')->setWidth(18); // Set width kolom A
		$excel->getActiveSheet()->getColumnDimension('B')->setWidth(18); // Set width kolom B
		$excel->getActiveSheet()->getColumnDimension('C')->setWidth(18); // Set width kolom B
		$excel->getActiveSheet()->getColumnDimension('D')->setWidth(18); // Set width kolom B
		$excel->getActiveSheet()->getColumnDimension('E')->setWidth(18); // Set width kolom B
		$excel->getActiveSheet()->getColumnDimension('F')->setWidth(18); // Set width kolom B
		$excel->getActiveSheet()->getColumnDimension('G')->setWidth(15); // Set width kolom B
		$excel->getActiveSheet()->getColumnDimension('H')->setWidth(18); // Set width kolom B
		$excel->getActiveSheet()->getColumnDimension('I')->setWidth(18); // Set width kolom B
		$excel->getActiveSheet()->getColumnDimension('K')->setWidth(18); // Set width kolom B
		$excel->getActiveSheet()->getColumnDimension('L')->setWidth(18); // Set width kolom B
		$excel->getActiveSheet()->getColumnDimension('M')->setWidth(18); // Set width kolom B
		$excel->getActiveSheet()->getColumnDimension('N')->setWidth(18); // Set width kolom B
		$excel->getActiveSheet()->getColumnDimension('O')->setWidth(18); // Set width kolom B
		$excel->getActiveSheet()->getColumnDimension('P')->setWidth(18); // Set width kolom B
		$excel->getActiveSheet()->getColumnDimension('Q')->setWidth(18); // Set width kolom B
		$excel->getActiveSheet()->getColumnDimension('R')->setWidth(18); // Set width kolom B
		$excel->getActiveSheet()->getColumnDimension('S')->setWidth(18); // Set width kolom B
		$excel->getActiveSheet()->getColumnDimension('U')->setWidth(18); // Set width kolom B
		$excel->getActiveSheet()->getColumnDimension('V')->setWidth(18); // Set width kolom B
		$excel->getActiveSheet()->getColumnDimension('W')->setWidth(18); // Set width kolom B
		$excel->getActiveSheet()->getColumnDimension('X')->setWidth(18); // Set width kolom B

		// Set height semua kolom menjadi auto (mengikuti height isi dari kolommnya, jadi otomatis)
		$excel->getActiveSheet()->getDefaultRowDimension()->setRowHeight(-1);

		// Set orientasi kertas jadi LANDSCAPE
		$excel->getActiveSheet()->getPageSetup()->setOrientation(PHPExcel_Worksheet_PageSetup::ORIENTATION_LANDSCAPE);

		// Set judul file excel nya
		$excel->getActiveSheet(0)->setTitle("Laporan Keuangan");
		$excel->setActiveSheetIndex(0);
		//Create a new worksheet, after the default sheet

		// Proses file excel
		header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
		header('Content-Disposition: attachment; filename="LaporanKeuangan"'.DATE('Y-m-d H:i:s').'".xlsx"'); // Set nama file excel nya
		header('Cache-Control: max-age=0');

		$write = PHPExcel_IOFactory::createWriter($excel, 'Excel2007');
		$write->save('php://output');
	}


public function export_siswa(){
		// Load plugin PHPExcel nya
		include APPPATH.'third_party/PHPExcel/PHPExcel.php';
		
		// Panggil class PHPExcel nya
		$excel = new PHPExcel();

		// Settingan awal fil excel
		$excel->getProperties()->setCreator('SPPS - Sahrul Ramdhani')
							   ->setLastModifiedBy('SPPS - Sahrul Ramdhani')
							   ->setTitle("SPPS")
							   ->setSubject("SPPS")
							   ->setDescription("Template Upload SPPS")
							   ->setKeywords("SPPS");

	    $style1 = array(
			'font' => array('bold' => true, 'size' => 10), // Set font nya jadi bold
	        'alignment' => array(
	            'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER, //SET TEXT CENTER
	            'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER, //SET MIDDLE CENTER
	        ),
				'borders' => array(
				'top' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border top dengan garis tipis
				'right' => array('style'  => PHPExcel_Style_Border::BORDER_THIN),  // Set border right dengan garis tipis
				'bottom' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border bottom dengan garis tipis
				'left' => array('style'  => PHPExcel_Style_Border::BORDER_THIN) // Set border left dengan garis tipis
			),
		        'fill' => array(
		            'type' => PHPExcel_Style_Fill::FILL_SOLID,
		            'color' => array('rgb' => '78c7c7')
		    )
	    );

	    $style = array(
	        'alignment' => array(
	            //'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER, //SET TEXT CENTER
	            'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER, //SET MIDDLE CENTER
	        ),
				'borders' => array(
				'top' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border top dengan garis tipis
				'right' => array('style'  => PHPExcel_Style_Border::BORDER_THIN),  // Set border right dengan garis tipis
				'bottom' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border bottom dengan garis tipis
				'left' => array('style'  => PHPExcel_Style_Border::BORDER_THIN) // Set border left dengan garis tipis
			)
	    );

	 	$style_red = array(
			'font' => array('bold' => true, 'color' => array('rgb' => 'ffff'), 'size' => 10), // Set font nya jadi bold
	        'alignment' => array(
	            'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER, //SET TEXT CENTER
	            'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER, //SET MIDDLE CENTER
	        ),
				'borders' => array(
				'top' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border top dengan garis tipis
				'right' => array('style'  => PHPExcel_Style_Border::BORDER_THIN),  // Set border right dengan garis tipis
				'bottom' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border bottom dengan garis tipis
				'left' => array('style'  => PHPExcel_Style_Border::BORDER_THIN) // Set border left dengan garis tipis
			),	
			'fill' => array(
		            'type' => PHPExcel_Style_Fill::FILL_SOLID,
		            'color' => array('rgb' => 'ea0000')
		    )
	    );

		$excel->setActiveSheetIndex(0);
		$excel->getActiveSheet()->setCellValue('A1', 'NO INDUK');
		$excel->getActiveSheet()->setCellValue('B1', 'NISN');
		$excel->getActiveSheet()->setCellValue('C1', 'NAMA SISWA');
		$excel->getActiveSheet()->setCellValue('D1', 'JENIS KELAMIN');
		$excel->getActiveSheet()->setCellValue('E1', 'TEMPAT LAHIR');
		$excel->getActiveSheet()->setCellValue('F1', 'TGL LAHIR');
		$excel->getActiveSheet()->setCellValue('G1', 'AGAMA');
		$excel->getActiveSheet()->setCellValue('H1', 'KELAS');
		$excel->getActiveSheet()->setCellValue('I1', 'ALAMAT');
		$excel->getActiveSheet()->setCellValue('J1', 'HP SISWA');
		$excel->getActiveSheet()->setCellValue('K1', 'NAMA IBU KANDUNG');
		$excel->getActiveSheet()->setCellValue('L1', 'NAMA AYAH KANDUNG');
		$excel->getActiveSheet()->setCellValue('M1', 'HP ORANG TUA');

		$siswa = $this->db->query("SELECT * FROM student 
			INNER JOIN kelas ON kelas.id_kelas=student.id_kelas 
			INNER JOIN agama ON agama.id_agama=student.id_agama")->result_array();
		$numrow = 2;
		foreach ($siswa as $key) {
			$excel->getActiveSheet()->setCellValue('A'.$numrow, $key['no_induk']);
			$excel->getActiveSheet()->setCellValue('B'.$numrow, $key['nisn']);
			$excel->getActiveSheet()->setCellValue('C'.$numrow, $key['nama_murid']);
			$excel->getActiveSheet()->setCellValue('D'.$numrow, $key['jenis_kelamin']);
			$excel->getActiveSheet()->setCellValue('E'.$numrow, $key['tempat_lahir']);
			$excel->getActiveSheet()->setCellValue('F'.$numrow, $key['tgl_lahir']);
			$excel->getActiveSheet()->setCellValue('G'.$numrow, $key['ket_agama']);
			$excel->getActiveSheet()->setCellValue('H'.$numrow, $key['ket_kelas']);
			$excel->getActiveSheet()->setCellValue('I'.$numrow, $key['alamat']);
			$excel->getActiveSheet()->setCellValue('J'.$numrow, $key['hp_siswa']);
			$excel->getActiveSheet()->setCellValue('K'.$numrow, $key['nama_ibu']);
			$excel->getActiveSheet()->setCellValue('L'.$numrow, $key['nama_ayah']);
			$excel->getActiveSheet()->setCellValue('M'.$numrow, $key['hp_orang_tua']);

			$excel->getActiveSheet()->getStyle('A'.$numrow)->applyFromArray($style);
			$excel->getActiveSheet()->getStyle('B'.$numrow)->applyFromArray($style);
			$excel->getActiveSheet()->getStyle('C'.$numrow)->applyFromArray($style);
			$excel->getActiveSheet()->getStyle('D'.$numrow)->applyFromArray($style);
			$excel->getActiveSheet()->getStyle('E'.$numrow)->applyFromArray($style);
			$excel->getActiveSheet()->getStyle('F'.$numrow)->applyFromArray($style);
			$excel->getActiveSheet()->getStyle('G'.$numrow)->applyFromArray($style);
			$excel->getActiveSheet()->getStyle('H'.$numrow)->applyFromArray($style);
			$excel->getActiveSheet()->getStyle('I'.$numrow)->applyFromArray($style);
			$excel->getActiveSheet()->getStyle('J'.$numrow)->applyFromArray($style);
			$excel->getActiveSheet()->getStyle('K'.$numrow)->applyFromArray($style);
			$excel->getActiveSheet()->getStyle('L'.$numrow)->applyFromArray($style);
			$excel->getActiveSheet()->getStyle('M'.$numrow)->applyFromArray($style);
			$numrow++;
		}

		$excel->getActiveSheet()->getStyle('A1')->applyFromArray($style1);
		$excel->getActiveSheet()->getStyle('B1')->applyFromArray($style1);
		$excel->getActiveSheet()->getStyle('C1')->applyFromArray($style1);
		$excel->getActiveSheet()->getStyle('D1')->applyFromArray($style1);
		$excel->getActiveSheet()->getStyle('E1')->applyFromArray($style1);
		$excel->getActiveSheet()->getStyle('F1')->applyFromArray($style1);
		$excel->getActiveSheet()->getStyle('G1')->applyFromArray($style1);
		$excel->getActiveSheet()->getStyle('H1')->applyFromArray($style1);
		$excel->getActiveSheet()->getStyle('I1')->applyFromArray($style1);
		$excel->getActiveSheet()->getStyle('J1')->applyFromArray($style1);
		$excel->getActiveSheet()->getStyle('K1')->applyFromArray($style1);
		$excel->getActiveSheet()->getStyle('L1')->applyFromArray($style1);
		$excel->getActiveSheet()->getStyle('M1')->applyFromArray($style1);

		// Set width kolom
		$excel->getActiveSheet()->getColumnDimension('A')->setWidth(15); // Set width kolom A
		$excel->getActiveSheet()->getColumnDimension('B')->setWidth(15); // Set width kolom B
		$excel->getActiveSheet()->getColumnDimension('C')->setWidth(25); // Set width kolom B
		$excel->getActiveSheet()->getColumnDimension('D')->setWidth(15); // Set width kolom B
		$excel->getActiveSheet()->getColumnDimension('E')->setWidth(20); // Set width kolom B
		$excel->getActiveSheet()->getColumnDimension('F')->setWidth(15); // Set width kolom B
		$excel->getActiveSheet()->getColumnDimension('G')->setWidth(15); // Set width kolom B
		$excel->getActiveSheet()->getColumnDimension('H')->setWidth(20); // Set width kolom B
		$excel->getActiveSheet()->getColumnDimension('I')->setWidth(25); // Set width kolom B
		$excel->getActiveSheet()->getColumnDimension('J')->setWidth(20); // Set width kolom B
		$excel->getActiveSheet()->getColumnDimension('K')->setWidth(20); // Set width kolom B
		$excel->getActiveSheet()->getColumnDimension('L')->setWidth(20); // Set width kolom B
		$excel->getActiveSheet()->getColumnDimension('M')->setWidth(20); // Set width kolom B
		// Set height semua kolom menjadi auto (mengikuti height isi dari kolommnya, jadi otomatis)
		$excel->getActiveSheet()->getDefaultRowDimension()->setRowHeight(-1);

		// Set orientasi kertas jadi LANDSCAPE
		$excel->getActiveSheet()->getPageSetup()->setOrientation(PHPExcel_Worksheet_PageSetup::ORIENTATION_LANDSCAPE);

		// Set judul file excel nya
		$excel->getActiveSheet(0)->setTitle("Export Data Siswa");
		$excel->setActiveSheetIndex(0);
		//Create a new worksheet, after the default sheet

		// Proses file excel
		header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
		header('Content-Disposition: attachment; filename="DataSiswa"'.DATE('d/M/Y H:i:s').'".xlsx"'); // Set nama file excel nya
		header('Cache-Control: max-age=0');

		$write = PHPExcel_IOFactory::createWriter($excel, 'Excel2007');
		$write->save('php://output');
	}


}
?>