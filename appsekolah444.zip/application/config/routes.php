<?php
defined('BASEPATH') OR exit('No direct script access allowed');

//ubah nama controller
$route['default_controller'] = 'login';
$route['404_override'] = 'overide_error/index';
$route['translate_uri_dashes'] = FALSE;
