<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------
| Instructions
| -------------------------------------------------------------------
|
| These are the things you can load automatically:
|
| 1. Packages
| 2. Libraries
| 3. Drivers
| 4. Helper files
| 5. Custom config files
| 6. Language files
| 7. Models
|
*/

$autoload['packages'] = array();

//ditambhkan 'database' karena menggunakan database (tambhakan session jika menggunakan)
$autoload['libraries'] = array('database','session','pagination','email');

$autoload['drivers'] = array();

//diisi url, form untuk file gambar ,, load html
$autoload['helper'] = array('url','form','html','Cookie','file');


$autoload['config'] = array();


$autoload['language'] = array();

//tambahkan model crud
$autoload['model'] = array('m_p','m_admin');
