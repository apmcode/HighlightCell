<?php

class Fullcalendar_model extends CI_Model
{
	function fetch_all_event(){
		$login = $this->session->userdata('arr_login');
		$get_login = explode('*&*&*', $login);
		$id_user = $get_login[2];
		
		$this->db->order_by('id');
		$this->db->where('id_user', $id_user);
		return $this->db->get('events');
	}

	function insert_event($data)
	{
		$this->db->insert('events', $data);
	}

	function update_event($data, $id)
	{
		$this->db->where('id', $id);
		$this->db->update('events', $data);
	}

	function delete_event($id)
	{
		$this->db->where('id', $id);
		$this->db->delete('events');
	}
}

?>