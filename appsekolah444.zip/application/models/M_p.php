<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_p extends CI_Model {

	public function insert_daftar($table, $data){
		$insert = $this->db->insert($table, $data);
		return $insert;
	}
	public function update_daftar($data, $email){
		$update = $this->db->query("
			UPDATE pen_user
			SET $data
			WHERE email_daftar='$email'
		");
		echo $this->db->last_query();
		return $update;
	}

	public function insert_transaksi($table, $pengajar){
		$insert = $this->db->insert($table, $pengajar);
		return $insert;
	}

	public function hapus_jadwal_dan_pembayaran($id_transaksi){
		$hps_pembayaran_peserta = $this->db->query("DELETE FROM pembayaran WHERE id_transaksi='$id_transaksi'");
		$hps_transaksi_peserta = $this->db->query("DELETE FROM transaksi WHERE id_transaksi='$id_transaksi'");
		return $hps_pembayaran_peserta;
		return $hps_transaksi_peserta;
	}
	public function insert_pembayaran($table, $data_pembayaran){
		$insert = $this->db->insert($table, $data_pembayaran);
		return $insert;
	}
	
	public function buat_akun($table, $data_akun){
		$insert = $this->db->insert($table, $data_akun);
		return $insert;
	}

	public function cek_email($table, $email){
		$this->db->where('email_daftar', $email);
		$get_email = $this->db->get($table);
		return $get_email;
	}
	
	public function get_data_peserta($session){
		$get_data_peserta = $this->db->query('SELECT * FROM pen_user WHERE email_daftar="'.$this->data['session'].'"');
		return $get_data_peserta;
	}

	//Show Foto and Nama Berdasarkan Session
	public function get_nama_and_foto($session){
		$get_data = $this->db->query("SELECT nama_daftar,foto1 FROM pen_user WHERE email_daftar='$session'");
		return $get_data;
	}
	

	public function pembagian_jadwal($session){
		$get_jadwal_full = $this->db->query("
		SELECT
		pen_user.nama_daftar,
		rumpun_diklat.jenis_pelatihan, 
		tenaga_pengajar.nama_pengajar,
		ruang_kelas.nama_kelas,
		transaksi.tanggal_mengajar,
        transaksi.hari
		FROM transaksi
		INNER JOIN pen_user ON pen_user.id_daftar=transaksi.id_daftar
		INNER JOIN rumpun_diklat ON rumpun_diklat.id_pelatihan=transaksi.id_pelatihan
		INNER JOIN tenaga_pengajar ON tenaga_pengajar.id_pengajar=transaksi.id_pengajar
		INNER JOIN ruang_kelas ON ruang_kelas.id_kelas=transaksi.id_kelas
		WHERE pen_user.email_daftar='$session' ORDER BY transaksi.id");
		return $get_jadwal_full;
	}

	public function cek_pembayaran($session){
		$get_pembayaran = $this->db->query("
		SELECT
		pembayaran.id_pembayaran,
		pembayaran.id_transaksi,
		pembayaran.status,
		rumpun_diklat.harga_pelatihan,
		rumpun_diklat.jenis_pelatihan, 
		rumpun_diklat.hari_pelatihan
		FROM pembayaran
		INNER JOIN transaksi ON transaksi.id_transaksi=pembayaran.id_transaksi
		INNER JOIN pen_user ON pen_user.id_daftar=transaksi.id_daftar 
		INNER JOIN rumpun_diklat ON rumpun_diklat.id_pelatihan=transaksi.id_pelatihan 
		WHERE pen_user.email_daftar='$session'
		GROUP BY pembayaran.id_pembayaran
		ORDER BY pembayaran.status DESC");
		return $get_pembayaran;
	}

	public function update_resi($table, $data, $po_pembayaran){
		$this->db->where('id_pembayaran', $po_pembayaran);
	  	$update = $this->db->update($table, $data);
		return $update;
	}
}
?>